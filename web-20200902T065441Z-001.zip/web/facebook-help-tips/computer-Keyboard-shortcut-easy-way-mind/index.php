<!--------------------------home page-------------------->
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>



<!-- menu Bar option---------------------------------------------->
<?php include('nave.php'); ?>
  
	<!------------------------------------------Floating box 1(under nave bar)----------------------------------------->
 
<!-------------------------------------------------Floating box 2(left menu) --------------------------------------->

 <div class="relativels">
  <!-----------------------------------------------post part-------------------------------------------->
  <div class="relative2">
  <h1 id="h">কম্পিউটার এর সকল কীবোর্ড শর্টকাট মনে রাখার সহজ পদ্ধতি</h1><br>
 <img src="image/postpic.jpg" alt="who seeen your facebook profile" width="900px" height="500px" border="1">
 <br> <h2 id="h">Easy way to remember all of the computer's keyboard shortcuts</h2>
 <br>
<p id="h">General Shortcuts:</p>
<hr>
<p>F1&nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Display Help<br>
F2&nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Rename the selected item<br>
F3&nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Search for a file or folder<br>
F4&nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Display the address bar list in File Explorer<br>
F5&nbsp;&nbsp;&nbsp;--&nbsp;&nbsp;&nbsp;	Refresh the active window<br>
F6&nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Cycle through screen elements in a window or on the desktop<br>
F10&nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Activate the Menu bar in the active app<br>
ALT + F4&nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Close the active item, or exit the active app<br>
ALT + ESC&nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Cycle through items in the order in which they were opened<br>
ALT + Underlined&nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Letter in menus and dialog box options Perform the command for that letter<br>
ALT + ENTER&nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Display properties for the selected item<br>
ALT + SPACEBAR&nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Open the shortcut menu for the active window<br>
ALT + LEFT ARROW&nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Back<br>
ALT + RIGHT ARROW&nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Forward<br>
ALT + PAGE UP&nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Move up one screen<br>
ALT + PAGE DOWN &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Move down one screen<br>
ALT + TAB &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Switch between open apps (except desktop apps) <br>
CTRL + F4&nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Close the active document (in apps that allow you to have multiple documents open simultaneously)<br>
CTRL + A &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Select all items in a document or window<br>
CTRL + C or CTRL + INSERT &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Copy the selected item<br>
CTRL + D / DELETE &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	DELETE the selected item and move it to the Recycle Bin<br>
CTRL + R or F5 &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Refresh the active window<br>
CTRL + V or SHIFT + INSERT&nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Paste the selected item<br>
CTRL + X &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Cut the selected item<br>
CTRL + Y &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Redo an action<br>
CTRL + Z &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Undo an action<br>
CTRL + + or CTRL + – &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Zoom in or out of a large NUMBER of items, like apps pinned to the Start screen<br>
CTRL + mouse scroll wheel &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Change the size of desktop icons or zoom in or out of a large NUMBER of items, like apps pinned to the Start screen<br>
CTRL + RIGHT ARROW &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Move the cursor to the beginning of the next word<br>
CTRL + LEFT ARROW &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Move the cursor to the beginning of the previous word<br>
CTRL + DOWN ARROW &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Move the cursor to the beginning of the next paragraph<br>
CTRL + UP ARROW &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Move the cursor to the beginning of the previous paragraph<br>
CTRL + ALT + TAB &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Use the arrow keys to switch between all open apps<br>
CTRL + ARROW + SPACEBAR &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Select multiple individual items in a window or on the desktop<br>
CTRL + SHIFT + ARROW &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Select a block of text<br>
CTRL + ESC &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Open the Start screen<br>
CTRL + SHIFT + ESC &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Open Task Manager<br>
CTRL + SHIFT &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Switch the keyboard layout when multiple keyboard layouts are available<br>
CTRL + SPACEBAR &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Turn the Chinese input method editor (IME) on or off<br>
SHIFT + F10 &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Display the shortcut menu for the selected item<br>
SHIFT + ARROW &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Select more than one item in a window or on the desktop, or select text within a document<br>
SHIFT + DELETE &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Delete the selected item without moving it to the Recycle Bin first<br>
RIGHT ARROW &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Open the next menu to the right, or open a submenu<br>
LEFT ARROW &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Open the next menu to the left, or close a submenu<br>
ESC&nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;	Stop or leave the current task</p>

<br>
<p id="h">windows Key Shortcuts:</p>
<hr>
<p>
Win + F1 &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Open Windows Help and support<br>
Win &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Display or hide the Start screen<br>
Win + B &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Set focus in the notification area<br>
Win + C &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Open Charms<br>
Win + D &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Display and hide the desktop<br>
Win + E &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Open File Explorer<br>
Win + F &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Open the Search charm and search for files<br>
Win + H &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Open the Share charm<br>
Win + I &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Open the Settings charm<br>
Win + K &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Open the Devices charm<br>
Win + L &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Lock your PC or switch people<br>
Win + M &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Minimize all windows<br>
Win + O &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Lock device orientation<br>
Win + P &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Choose a presentation display mode<br>
Win + Q &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Open the Search charm to search everywhere or within the open app (if the app supports app search)<br>
Win + R &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Open the Run dialog box<br>
Win + S &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Open the Search charm to search Windows and the web<br>
Win + T &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Cycle through apps on the taskbar<br>
Win + U &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Open Ease of Access Center<br>
Win + V &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Cycle through notifications<br>
Win + SHIFT + V &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Cycle through notifications in reverse order<br>
Win + W &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Open the Search charm and search for settings<br>
Win + X &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Open the Quick Link menu<br>
Win + Z &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Show the commands available in the app<br>
Win + , &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Temporarily peek at the desktop<br>
Win + PAUSE &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Display the System Properties dialog box<br>
Win + CTRL + F &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Search for PCs (if you’re on a network)]
Win + SHIFT + M &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Restore minimized windows on the desktop<br>
Win + (NUMBER 1-9) &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Open the desktop and start the app pinned to the taskbar in the position indicated by the number. If the app is already running, it switches to that app.<br>
Win + SHIFT + (NUMBER 1-9) &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Open the desktop and start a new instance of the app pinned to the taskbar in the position indicated by the number<br>
Win + CTRL + (NUMBER 1-9) &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Open the desktop and switch to the last active window of the app pinned to the taskbar in the position indicated by the number<br>
Win + ALT + (NUMBER 1-9) &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Open the desktop and open the Jump List for the app pinned to the taskbar in the position indicated by the number<br>
Win + CTRL + SHIFT + (NUMBER 1-9) &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Open the desktop and open a new instance of the app located at the given position on the taskbar as an administrator<br>
Win + TAB &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Cycle through recently used apps (except desktop apps)<br>
Win + CTRL + TAB &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Cycle through recently used apps (except desktop apps)<br>
Win + SHIFT + TAB &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Cycle through recently used apps (except desktop apps) in reverse order<br>
Win + CTRL + B &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Switch to the app that displayed a message in the notification area<br>
Win + UP ARROW &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Maximize the window<br>
Win + DOWN ARROW &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Remove current app from screen or minimize the desktop window<br>
Win + LEFT ARROW &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Maximize the app or desktop window to the LEFT side of the screen<br>
Win + RIGHT ARROW &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Maximize the app or desktop window to the RIGHT side of the screen<br>
Win + HOME &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Minimize all but the active desktop window (restores all windows on second stroke)<br>
Win + SHIFT + UP ARROW &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Stretch the desktop window to the top and bottom of the screen<br>
Win + SHIFT + DOWN ARROW &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Restore/minimize active desktop windows vertically, maintaining width<br>
Win + SHIFT + LEFT ARROW or RIGHT ARROW &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Move an app or window in the desktop from one monitor to another<br>
Win + SPACEBAR &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Switch input language and keyboard layout<br>
Win + CTRL + SPACEBAR &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Change to a previously selected input<br>
Win + ENTER &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Open Narrator<br>
Win + SHIFT + . &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Cycle through open apps<br>
Win + . &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Cycle through open apps<br>
Win + / &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Initiate IME reconversion<br>
Win + ALT + ENTER &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Open WindowsMedia Center<br>
Win + +/- &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Zoom in or out using Magnifier<br>
Win + ESC &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Exit Magnifier<br>
</p>
 
 
<br> 
<p id="h">Dialog box Shortcuts</p>
<hr>
 <p>
F1 &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Display Help<br>
F4 &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Display the items in the active list<br>
CTRL + TAB &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Move forward through tabs<br>
CTRL + SHIFT + TAB &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Move back through tabs<br>
CTRL + (NUMBER 1-9) &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Move to nth tab<br>
TAB &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Move forward through options<br>
SHIFT + TAB &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Move back through options<br>
ALT + Underlined Letter in menus and dialog box options &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Perform the command (or select the option) that goes with that letter<br>
SPACEBAR &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Select or clear the check box if the active option is a check box<br>
BACKSPACE &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Open a folder one level up if a folder is selected in the Save As or Open dialog box<br>
ARROW keys &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Select a button if the active option is a group of option buttons
 </p>
 <br>
 <p id="h">File explorer Shortcuts</p>
 <hr>
 <p>
 ALT + D &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Select the address bar<br>
CTRL + E &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Select the search box<br>
CTRL + F &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Select the search box<br>
CTRL + N &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Open a new window<br>
CTRL + W &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Close the current window<br>
CTRL + mouse scroll wheel &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Change the size and appearance of file and folder icons<br>
CTRL + SHIFT + E &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Display all folders above the selected folder<br>
CTRL + SHIFT + N &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Create a new folder<br>
NUM LOCK + * &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Display all subfolders under the selected folder<br>
NUM LOCK + + &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Display the contents of the selected folder<br>
NUM LOCK + – &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Collapse the selected folder<br>
ALT + P &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Display the preview pane<br>
ALT + ENTER &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Open the Properties dialog box for the selected item<br>
ALT + RIGHT ARROW &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;View the next folder<br>
ALT + UP ARROW &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;View the folder that the folder was in<br>
ALT + LEFT ARROW &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;View the previous folder<br>
BACKSPACE &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;View the previous folder<br>
RIGHT ARROW &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Display the current selection (if it’s collapsed), or select the first subfolder<br>
LEFT ARROW &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Collapse the current selection (if it’s expanded), or select the folder that the folder was in<br>
END &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Display the bottom of the active window<br>
HOME &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Display the top of the active window<br>
F11 &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Maximize or minimize the active window
</p>
<br>
 <p id="h">Taskbar Shortcuts</p>
  <hr>
  <p>SHIFT + Click a Taskbar Button &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Open an app or quickly open another instance of an app<br>
CTRL + SHIFT + Click a Taskbar Button &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Open an app as an administrator<br>
SHIFT + Right-click a Taskbar Button &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Show the window menu for the app<br>
SHIFT + Right-click a Grouped Taskbar Button &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Show the window menu for the groUP<br>
CTRL + Click a Grouped Taskbar Button &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Cycle through the windows of the groUP</p>
 
 <br>
 <p id="h">File explorer Shortcuts</p>
 <hr>
 <p>
 Hold RIGHT SHIFT for eight seconds &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Turn Filter Keys on and off<br>
LEFT ALT + LEFT SHIFT + PRINT SCREEN &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Turn High Contrast on or off<br>
LEFT ALT + LEFT SHIFT + NUM LOCK &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Turn Mouse Keys on or off<br>
Press SHIFT five times &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Turn Sticky Keys on or off<br>
Press NUM LOCK for five seconds &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Turn Toggle Keys on or off<br>
Win + U &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Open the Ease of Access Center
 </p>
 <br>
 <p id="h">Magnifier Shortcuts</p>
 <hr>
 <p>
 Win + + &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Zoom in<br>
Win + – &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Zoom out<br>
CTRL + ALT + SPACEBAR &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Preview the desktop in full-screen mode<br>
CTRL + ALT + D &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Switch to docked mode<br>
CTRL + ALT + F &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Switch to full-screen mode<br>
CTRL + ALT + I &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Invert colors<br>
CTRL + ALT + L &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Switch to lens mode<br>
CTRL + ALT + R &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Resize the lens<br>
CTRL + ALT + ARROW keys &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Pan in the direction of the ARROW keys<br>
Win + ESC &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Exit Magnifier
 </p>
 <br>
 <p id="h">Narrator Shortcuts</p>
 <hr>
 <p>
 SPACEBAR or ENTER &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Activate current item<br>
TAB + ARROW Keys &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Move around on the screen<br>
CTRL &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Stop reading<br>
CAPS LOCK + D &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Read item<br>
CAPS LOCK + M &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Start reading<br>
CAPS LOCK + H &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Read document<br>
CAPS LOCK + V &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Repeat phrase<br>
CAPS LOCK + W &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Read window<br>
CAPS LOCK + PAGE UP or PAGE DOWN &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Increase or decrease the volume of the voice<br>
CAPS LOCK + +/- &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Increase or decrease the speed of the voice<br>
CAPS LOCK + SPACEBAR &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Do default action<br>
CAPS LOCK + LEFT or RIGHT ARROW &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Move to previous/next item<br>
CAPS LOCK + F2 &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Show commands for current item<br>
Caps + ESC &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Exit Narrator
 </p>
 <br>
 <p id="h">Remote desktop connection Shortcuts</p>
 <hr>
 <p>
 ALT + PAGE UP &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Move between apps, left to right<br>
ALT + PAGE DOWN &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Move between apps, right to left<br>
ALT + INSERT &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Cycle through apps in the order that they were started<br>
ALT + HOME &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Display the Start screen<br>
CTRL + ALT + BREAK &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Switch between a window and full screen<br>
CTRL + ALT + END &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Display the Windows Security dialog box<br>
CTRL + ALT + HOME &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;In full-screen mode, activate the connection bar<br>
ALT + DELETE &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Display the system menu<br>
CTRL + ALT + –
&nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Place a copy of the active window, within the client, on the Terminal server clipboard (similar to ALT + PRINT SCREEN on a local PC)<br>
CTRL + ALT + +
&nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Place a copy of the entire client window area on the Terminal server clipboard (similar to Print Screen on a local PC),br>
CTRL + ALT + RIGHT ARROW 
&nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;TAB out of the Remote Desktop controls to a control in the host app (for example, a button or a text box). Useful when the Remote Desktop controls are embedded in another (host) app.<br>
CTRL + ALT + LEFT ARROW 
&nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;TABout of the Remote Desktop controls to a control in the host app (for example, a button or a text box). Useful when the Remote Desktop controls are embedded in another (host) app.
 </p>
 <br>
 <p id="h">Help viewer Shortcuts</p>
 <hr>
 <p>
 F3 &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Move the cursor to the search box<br>
F10 &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Display the Options menu<br>
HOME &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Move to the beginning of a topic<br>
END &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Move to the end of a topic<br>
ALT + LEFT ARROW &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Move back to the previously viewed topic<br>
ALT + RIGHT ARROW &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Move to the next (previously viewed) topic<br>
ALT + HOME &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Display the Help and support home page<br>
ALT + A &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Display the customer support page<br>
ALT + C &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Display the TABle of Contents<br>
ALT + N &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Display the Connection Settings menu<br>
CTRL + F &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Search the current topic<br>
CTRL + P &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Print a topic
 </p>
<br>
<p id="h">App rearranging Shortcuts (Metro)</p>
 <hr>
 <p>
 Win + . &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Enter Rearrange mode and select apps or dividers across monitors<br>
Win + LEFT ARROW &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Move app divider left<br>
Win + RIGHT ARROW &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Move app divider right<br>
Win + UP ARROW &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Maximize app<br>
Win + DOWN ARROW &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Close app<br>
Win + ESC &nbsp;&nbsp;&nbsp; &rarr;&nbsp;&nbsp;&nbsp;Exit Rearrange mode
 </p>
 </div>
  <!-----------------------------------------------end post part-------------------------------------------->
 
 <div class="relative21">
		<?php include('ground1.php'); ?>
		</div>
  
	<div class="relative21">
	<?php include('ground2.php'); ?>
	</div>
  
  </div>
<!---------------------------------------------most popular------------------------------->
  <div class="relativers">
	<?php include('right-side.php'); ?>
	</div>
	<!----------------------------------------------end right column-------------------------------->
	<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>

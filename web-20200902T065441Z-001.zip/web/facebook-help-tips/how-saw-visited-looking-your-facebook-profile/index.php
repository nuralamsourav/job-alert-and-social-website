<!--------------------------home page-------------------->
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>



<!-- menu Bar option---------------------------------------------->
<?php include('nave.php');    ?>
  

 <div class="relativels">
  <!-----------------------------------------------post part-------------------------------------------->
  <div class="relative2">
  <h1 id="h">কে কে দেখলো আপনার ফেসবুক প্রোফাইল ? জেনে নিন কিভাবে দেখবেন</h1><br>
 <img src="image/img.jpg" alt="who seeen your facebook profile" width="900px" height="500px" border="1">
 <br> <h2 id="h">Who saw your Facebook profile? Know How To Watch</h2>
 <br>
  <p>ফেসবুকে আপনার প্রোফাইল কারা ভিজিট করেছেন, তা জানতে ইচ্ছে করে না? আমাদের সম্পর্কে অনলাইন দুনিয়ায় কার কার আগ্রহ রয়েছে, তা জানার আগ্রহ প্রায় আমাদের সবারই। ফেসবুকেরও আগে সোশ্যাল নেটওয়ার্কিং-এর দুনিয়ায় ঝড় তোলা অর্কুট-এ 'রিসেন্ট ভিজিটর' অপশন ছিল। সেখান থেকে সহজেই জানতে পারতেন, কারা আপনার প্রোফাইল নেড়েচেড়ে দেখছে। ফেসবুক কখনোই এরকম কোনো অপশন রাখেনি। অর্কুটও এখন অতীত। তবু সোশ্যাল নেটওয়ার্কিং-এ কারা আপনার সম্পর্কে আগ্রহী, তা জানতে পারবেন সহজেই। সেই উপায়ই আপনাদের বাতলাবো এখানে।</p>
  <br>
  <p>কয়েকটা সহজ স্টেপ ফলো করে জেনে নিন ফেসবুকে আপনার প্রোফাইল সম্প্রতি কারা ভিজিট করেছেন।</p>
  <p> * প্রথমে ফেসবুকে লগইন করুন।</p>
  <p> * টাইমলাইনে রাইট ক্লিক করুন। 'view page source'সিলেক্ট করুন।</p>
  <p> * কোডে ভরা একটা পেজ খুলবে। বিভ্রান্ত হবেন না। আপনি ঠিক পথেই এগোচ্ছেন।</p>
  <p> * কিবোর্ডে CTRL+F প্রেস করুন। </p>
  <p> * পেজের ডান দিকে যে সার্চ বক্স খুলবে সেখানে টাইপ করুন InitialChatFriendsList</p>
  <p>* InitialChatFriendsList-এর পাশে নম্বরের একটা তালিকা দেখতে পাবেন। </p>
  <p>* যাঁরা আপনার টাইমলাইন ভিজিট করেছেন, তাঁদের আইডি'র তালিকা আসবে।</p>
  <p> * এরাই যে আপনার টাইমলাইন ভিজিট করেছে, তা নিশ্চিত করতে অ্যাড্রেস বারে টাইপ করুন: facebook.com/তারপরে আইডি। এন্টার মারলেই আপনার ভিজিটরের পেজে ল্যান্ড করবেন।</p>
  <p> সূত্র: এই সময় -</p>
 

  
  <p style="text-align:center;">*------------ An English Language ----------*</p> 
  <br>
  <p>Who visits your profile on Facebook, and do not want to know it? Who has an interest in the world about
  us Online, it's curiosity about all of us. Phesabukerao ago Orkut social networking world by storm in the 
  'Recent Visitors' options were. From there, he could easily find out who is viewing your profile and play with.
  Facebook did not really like any of the options. Orkut is now past. Yet you are interested in social networking,
  you can easily find out. Here's the approach you batalabo.</p><br>
  <p>Follow a few simple steps to find out who visits your facebook profile has been recently.</p>
  <p> * Please login first Facebook. </p>
  <p> * Right-click on the timeline. 'View page source' select.</p>
  <p> * Will open a page full of code. Do not be confused. Are you going on the right track.</p>
  <p> * Press CTRL + F keyboard.</p>
  <p> * Type in the search box on the right side of the page to open the 'InitialChatFriendsList'</p>
  <p>* You will see a list of numbers next to 'InitialChatFriendsList'</p>
  <p>* Those who visit your timeline, it will list their ID.</p>
  <p> * Those who have visited your timeline, make sure that the address bar type: facebook.com/ then ID. Maralei enter your visitor will land on the page.</p> 
  <br><br>
  </div>
  
  
  
  
  
  
  
  
  
  
  <!-----------------------------------------------end post part-------------------------------------------->
 
 <div class="relative21">
		<?php include('ground1.php'); ?>
		</div>
  
	<div class="relative21">
	<?php include('ground2.php'); ?>
		
	</div>
  
  </div>
<!---------------------------------------------right-column------------------------------->
  <div class="relativers">
	
	<?php include('right-side.php');     ?>
	
	</div>
	<!----------------------------------------------end right column-------------------------------->
	<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>

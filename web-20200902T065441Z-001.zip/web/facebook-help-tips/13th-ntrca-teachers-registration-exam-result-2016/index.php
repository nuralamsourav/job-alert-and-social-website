<!--------------------------home page-------------------->
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>



<!-- menu Bar option---------------------------------------------->
<?php include('nave.php');?>

  
	<!------------------------------------------Floating box 1(under nave bar)----------------------------------------->
 
<!-------------------------------------------------Floating box 2(left menu) --------------------------------------->

 <div class="relativels">
  <!-----------------------------------------------post part-------------------------------------------->
  <div class="relative2">
  <h1 id="h">বিজ্ঞপ্তি ত্রয়োদশ শিক্ষক নিবন্ধন পরীক্ষা ফলাফল -২০১৬</h1><br>
 <img src="image/ntrcp.jpg" alt="who seeen your facebook profile" width="900px" height="500px" border="1">
 <br> <h2 id="h">13th NTRCA Teachers' Registration Exam- MCQ Exam Result 2016 notification</h2>
 <br>
  <p><b>13th NTRCA MCQ Result Download 2016 ntrca.teletalk.com.bd.</b>  Non-government teachers’ registration & Certification Authority (NTRCA) has been published 13th teacher registration online apply process 2016.
  There are two categories of NTRCA exam. One is for College Level and another one is for school level.
	<br><br>
<p id="m">Time Schedule for 13th NTRCA Exam Circular:</p>
<p>&sext;&nbsp;&nbsp;Online Application form Submission Starting Date: 06 March, 2016</p>

<p>&sext;&nbsp;&nbsp;Online Application form Submission Ending Date: 3rd April, 2016</p>

<p>&sext;&nbsp;&nbsp;School MCQ Exam Date & Time: 13 May 2016. 04:00 pm to 05:00 pm</p>

<p>&sext;&nbsp;&nbsp;School Written Exam Date & Time: 12 August 2016. 9:00 am to 12:00 pm</p>

<p>&sext;&nbsp;&nbsp;College MCQ Exam Date & Time: 13 May 2016. 10:00 am to 11:00 am</P>

<p>&sext;&nbsp;&nbsp;College Written Exam Date & Time: 13 August 2016. 9:00 am to 12:00 pm</p>
<br>
<p>Download NTRCA Teachers Registration Exam last update <b>circular:</b> <a href="#" target="_blank" class="button button1">circular</a></p>
<p>Download NTRCA Teachers Registration Exam <b>syllabus:</b><a href="#" target="_blank" class="button button1">Syllabus</a></p>
<p>Download <b> Admit card</b><a href="#" target="_blank" class="button button1">Admit card </a></p>

<br>
	<p id="m">Time Schedule for 13th NTRCA Exam: </p>
	<p>School Level / School Level II Exam:&nbsp;&nbsp;&nbsp;&nbsp;	6/5/2016 		&nbsp;&nbsp;&nbsp;&nbsp;10:00 AM to 11:00 AM </p>
	<p >College Level Exam:&nbsp;&nbsp;&nbsp;&nbsp;	7/5/2016&nbsp;&nbsp;&nbsp;&nbsp;		10:00 AM to 11:00 AM</p>
	<br>
	<p>13th Non-government Teachers Registration Exam MCQ/preliminary test Question solve (School and College Level) is available here.
	You can Download 13th Non-government Teachers Registration exam MCQ/preliminary Test question Solve for school and college level pdf formate.
	Click below the line  Download 13th NTRCA MCQ exam Question Solve 2016 School or College Level.
	<br>
	<p id="m"><a href="">Download 13th NTRCA MCQ exam Question Solve 2016(School Level)</a></P>
	<p id="m"><a href="">Download 13th NTRCA MCQ exam Question Solve 2016(College Level)</a></P>
	<br>
	<p id="m"> 13th NTRCA Exam Merit List Result 2016 below:</p>
	<br>
<iframe src="http://ntrca.teletalk.com.bd/result/" height="550"; width="910";>
  <p>server busy</p>
  <p>refresh after few seconds</p>
</iframe>
<br><br>
<p id="m">How to pay Fee 13th NTRCA Teachers Registration Exam Apply by SMS Procedure</p>
<p>13th NTRCA Teachers Registration exam 2016 for School and College Level fee paid by only Teletalk Operator.
IF you don't paid your fee, your online application is not applicable and it is invalid.
SMS method of paying your money of 13th NTRCA Teachers Registration Exam-2016 is Details in Given Below..
<p>&sext;&nbsp;&nbsp;SMS Fee: 350/-</p>
<p>&sext;&nbsp;&nbsp;First SMS:<b>NTRCA &nbsp; &#60;space&#62; &nbsp;User ID </b>And send it to 16222</p>
<p>&sext;&nbsp;&nbsp;Second SMS:<b> NTRCA &nbsp;&#60;space&#62; &nbsp;Yes &nbsp;&#60; space&#62; &nbsp;PIN</b> And send it send to 16222</p>
<p>&sext;&nbsp;&nbsp;Having finished your online registration successfully you will get a password.</p>
<p>&sext;&nbsp;&nbsp;Save the User ID & Password for the use in future.</p>
<br>
<p id="m">13th NTRCA Teachers Registration Exam Center:</p>
<p>13th NTRCA Teachers Registration Exam held in 20 districts around in Bangladesh. The Exam Center are: Bogra, Rajshahi, Dinajpur, Rangpur, Pabna, Kustia, 
Jessore, Khulna, Jamalpur, Mymensingh, Tangail, Dhaka, Faridpur, Noakhali, Comilla, sylhet, Barishal, Pautuakhali,Chittagong, Rangamati  </p>
<br>
<p id="m">Viva Date of 13th NTRCA Teachers Registration Exam 2016:</p>
<p>Viva Date of 13th NTRCA Teachers Registration exam 2016 not publish. After publish Written Exam result Viva
Date will be publish and other information publish with Viva date. The Candidate of 13th NTRCA Exam will be Select for Viva after passing MCQ and Written Exam. The Candidate fo written exam only select who are passed MCQ Exam</p>
<p id="m"> Exam Marks and Time Schedule</p>
<p>School Level: MCQ 100 marks + Written 100 marks = 100+100=200 marks.</p>
<p>College Level: MCQ 100 marks + Written 100 marks = 100+100=200 marks.</p>
<p> Time:-School Level & College Level:1 Hour(MCQ exam) + 3 Hours(Written exam) = 4 Hours.</p>
<br><br>
<p id="m">এনটিআরসিএ কর্তৃক এ যাবৎ গৃহীত নিবন্ধন পরীক্ষার ফলাফল: </p>
<br>
<table style="width:100%">
  <tr>
    <th>পরীক্ষা</th>
    <th>মোট আবেদনকারী</th>
    <th>মোট অংশগ্রহণকারী</th>
	 <th>উত্তীর্ণ</th>
	  <th>	উত্তীর্ণের হার</th>
  </tr>
  <tr>
    <td>১ম পরীক্ষা নভেম্বর ২০০৫</td>		
    <td>৭৬,১৮৫</td>
    <td>৫৯,০০০</td>
	<td>৩৩,৭৮৮</td>
	<td>৫৭.২৭%</td>
  </tr>
  <tr>
    <td>২য় পরীক্ষা সেপ্টেম্বর ২০০৬</td>
    <td>১,৩১,৭৫৯</td>
    <td>৯৯,৮০৭</td>
	<td>২২,৩১৮</td>
	<td>২২.৩৬%</td>
  </tr>
  <tr>
    <td>৩য় পরীক্ষা সেপ্টেম্বর ২০০৭</td>
    <td>১,১৩,৯৭৫</td>
    <td>৮৩,৮৯৯</td>
	<td>১৬,০২০</td>
	<td>১৯.০৯%</td>
  </tr>
  <tr>
    <td>৪র্থ পরীক্ষা ডিসেম্বর ২০০৮</td>
    <td>১,২৭,০৭৪</td>
    <td>৯৬,০২৭</td>
	<td>৩১.,০৯৩</td>
	<td>৩২.৩৮%</td>
  </tr>
  <tr>
    <td>৫ম পরীক্ষাডিসেম্বর ২০০৯</td>
    <td>১,৪১,০৮২</td>
    <td>১,০২,৩৪৮</td>
	<td>৩৯,২২৫</td>
	<td>৩৮.৩৩%</td>
  </tr>
  <tr>
    <td>বিশেষ শিক্ষক নিবন্ধন পরীক্ষা, ২০১০</td>
    <td>৭,৭৬৪</td>
    <td>৬,৯৩৬</td>
	<td>১,৩৯৫</td>
	<td>২০.১১%</td>
  </tr>
  <tr>
    <td>৬ষ্ঠ শিক্ষক নিবন্ধন পরীক্ষা, ২০১০	</td>
    <td>২,৮৩,৩১৪</td>
    <td>২,২০,৫১৭</td>
	<td>৪২,৬৪১</td>
	<td>১৯.৩৪%</td>
  </tr>
  <tr>
    <td>৭ম শিক্ষক নিবন্ধন পরীক্ষা, ২০১১	</td>
    <td>৩,২১,৩০১</td>
    <td>২,৫৯,১১৪</td>
	<td>৫৭,২০৩</td>
	<td>২২.৪৪%</td>
  </tr>
  <tr>
    <td>৮ম শিক্ষক নিবন্ধন পরীক্ষা, ২০১২	</td>
    <td>৩,১৩,১৪৫</td>
    <td>২,৪৮,০০১</td>
	<td>৫৬,০৪৬</td>
	<td>২২.৫৯%</td>
  </tr>
   <tr>
    <td>৯ম শিক্ষক নিবন্ধন পরীক্ষা, ২০১৩</td>
    <td>৩,১৪,৮৮৭</td>
    <td>২,৪২,৪৫১</td>
	<td>৭৫,৮৯৮</td>
	<td>৩১.৩০%</td>
  </tr>
</table>



 </div>
  <!-----------------------------------------------end post part-------------------------------------------->
 <div class="relative21">
		<?php include('ground1.php'); ?>
		
		</div>
  
	<div class="relative21">
	<?php include('ground2.php'); ?>
		
	</div>
  
  </div>
<!---------------------------------------------right column------------------------------->
  <div class="relativers">
	<?php include('right-side.php'); ?>

	</div>
	<!----------------------------------------------end right column-------------------------------->
	<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>

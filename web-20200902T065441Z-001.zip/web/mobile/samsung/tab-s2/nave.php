<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>
<nav>
  <div class="navigation">
    <ul>
      
	  <li><a href="">Home</a></li>
      
	   <li><a href="#" tabindex="1">All Result<span class="arrow-down"></span></a>
        <ul class="dropdown">
      <li><a href="ipo-lottery-result-bd-dhaka-chittagong-Stoke-exchange-DSE-CSE">IPO Result</a></li>
      
	  <li><a href="bpsc-Bangladesh-Public-Service-Commission-job-result">BPSC Result</a></li>
	  <li><a href="Prize-bond-draw-result-bd">PRIZE Bond Result</a></li>
	  <li><a href="NTRC-result-admit-circular-download">NTRC Result</a></li>
	</ul>
	</li>
	
       <li><a href="#" tabindex="1">Scholarship<span class="arrow-down"></span></a>
        <ul class="dropdown">
		 <li><a href="jsc-jdc-scholarship-bd-result">International Scholarship</a></li>
      	  <li><a href="scholarship-dutch-bangla-bank-foundation-college-hsclevel-university-honourslevel">Bank Scholarship</a></li>
	  <li><a href="psc-Ebtedayi-scholarship-primary-school-certificate">PSC/Ebtedayi Scholarship</a></li>
      <li><a href="jsc-jdc-scholarship-bd-result">JSC/JDC Scholarship</a></li>
	 <li><a href="ssc-dakhil scholarship">SSC/Dakhil Scholarship</a></li>
	  <li><a href="scholarship-HSC-Alim-all-board-bd">HSC/Alim Scholarship</a></li>
	  </ul>
  </li>
  
  
      <li><a href="#" tabindex="1">Education Result<span class="arrow-down"></span></a>
        <ul class="dropdown">
       <li><a href="Primary-School-Certificate-PSC-Result-dperesult.teletalk.com.bd">PSC/Ebtedayi Result</a></li>
      <li><a href="JSC-jdc-Exam-Result-Education-madrasah-board">JSC/JDC Result</a></li>
      <li><a href="SSC-Dakhil-Exam-Result-Education-technical-madrasah-board">SSC/Dakhil Result</a></li>
		<li><a href="HSC-Alim-technical-Exam-Result-Education-technical-madrasah-board">HSC/Alim Result</a></li>
		<li><a href="BOU-Bangladesh-Open-University-Result">Open University</a></li>
   <li><a href="NU-National-university-Exam-Result-degree-first-second-third-final-year">NU Degree Result</a></li>
      <li><a href="NU-National-university-Exam-Result-Honours-first-second-third-fourth-final-year">NU Honours Result</a></li>
	  <li><a href="NU-National-university-masters-Exam-Result">NU Masters Result</a></li>
  </ul>
  </li>
  
  
   <li><a href="#" tabindex="1">Admission<span class="arrow-down"></span></a>
        <ul class="dropdown">
      <li><a href="Govt-High-School-Admission-Result-Notice-download-pdf">School Admission</a></li>
      <li><a href="HSC-college-Admission-Result-All-Colleges-Result">College/HSC Admission</a></li>
	  <li><a href="NU-national-university-admission-result-honours">NU Admission</a></li>
	  <li><a href="all-public-university-admission-result">University Admission</a></li>
	  <li><a href="medical-college-MBBS-admission-result-check-bd">Medical Admission</a></li>
	   <li><a href="Bangladesh-Polytechnic-Institute-Admission-resutl">Polytechnic Institute</a></li>
	  </ul>
  </li>
  
   <li><a href="#" tabindex="1">JOb Circular<span class="arrow-down"></span></a>
        <ul class="dropdown">
      <li><a href="All-govt-Job-result">Govt. Job circular</a></li>
      <li><a href="All-public-private-bank-job-result">Bank Job circular</a></li>
	  <li><a href="all-year-BCS-Result">BCS Result</a></li>
	  </ul>
  </li>
  
 
       <li><a href="#" tabindex="1">TIPS<span class="arrow-down"></span></a>
        <ul class="dropdown">
      <li><a href="">FACEBOOK TIPS</a></li>
      <li><a href="">WINDOWS 8</a></li>
	  <li><a href="">LINUX</a></li>
	  <li><a href="">BLOGGER</a></li>
      <li><a href="">WORDPRESS</a></li>
	  <li><a href="">INTERNET</a></li>
	  <li><a href="">LINUX</a></li>
	  <li><a href="">WINDOWS 10</a></li>
      <li><a href="">TUTORIAL</a></li>
	  <li><a href="">LIFESTYLE</a></li>
	  
	  
    </ul>
  </li>
  
  
   <li><a href="#" tabindex="1">Entertainment<span class="arrow-down"></span></a>
        <ul class="dropdown">
      <li><a href="All-govt-Job-result">BANGLA IQ TEST</a></li>
      <li><a href="All-public-private-bank-job-result">BANGLADESH TOP ACTRESS</a></li>
	  <li><a href="all-year-BCS-Result">INDIAN BANGLA TOP ACTRESS </a></li>
	  <li><a href="All-govt-Job-result">INDIAN TOP ACTRESS</a></li>
      <li><a href="All-public-private-bank-job-result">TAMIL TOP ACTRESS</a></li>
	  <li><a href="all-year-BCS-Result">PAKISTANI CUTE GIRLS </a></li>
	  <li><a href="All-govt-Job-result">TAMIL HOT GIRLS</a></li>
	  </ul>
  </li>
  
   <li><a href="#" tabindex="1">Mobile<span class="arrow-down"></span></a>
        <ul class="dropdown">
      <li><a href="All-govt-Job-result">Samsung</a></li>
      <li><a href="All-public-private-bank-job-result">Symphony</a></li>
	  <li><a href="all-year-BCS-Result">Walton </a></li>
	  <li><a href="All-govt-Job-result">Micromax</a></li>
      <li><a href="All-public-private-bank-job-result">Maximus</a></li>
	  <li><a href="All-govt-Job-result">HTC</a></li>
      <li><a href="All-public-private-bank-job-result">BlackBerry</a></li>
	  <li><a href="all-year-BCS-Result">Sony</a></li>
	  <li><a href="all-year-BCS-Result">Microsoft</a></li>
	  <li><a href="All-govt-Job-result">LG</a></li>
	  </ul>
  </li>
   <li><a href="#" tabindex="1">Routine<span class="arrow-down"></span></a>
        <ul class="dropdown">
		<li><a href="NU-National-universtiy-first-second-third-final-year-honours-masters-degree-exam-routine">NU Routine</a></li>
      <li><a href="PSC-and-Ebtedayi-exam-Routine">PSC/Ebtedayi Routine</a></li>
      <li><a href="JSC-JDC-exam-Routine-All-board-madrasah-board">JSC/JDC Routine</a></li>
      <li><a href="SSC-Dakhil-exam-Routine-All-board-madrasah-board">SSC/Dakhil Routine</a></li>
		<li><a href="HSC-Alim-exam-Routine-All-board-madrasah-board">HSC/Alim Routine</a></li>
	</ul>
  </li>
    </ul>
  </div>
  <div class="nav_bg">
    <div class="nav_bar"> <span></span> <span></span> <span></span> </div>
  </div>
  <script>

$('.nav_bar').click(function(){
  $('.navigation').toggleClass('visible');
  $('body').toggleClass('opacity');
});

</script>
</nav>

<body>
</html>
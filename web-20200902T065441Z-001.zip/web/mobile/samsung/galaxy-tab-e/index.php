<!--------------------------home page-------------------->
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

  <?php include 'nave.php';?>
  
  
  
 <div class="relativels">
  <!-----------------------------------------------post part-------------------------------------------->
  <div class="relative2">
 <div class="name">
 <img src="image/samsung-galaxy-tab-e-white.jpg" alt="samsung-galaxy-tab-e-white-price-bangladesh">White
 <img src="image/samsung-galaxy-tab-e-black.jpg" alt="samsung-galaxy-tab-e-black-price-bangladesh" >Black
 <img src="image/samsung-galaxy-tab-e-bronze.jpg" alt="samsung-galaxy-tab-e-bronze-price-bangladesh" >Bronze
 
 </div>
	<br><p style="font-size:23px; color:blue; font-family: 'Anton', sans-serif; text-align:center;"><b>SAMSUNG Galaxy Tab E</b></p>
	<p style="font-size:18px; color:green;text-align:center;"><b>Color:&nbsp;Black, White & Bronze</b></p>
	<br>
   <p style="font-size:30px; color:red;text-align:center;"><b>BDT 	23,500/-</b></p>
	<br>
	
	<table>

                                    
                                        <tr>
    <td style="color:#FFFFFF;background-color:#6A5ACD;">Network/Bearer</td>
    <td style="color:#6A5ACD;background-color:#6A5ACD;">Galaxy tab e</td>
  </tr>
                                    
                                    
                                        <tr>
                                            <td>Multi-SIM</td>
                                            <td>Single-SIM</td>
                                        </tr>
                                        <tr>
                                            <td>SIM size</td>
                                            <td>Micro-SIM (3FF)</td>
                                        </tr>
                                        <tr>
                                            <td>Infra</td>
                                            <td>2G GSM, 3G WCDMA</td>
                                        </tr>
                                        <tr>
                                            <td>2G GSM</td>
                                            <td>GSM850, GSM900, DCS1800, PCS1900</td>
                                        </tr>
                                        <tr>
                                            <td>2G CDMA</td>
                                            <td>N/A</td>
                                        </tr>
                                        <tr>
                                            <td>3G UMTS</td>
                                            <td>B1(2100), B8(900)</td>
                                        </tr>
                                    
                                

                                
                                    
                                        <tr>
    <td style="color:#FFFFFF;background-color:#6A5ACD;">Connectivity</td>
    <td style="color:#6A5ACD;background-color:#6A5ACD;">Galaxy tab e</td>
  </tr>
                                    
                                    
                                        <tr>
                                            <td>ANT+</td>
                                            <td>No</td>
                                        </tr>
                                        <tr>
                                            <td>USB Version</td>
                                            <td>USB 2.0</td>
                                        </tr>
                                        <tr>
                                            <td>Location Technology</td>
                                            <td>A-GPS, Glonass</td>
                                        </tr>
                                        <tr>
                                            <td>Earjack</td>
                                            <td>3.5mm Stereo</td>
                                        </tr>
                                        <tr>
                                            <td>MHL</td>
                                            <td>No</td>
                                        </tr>
                                        <tr>
                                            <td>Wi-Fi</td>
                                            <td>802.11 b/g/n 2.4GHz</td>
                                        </tr>
                                        <tr>
                                            <td>Wi-Fi Direct</td>
                                            <td>Yes</td>
                                        </tr>
                                        <tr>
                                            <td>Bluetooth Version</td>
                                            <td>Bluetooth v4.0</td>
                                        </tr>
                                        <tr>
                                            <td>NFC</td>
                                            <td>No</td>
                                        </tr>
                                        <tr>
                                            <td>Bluetooth Profiles</td>
                                            <td>A2DP, AVRCP, DI, HFP, HID, HOGP, HSP, MAP, OPP, PAN, PBAP</td>
                                        </tr>
                                        <tr>
                                            <td>PC Sync.</td>
                                            <td>N/A</td>
                                        </tr>
                                    
                                

                                
                                    
                                       <tr>
    <td style="color:#FFFFFF;background-color:#6A5ACD;">OS</td>
    <td style="color:#6A5ACD;background-color:#6A5ACD;">Galaxy tab e</td>
  </tr>
                                    
                                    
                                        <tr>
                                            <td></td>
                                            <td>Android Kitkat 4.4.4</td>
                                        </tr>
                                    
                                

                                
                                    
                                        <tr>
    <td style="color:#FFFFFF;background-color:#6A5ACD;">Display</td>
    <td style="color:#6A5ACD;background-color:#6A5ACD;">Galaxy tab e</td>
  </tr>
                                    
                                    
                                        <tr>
                                            <td>Technology (Main Display)</td>
                                            <td>TFT</td>
                                        </tr>
                                        <tr>
                                            <td>Size (Main Display)</td>
                                            <td>9.6" (243.4mm)</td>
                                        </tr>
                                        <tr>
                                            <td>Resolution (Main Display)</td>
                                            <td>1280 x 800 (WXGA)</td>
                                        </tr>
                                        <tr>
                                            <td>Color Depth (Main Display)</td>
                                            <td>16M</td>
                                        </tr>
                                        <tr>
                                            <td>S Pen Support</td>
                                            <td>No</td>
                                        </tr>
                                    
                                

                                
                                    
                                        <tr>
    <td style="color:#FFFFFF;background-color:#6A5ACD;">Processor</td>
    <td style="color:#6A5ACD;background-color:#6A5ACD;">Galaxy tab e</td>
  </tr>
                                    
                                    
                                        <tr>
                                            <td>CPU Speed</td>
                                            <td>1.3GHz</td>
                                        </tr>
                                        <tr>
                                            <td>CPU Type</td>
                                            <td>Quad-Core</td>
                                        </tr>
                                    
                                

                                
                                    
                                       <tr>
    <td style="color:#FFFFFF;background-color:#6A5ACD;">General Information</td>
    <td style="color:#6A5ACD;background-color:#6A5ACD;">Galaxy tab e</td>
  </tr>
                                    
                                    
                                        <tr>
                                            <td>Form Factor</td>
                                            <td>Tablet</td>
                                        </tr>
                                    
                                

                                
                                    
                                        <tr>
    <td style="color:#FFFFFF;background-color:#6A5ACD;">Memory</td>
    <td style="color:#6A5ACD;background-color:#6A5ACD;">Galaxy tab e</td>
  </tr>
                                    
                                        <tr>
                                            <td>RAM Size (GB)</td>
                                            <td>1.5</td>
                                        </tr>
                                        <tr>
                                            <td>External Memory Support</td>
                                            <td>MicroSD (Up to 128GB) Internal Memory 8GB</td>
                                        </tr>
                                    
                                

                                
                                    
                                        <tr>
    <td style="color:#FFFFFF;background-color:#6A5ACD;">Camera</td>
    <td style="color:#6A5ACD;background-color:#6A5ACD;">Galaxy tab e</td>
  </tr>
                                    
                                    
                                        <tr>
                                            <td>Video Recording Resolution</td>
                                            <td>HD (1280 x 720)@30fps</td>
                                        </tr>
                                        <tr>
                                            <td>Main Camera - Resolution</td>
                                            <td>CMOS 5.0 MP</td>
                                        </tr>
                                        <tr>
                                            <td>Front Camera - Resolution</td>
                                            <td>CMOS 2.0 MP</td>
                                        </tr>
                                        <tr>
                                            <td>Main Camera - Flash</td>
                                            <td>No</td>
                                        </tr>
                                        <tr>
                                            <td>Main Camera - Auto Focus</td>
                                            <td>Yes</td>
                                        </tr>
                                    
                                

                                
                                    
                                       <tr>
    <td style="color:#FFFFFF;background-color:#6A5ACD;">Sensors</td>
    <td style="color:#6A5ACD;background-color:#6A5ACD;">Galaxy tab e</td>
  </tr>
                                    
                                        <tr>
                                            <td></td>
                                            <td>Accelerometer</td>
                                        </tr>
                                    
                                

                                
                                    
                                        <tr>
    <td style="color:#FFFFFF;background-color:#6A5ACD;">Physical specification</td>
    <td style="color:#6A5ACD;background-color:#6A5ACD;">Galaxy tab e</td>
  </tr>
                                    
                                    
                                        <tr>
                                            <td>Dimension (HxWxD, mm)</td>
                                            <td>241.9 x 149.5 x 8.5</td>
                                        </tr>
                                        <tr>
                                            <td>Weight (g)</td>
                                            <td>495</td>
                                        </tr>
                                    
                                

                                
                                    
                                       <tr>
    <td style="color:#FFFFFF;background-color:#6A5ACD;">Battery</td>
    <td style="color:#6A5ACD;background-color:#6A5ACD;">Galaxy tab e</td>
  </tr>
                                    
                                    
                                        <tr>
                                            <td>Internet Usage Time(3G) (Hours)</td>
                                            <td>Up to 7</td>
                                        </tr>
                                        <tr>
                                            <td>Internet Usage Time(Wi-Fi) (Hours)</td>
                                            <td>Up to 8</td>
                                        </tr>
                                        <tr>
                                            <td>Video Playback Time (Hours)</td>
                                            <td>Up to 7</td>
                                        </tr>
                                        <tr>
                                            <td>Standard Battery Capacity (mAh)</td>
                                            <td>5000</td>
                                        </tr>
                                        <tr>
                                            <td>Removable</td>
                                            <td>No</td>
                                        </tr>
                                        <tr>
                                            <td>Audio Playback Time (Hours)</td>
                                            <td>Up to 95</td>
                                        </tr>
                                        <tr>
                                            <td>Talk Time (3G WCDMA) (Hours)</td>
                                            <td>Up to 26</td>
                                        </tr>

                                    
                                

                                
                                    
                                       <tr>
    <td style="color:#FFFFFF;background-color:#6A5ACD;">Audio and Video</td>
    <td style="color:#6A5ACD;background-color:#6A5ACD;">Galaxy tab e</td>
  </tr>
                                    
                                    
                                        <tr>
                                            <td>Video Playing Format</td>
                                            <td>MP4, M4V, 3GP, 3G2, MKV, WEBM</td>
                                        </tr>
                                        <tr>
                                            <td>Video Playing Resolution</td>
                                            <td>FHD (1920 x 1080)@30fps</td>
                                        </tr>
                                        <tr>
                                            <td>Audio Playing Format</td>
                                            <td>MP3, M4A, 3GA, AAC, OGG, OGA, WAV, AMR, AWB, FLAC, MID, MIDI, XMF, MXMF, IMY, RTTTL, RTX, OTA</td>
                                        </tr>
                                    
                                

                               
                                    
                                        <tr>
    <td style="color:#FFFFFF;background-color:#6A5ACD;"> Services and Applications</td>
    <td style="color:#6A5ACD;background-color:#6A5ACD;">Galaxy tab e</td>
  </tr>
                                    
                                    
                                        <tr>
                                            <td>S-Voice</td>
                                            <td>No</td>
                                        </tr>
                                        <tr>
                                            <td>Mobile TV</td>
                                            <td>No</td>
                                        </tr>
                                    
                                

                                
                                    
                                        <tr>
    <td style="color:#FFFFFF;background-color:#6A5ACD;">Price</td>
    <td style="color:#6A5ACD;background-color:#6A5ACD;">Galaxy tab e</td>
  </tr>
                                    
                                        <tr>
                                            <td>Regular Price</td>
                                            <td><b>23,500/-</b></td>
                                        </tr>
                                    
                                
</table>
	
	
	
	
	
	</div>
  <!-----------------------------------------------end post part-------------------------------------------->
 
 <div class="relative21">
		<div class="after-box1"><h2 id="h">RECOMMENDED FOR YOU</h2></div>
		<div class="img">
		<a target="_blank" href="">
		<img src="image/college.jpg" alt="Trolltunga Norway" width="32%" height="178">
			<div class="desc">এইচএসসি কলেজের ভর্তি তথ্য, প্রক্রিয়া ও ফলাফল-২০১৬</div>
				</a>		
		</div>
		
		<div class="img">
		<a target="_blank" href="">
		<img src="image/ssc2.jpg" alt="ssc exam result re-check re-scrutiny application" width="32%" height="178">
			<div class="desc">এস এস সি ফলাফল-২০১৬ ফল পুনঃনিরীক্ষণ  করতে ক্লিক করুন </div>
				</a>	
		</div>
		
		<div class="img">
		<a target="_blank" href="">
		<img src="image/hsc.png" alt="HSC Result Education board result 2016" width="32%" height="178">
			<div class="desc">এইচএসসি সকল শিক্ষা বোর্ডের ফলাফল-২০১৬-</div>
				</a>
		</div>
		
		<div class="img">
		<a target="_blank" href="">
		<img src="image/hsc.png" alt="HSC Result Education board result 2016" width="32%" height="178">
			<div class="desc">এইচএসসি সকল শিক্ষা বোর্ডের ফলাফল-২০১৬-</div>
				</a>
		</div>
		
		</div>
  
	<div class="relative21">
	<div class="after-box1"><h3 id="h">HOT & CUTE GIRL PICTURE</h3></div>
		<div class="img">
		<a target="_blank" href="">
		<img src="image/girl.jpg" alt="Trolltunga Norway" >
			<div class="desc">Tamil and Pakistani Hot and Cute Girls Photos and Wallpaper</div>
				</a>
		</div>
		
		<div class="img">
		<a target="_blank" href="">
		<img src="image/model.jpg" alt="Trolltunga Norway">
			<div class="desc">Tamil Actress Model Hot picture and Wallpaper</div>
				</a>
		</div>
		
		<div class="img">
		<a target="_blank" href="">
		<img src="image/saree.jpg" alt="Trolltunga Norway" >
			<div class="desc">Tamil actress hot photo with saree</div>
				</a>
		</div>
		
		<div class="img">
		<a target="_blank" href="">
		<img src="image/hsc.png" alt="HSC Result Education board result 2016" width="32%" height="178">
			<div class="desc">cute actress model with saree</div>
				</a>
		</div>
		
	</div>
  
  </div>
<!---------------------------------------------most popular------------------------------->
  <div class="relativers">
	<!-----------------------search Option---------------------------------->
	<div class="floating-box2">
	<div class="search">
								<td align="center">
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Search in this side
								</td>
								<td valign="middle" align="right"><br>
								<form action="http://www.google.com/cse" id="cse-search-box" target="_blank">
  <div>
    <input type="hidden" name="cx" value="partner-pub-7076007165145310:7627252844" />
    <input type="hidden" name="ie" value="UTF-8" />
    <input type="text" name="q" size="25" />
    <input type="submit" name="sa"  value="Search" />
  </div>
</form>

<script type="text/javascript" src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en"></script>

								</td>
</tr>
</div>
	
	</div>
	<!-----------------------------------------social share button------------------------------------->
	
	<!------------------------------------------Most popular----------------------------------------->
	<div class="after-box1">
	<p id="h"><b>MOST POPULAR</b></p>
	</div>
	<div class="floating-box2">
	<a target="_blank" href="">
		<div class="img1">
		<img src="image/fbprofile.jpg" alt="dbblf scholarship ssc 2016" width="32%" height="278">
		</div>
			<div class="desc1">কে কে দেখলো আপনার ফেসবুক প্রোফাইল ? জেনে নিন কিভাবে দেখবেন
				</a>
				</div>
	</div>
	
	<div class="floating-box2">
	<a target="_blank" href="">
		<div class="img1">
		<img src="image/fbprofile2.jpg" alt="dbblf scholarship ssc 2016" width="32%" height="278">
		</div>
			<div class="desc1">ফেসবুকে অন্যের লুকানো ফ্রেন্ড লিস্ট দেখার কৌশল…
				</a>
				</div>
	</div>
	<div class="floating-box2">
	<a target="_blank" href="">
		<div class="img1">
		<img src="image/keyboard.jpg" alt="dbblf scholarship ssc 2016" width="32%" height="278">
		</div>
			<div class="desc1">কম্পিউটার এর সকল কীবোর্ড শর্টকাট  মনে রাখার সহজ  পদ্ধতি			</a>
				</div>
	</div>
	
	<div class="floating-box2">
	<a target="_blank" href="">
		<div class="img1">
		<img src="image/apj.jpg" alt="dbblf scholarship ssc 2016" width="32%" height="278">
		</div>
			<div class="desc1">রাষ্ট্রপতি ডঃ এ পি জে আবদুল কালামের ১২ টি উক্তি আপনার ক্যারিয়ার পাল্টে দিতে পারে
				</a>
				</div>
	</div>
	
	<div class="floating-box2">
	<a target="_blank" href="">
		<div class="img1">
		<img src="image/fbhack.jpg" alt="dbblf scholarship ssc 2016" width="32%" height="278">
		</div>
			<div class="desc1">খুব সহজেই যেকোনো ফেসবুক অ্যাকাউন্ট হ্যাক!
				</a>
				</div>
	</div>
	
	
	<div class="floating-box2">
	<a target="_blank" href="">
		<div class="img1">
		<img src="image/ntrc.jpg" alt="dbblf scholarship ssc 2016" width="32%" height="278">
		</div>
			<div class="desc1">১৩তম শিক্ষক নিবন্ধন পরীক্ষার ফলাফল-২০১৬
				</a>
				</div>
	</div>
	<div class="contact">
	<p style="background-color:#4682B4;color:white;font-size:18px;">Get Update Via E-mail</p></br>
	<form name="fmce" method="post" action="index2.php">
	<font size="4"><b>Name: </b></font><input type="text" name="name"  maxlength="50" /></br></br>
	<font size="4"><b>Email: </b></font><input type="text" name="email" maxlength="150" /></br></br>
	<center><input type="submit" value="submit" style="width:100px; height: 40px;"/></center>
	</form>
	</div>
	</div>
	<!----------------------------------------------end right column-------------------------------->
</body>
</html>

<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>ntrca result-www.ntrca.gov.bd</title>

<meta charset="utf-8">
<META NAME="author" CONTENT="Nur Alam Sourav">
<META NAME="Description" CONTENT="ntrca teacher registration non government exam circular, notice, latest update news and Result publish this website.">
<META NAME="Keywords" 	CONTENT="www.techedu.gov.bd,www.ntrca.gov.bd,bd result,ntrca.teletalk.com.bd,www.ntrca.teletalk.com.bd,ntrca result,techedu.gov.bd,www.ntrca,www.ntrca.com,ntrca bd,teletalk.com.bd,ntrca.gov.bd,ntrca circular,www.teletalk.com,teacher registration,bdresult,শিক্ষক নিবন্ধন,www.hsc result.com,www.ntrca.bd.com,ntrca notice,www.education board result.com,teletalk.com,www.bpsc.bd.com,ntcra,ntrca.teletalk,ntrca syllabus,www.ntrca.bd,ntrca.com,ntrca notice board,teletalk result,hsc result.com,ntrca admit card,শিক্ষক,www.ntrca.teletalk.com,nibondhon,ntrca office,nu.edu.bd notice board,ntrca.teletalk.com,ntrca admit card download,ntrca exam question,ntrc bd,www.ntrca.teletalk.gov.bd,shikkhok nibondhon,www.ntrca.com.bd,ntrca exam,teachers registration,www.educationboard result.com,ntrca.teletalk.bd,ntrca.bd.com,www.ntrc.com,www.ntrca result,non government teachers registration,ntrca exam result,nibondhon exam,ntrac,www.ntrca result.com,non-government teachers,teacher registration bd,ntrca.gov.bd circular,www.dpe.gov.bd admit card,ntrca question,ntrca.com.bd,non govt teacher registration,nctra,teacher nibondhon,nibondhon result,ntrca syllabus school,ntrca syllabus college level,www.ntrca.gov.bd circular,ntrc bangladesh,ntrca exam syllabus,ntrca exam date,ntrca bangladesh,teacher registration circular,nibondhon circular,teacher registration exam,www.ntrca.gov,teletalk.gov.bd,ntrca admit,result of ntrca">
<META NAME="Language" CONTENT="English">
<META HTTP-EQUIV="CACHE-CONTROL" CONTENT="PUBLIC">
<META NAME="Designer" CONTENT="Nur Alam">
<META NAME="distribution" CONTENT="Global">
<META NAME="city" CONTENT="Dhaka">
<META NAME="country" CONTENT="Bangladesh">
<meta name="google-site-verification" content="" />

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="../include/home-post/image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="../include/home-post/style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
<script language="javascript">
  document.onmousedown = disableclick;
  status = "Right Click Disabled";
  Function disableclick(e)
  {
    if(event.button == 2)
    {
      alert(status);
      return false; 
    }
  }
</script> 
</head>
<body oncontextmenu="return false">



<!-- menu Bar option---------------------------------------------->
<?php include('../include/home-post/nave.php'); ?>

  
	
  <div class="relativels">
	<?php include('../include/home-post/latest.php'); ?>
	</div>
  
  
  </div>
<!-------------------------------------posting part---------------------------->
 <div class="relativem">
  	
	<div class="relative2">
		No Result Found at this Time. Please find Your Result after few Moment
		</div>
	
		
	</div>
	
<!------------------------------------------------------------------------------->
	<div class="relativers">
	<?php include('../include/home-post/popular.php'); ?>
	
	
		
	</div>
	
	<!----------------------------------------------end right column-------------------------------->
	<div class="footer">
	<?php include('../include/home-post/footer.php'); ?>
	</div>
<!-- Go to www.addthis.com/dashboard to customize your tools -->
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-575a3cc810553983"></script>

	
</body>
</html>

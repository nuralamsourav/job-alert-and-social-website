<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>college admission</title>

<meta charset="utf-8">
<META NAME="author" CONTENT="Nur Alam Sourav">
<META NAME="Description" CONTENT="College Admission for HSC level Students who are passed SSC Examination. The information of college admission such as how to apply online to admit college and then College admission result for admit to HSC Level education .">
<META NAME="Keywords" 	CONTENT="admission,college,college admission,city college,college board,online college,scholarships,online colleges,colleges and universities,admission test,college admission result,college admissions,college admission form,education colleges,admission form of college,online college admission,college classes,admission application,college education,apply for college,admission college,college application,college search,college admission requirements,medical college admission test,college student,admission from,college admission process,community college,college program,harvard university admissions,admission requirements,college degree,continuing education,college class,college admission system,admission for college,college admission results,collage admission,admission in college,technical college,college students,college application form,online college application,college registration,college admission information,college scholarships,college course,college admission info,apply to college,college admission application,college information,">
<META NAME="Language" CONTENT="English">
<META HTTP-EQUIV="CACHE-CONTROL" CONTENT="PUBLIC">
<META NAME="Designer" CONTENT="Nur Alam">
<META NAME="distribution" CONTENT="Global">
<META NAME="city" CONTENT="Dhaka">
<META NAME="country" CONTENT="Bangladesh">
<meta name="google-site-verification" content="" />

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="../include/home-post/image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="../include/home-post/style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
<script language="javascript">
  document.onmousedown = disableclick;
  status = "Right Click Disabled";
  Function disableclick(e)
  {
    if(event.button == 2)
    {
      alert(status);
      return false; 
    }
  }
</script> 
</head>
<body oncontextmenu="return false">



<!-- menu Bar option---------------------------------------------->
<?php include('../include/home-post/nave.php'); ?>

  
	
  <div class="relativels">
	<?php include('../include/home-post/latest.php'); ?>
	</div>
  
  
  </div>
<!-------------------------------------posting part---------------------------->
 <div class="relativem">
  	
	<div class="relative2">
		No Result Found at this Time. Please find Your Result after few Moment
		</div>
	
		
	</div>
	
<!------------------------------------------------------------------------------->
	<div class="relativers">
	<?php include('../include/home-post/popular.php'); ?>
	
	
		
	</div>
	
	<!----------------------------------------------end right column-------------------------------->
	<div class="footer">
	<?php include('../include/home-post/footer.php'); ?>
	</div>
<!-- Go to www.addthis.com/dashboard to customize your tools -->
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-575a3cc810553983"></script>

	
</body>
</html>

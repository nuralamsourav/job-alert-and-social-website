<!--------------------------home page-------------------->
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>

<meta charset="utf-8">
<META NAME="author" CONTENT="Nur Alam Sourav">
<META NAME="Description" CONTENT="Get all Bangladesh education board result, Exam Routine, National University Result, IPO Result,free iq test bangal question answer,facebook tips,hot girl photo, SSC result, HSC result, Admission Result and education news from educationboardresult.gov,bd">
<META NAME="Keywords" 	CONTENT="bd result, bpsc, samsung mobile price, symphoney mobile bd price, micromax mobile, walton mobile price, mobile price bd, govt job circular, bank job circular, bcs question ans result syllabus, education board result,nu.bd, jsc result,jsc result 2016,iq test, bangla iq test, bangal iq test question with answer, bangla iq test quiz, national university result, nu result,education board result,ipo result, bd ipo, ipo bd, ipo lottery result, ipo form, dse ipo result, dsc ipo, ipo result bd, ipo news bd, nu routine, psc routine, ebtedaye routine, jsc/ jdc routine, ssc exam routine, dakhil exam routine, alim examination routine, hsc exam routine, bd ipo news, bdipo result, upcoming ipo bd, new ipo, dsebd.org ipo result, dutch bangla bank scholarship,dpe result, www.dpe.gov.bd.result, www.dpe, www.dpe.gov.bd, psc scholarship result, www.psc result.com, jsc result , psc bd, primary education board , ssc exam result, dakhil result, nu degree result , nu notice board, medical admission result, polytechnic admission result, psc routine, jsc routine, jdc routine, ssc routine, dakhil routine, hsc routine, alim routine, nu routine, honours routine, masters routine, bd jobs, bd jobs today, bd job, bd jobs news, bdjobs bangla, bangladesh bank recruitment , govt job bd , bcs result, bcs news, bcs application, bcs form, job circular, bank job circualr, gov job circular, current job circular, bd jobs circular, admission result, college admission, university admission result,  ebtedaye result, alim result, hsc result, ssc scholarship result, hsc scholarship result, national university admission , national university bd, nu result bd ,hot girl bd, tamil hot girl, pakistani hot girls, bd model, apu biswas, mahi, top most photo, picture, image, hd wallpaper, purnima hot photo, nu result, nu bd, national university result, nu.edu.bd result, nu bd result, primary result, directorate of primary education, ipo news, bpsc result, dsebd ipo, investing, education board result bd,result bd, ssc result 2016 bd, ssc result bd,nu.edu.bd result,ssc result bd, bcs exam, bpsc form, prize bond result, prize bond, prize bond draw, prize bond draw result, prise bond, ntrc result, teletalk bd, bdresult, ntrc bd, www.education board result.com, education board bd result, jsc rajal, nu.edu.bd notice, nu notice, nu bd notice ,honours result, national university degree result, national university masters result, education board result bd, nu admission result, nubd, nu admission, nu.edu.bd.info,  psc bdpsc result bd, sscresult, ssc result ,  www.education result.com, ntrca exam question, teacher registration, teletalk bangladesh, nu admission result,jsc exam result 2016,education bd,national university admission result bd,nu admission, jsc exam,www.ntrca, ntrca admit card, www.ntrca.bd.com,ntrca result, www.ntrca.com, www.ntrca.gov.bd,ntrca bd, www.ntrca.teletalk.com.bd, ntrca.gov.bd,??????, ntrca.teletalk.com.bd  jsc result,bd education board result,jsc scholarship result 2016,jdc result, jsc results 2016,bd education board,jsc scholarship result 2016, nu bd result,jdc result 2016,education bord bd,all result bd, scholarship, scholarships, nu result bd,nu admission test result bd, bd ssc result, national university, education board result bd, education board bd result, psc resutl bd">
<META NAME="Language" CONTENT="English">
<META HTTP-EQUIV="CACHE-CONTROL" CONTENT="PUBLIC">
<META NAME="Designer" CONTENT="Nur Alam Sourav">
<META NAME="distribution" CONTENT="Global">
<META NAME="city" CONTENT="Dhaka">
<META NAME="country" CONTENT="Bangladesh">
<meta name="google-site-verification" content="L4vmlt1MQkEUZooxRY1tEXtZ0sC02JSSVRSQ_aEFvSQ" />

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="image/style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
<script language="javascript">
  document.onmousedown = disableclick;
  status = "Right Click Disabled";
  Function disableclick(e)
  {
    if(event.button == 2)
    {
      alert(status);
      return false; 
    }
  }
</script> 
</head>
<body oncontextmenu="return false">



<!-- menu Bar option---------------------------------------------->
<?php include('image/nave.php'); ?>

  
	<!------------------------------------------Floating box 1(under nave bar)----------------------------------------->
 
<!-------------------------------------------------Floating box 2(left menu) --------------------------------------->

  <div class="relativels">
	<?php include('image/latest.php'); ?>
	</div>
  
  
  </div>

<!---------------------------------float box3(middle coloumn)--------------------------------------->
  <div class="relativem">
  <!-----------------------------row 1 -------------------------------------------------->
		<?php 
$num_rec_per_page=7;
mysql_connect('localhost','root','');
mysql_select_db('help');
if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; }; 
$start_from = ($page-1) * $num_rec_per_page; 
$sql = "SELECT * FROM post LIMIT $start_from, $num_rec_per_page"; 
$rs_result = mysql_query ($sql); //run the query
?> 
<?php 
while ($row = mysql_fetch_assoc($rs_result)) { 
?> 
            
            <?php echo $row['title']; ?>
         <?php echo $row['admin']; ?>
         <?php echo $row['catagory']; ?>
         <?php echo $row['time']; ?>
         <?php echo $row['post']; ?>
         
         
<?php 
}; 
?> 
<?php 
$sql = "SELECT * FROM post"; 
$rs_result = mysql_query($sql); //run the query
$total_records = mysql_num_rows($rs_result);  //count number of records
$total_pages = ceil($total_records / $num_rec_per_page); 

echo "<a href='index.php?page=1'>".'|<'."</a> "; // Goto 1st page  

for ($i=1; $i<=$total_pages; $i++) { 
            echo "<a href='index.php?page=".$i."'>".$i."</a> "; 
}; 
echo "<a href='index.php?page=$total_pages'>".'>|'."</a> "; // Goto last page
?>

		
	</div>
<!-----------------------colume right side----------------------------------------------------------------->
	
	<div class="relativers">
	<?php include('image/popular.php'); ?>
	
	
		
	</div>
	
	<!----------------------------------------------end right column-------------------------------->
	<div class="footer">
	<?php include('image/footer.php'); ?>
	</div>
<!-- Go to www.addthis.com/dashboard to customize your tools -->
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-575a3cc810553983"></script>

	
</body>
</html>

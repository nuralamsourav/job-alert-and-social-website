<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>bank  job circular</title>

<meta charset="utf-8">
<META NAME="author" CONTENT="Nur Alam Sourav">
<META NAME="Description" CONTENT="Bangladeshi All Government and private Bank Job news and latest circular update is all time and at first publish this website. to View today publish Govt. and private Bank Job circular or news">
<META NAME="Keywords" 	CONTENT="bank  job circular,jobs in bd,bank job bd,bd job news,job circular,job in bd,bd bank job,bd jobs online,all jobs bd,bd job circular,job site in bd,bd job today,bank jobs bd,bangladeshi jobs,all bank jobs bd,bd job site,bd online jobs,bd bank jobs,recent bank job circular,bangla job,all bank job circular,sonali bank recruitment,prothom alo jobs today,job circular bd,bangladesh bank recruitment,bd bank job circular,bangladeshi jobs site,bank job circular 2013,banking job bd,prothom alo jobs bank,sonali bank jobs,bd jobs in bank,bangladeshi job sites,bank jobs circular,bangla job application,jobs site in bd,bd job bank,sonali bank job,prothom alo bd jobs,national bank job circular,bd job search,janata bank job circular,bangladeshi job website,bangladeshi bank jobs,all bangladeshi bank jobs,new bank job circular,bd govt jobs,islami bank job circular,jobs today bd,online job bd,all bd jobs,govt job bd,latest job circular,online job in bd,bd govt job circular,bank job circular bd,all bank job bd,">
<META NAME="Language" CONTENT="English">
<META HTTP-EQUIV="CACHE-CONTROL" CONTENT="PUBLIC">
<META NAME="Designer" CONTENT="Nur Alam">
<META NAME="distribution" CONTENT="Global">
<META NAME="city" CONTENT="Dhaka">
<META NAME="country" CONTENT="Bangladesh">
<meta name="google-site-verification" content="" />

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="../include/home-post/image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="../include/home-post/style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
<script language="javascript">
  document.onmousedown = disableclick;
  status = "Right Click Disabled";
  Function disableclick(e)
  {
    if(event.button == 2)
    {
      alert(status);
      return false; 
    }
  }
</script> 
</head>
<body oncontextmenu="return false">



<!-- menu Bar option---------------------------------------------->
<?php include('../include/home-post/nave.php'); ?>

  
	
  <div class="relativels">
	<?php include('../include/home-post/latest.php'); ?>
	</div>
  
  
  </div>
<!-------------------------------------posting part---------------------------->
 <div class="relativem">
  	
	<div class="relative2">
		No Result Found at this Time. Please find Your Result after few Moment
		</div>
	
		
	</div>
	
<!------------------------------------------------------------------------------->
	<div class="relativers">
	<?php include('../include/home-post/popular.php'); ?>
	
	
		
	</div>
	
	<!----------------------------------------------end right column-------------------------------->
	<div class="footer">
	<?php include('../include/home-post/footer.php'); ?>
	</div>
<!-- Go to www.addthis.com/dashboard to customize your tools -->
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-575a3cc810553983"></script>

	
</body>
</html>

<!--------------------------home page-------------------->
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>

<meta charset="utf-8">
<META NAME="author" CONTENT="Nur Alam Sourav">
<META NAME="Description" CONTENT="Get all Bangladesh education board result, Exam Routine, National University Result, IPO Result,free iq test bangal question answer,facebook tips,hot girl photo, SSC result, HSC result, Admission Result and education news from educationboardresult.gov,bd">
<META NAME="Keywords" 	CONTENT="bd result, bpsc, samsung mobile price, symphoney mobile bd price, micromax mobile, walton mobile price, mobile price bd, govt job circular, bank job circular, bcs question ans result syllabus, education board result,nu.bd, jsc result,jsc result 2016,iq test, bangla iq test, bangal iq test question with answer, bangla iq test quiz, national university result, nu result,education board result,ipo result, bd ipo, ipo bd, ipo lottery result, ipo form, dse ipo result, dsc ipo, ipo result bd, ipo news bd, nu routine, psc routine, ebtedaye routine, jsc/ jdc routine, ssc exam routine, dakhil exam routine, alim examination routine, hsc exam routine, bd ipo news, bdipo result, upcoming ipo bd, new ipo, dsebd.org ipo result, dutch bangla bank scholarship,dpe result, www.dpe.gov.bd.result, www.dpe, www.dpe.gov.bd, psc scholarship result, www.psc result.com, jsc result , psc bd, primary education board , ssc exam result, dakhil result, nu degree result , nu notice board, medical admission result, polytechnic admission result, psc routine, jsc routine, jdc routine, ssc routine, dakhil routine, hsc routine, alim routine, nu routine, honours routine, masters routine, bd jobs, bd jobs today, bd job, bd jobs news, bdjobs bangla, bangladesh bank recruitment , govt job bd , bcs result, bcs news, bcs application, bcs form, job circular, bank job circualr, gov job circular, current job circular, bd jobs circular, admission result, college admission, university admission result,  ebtedaye result, alim result, hsc result, ssc scholarship result, hsc scholarship result, national university admission , national university bd, nu result bd ,hot girl bd, tamil hot girl, pakistani hot girls, bd model, apu biswas, mahi, top most photo, picture, image, hd wallpaper, purnima hot photo, nu result, nu bd, national university result, nu.edu.bd result, nu bd result, primary result, directorate of primary education, ipo news, bpsc result, dsebd ipo, investing, education board result bd,result bd, ssc result 2016 bd, ssc result bd,nu.edu.bd result,ssc result bd, bcs exam, bpsc form, prize bond result, prize bond, prize bond draw, prize bond draw result, prise bond, ntrc result, teletalk bd, bdresult, ntrc bd, www.education board result.com, education board bd result, jsc rajal, nu.edu.bd notice, nu notice, nu bd notice ,honours result, national university degree result, national university masters result, education board result bd, nu admission result, nubd, nu admission, nu.edu.bd.info,  psc bdpsc result bd, sscresult, ssc result ,  www.education result.com, ntrca exam question, teacher registration, teletalk bangladesh, nu admission result,jsc exam result 2016,education bd,national university admission result bd,nu admission, jsc exam,www.ntrca, ntrca admit card, www.ntrca.bd.com,ntrca result, www.ntrca.com, www.ntrca.gov.bd,ntrca bd, www.ntrca.teletalk.com.bd, ntrca.gov.bd,??????, ntrca.teletalk.com.bd  jsc result,bd education board result,jsc scholarship result 2016,jdc result, jsc results 2016,bd education board,jsc scholarship result 2016, nu bd result,jdc result 2016,education bord bd,all result bd, scholarship, scholarships, nu result bd,nu admission test result bd, bd ssc result, national university, education board result bd, education board bd result, psc resutl bd">
<META NAME="Language" CONTENT="English">
<META HTTP-EQUIV="CACHE-CONTROL" CONTENT="PUBLIC">
<META NAME="Designer" CONTENT="Nur Alam Sourav">
<META NAME="distribution" CONTENT="Global">
<META NAME="city" CONTENT="Dhaka">
<META NAME="country" CONTENT="Bangladesh">
<meta name="google-site-verification" content="L4vmlt1MQkEUZooxRY1tEXtZ0sC02JSSVRSQ_aEFvSQ" />

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="image/style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
<script language="javascript">
  document.onmousedown = disableclick;
  status = "Right Click Disabled";
  Function disableclick(e)
  {
    if(event.button == 2)
    {
      alert(status);
      return false; 
    }
  }
</script> 
</head>
<body oncontextmenu="return false">



<!-- menu Bar option---------------------------------------------->
<?php include('image/nave.php'); ?>

  
	<!------------------------------------------Floating box 1(under nave bar)----------------------------------------->
 
<!-------------------------------------------------Floating box 2(left menu) --------------------------------------->

  <div class="relativels">
	<?php include('image/latest.php'); ?>
	</div>
  
  
  </div>

<!---------------------------------float box3(middle coloumn)--------------------------------------->
  <div class="relativem">
  <!-----------------------------row 1 -------------------------------------------------->
	<?php	
	mysql_connect('localhost','root','');
mysql_select_db('help');
	$tableName="post";
$targetpage = "index.php";
$limit = 10;

$query = "SELECT COUNT(*) as num FROM post";
$total_pages = mysql_fetch_array(mysql_query($query));
$total_pages = $total_pages[num];

$stages = 3;
$page = mysql_escape_string($_GET['page']);
if($page){
$start = ($page - 1) * $limit;
}else{
$start = 0;
}

// Get page data
$query1 = "SELECT * FROM $tableName LIMIT $start, $limit";
$result = mysql_query($query1);

// Initial page num setup
if ($page == 0){$page = 1;}
$prev = $page - 1;
$next = $page + 1;
$lastpage = ceil($total_pages/$limit);
$LastPagem1 = $lastpage - 1;

$paginate = '';
if($lastpage > 1)
{

$paginate .= "<div class='paginate'>";
// Previous
if ($page > 1){
$paginate.= "<a href='$targetpage?page=$prev'>previous</a>";
}else{
$paginate.= "<span class='disabled'>previous</span>"; }

// Pages
if ($lastpage < 7 + ($stages * 2)) // Not enough pages to breaking it up
{
for ($counter = 1; $counter <= $lastpage; $counter++)
{
if ($counter == $page){
$paginate.= "<span class='current'>$counter</span>";
}else{
$paginate.= "<a href='$targetpage?page=$counter'>$counter</a>";}
}
}
elseif($lastpage > 5 + ($stages * 2)) // Enough pages to hide a few?
{
// Beginning only hide later pages
if($page < 1 + ($stages * 2))
{
for ($counter = 1; $counter < 4 + ($stages * 2); $counter++)
{
if ($counter == $page){
$paginate.= "<span class='current'>$counter</span>";
}else{
$paginate.= "<a href='$targetpage?page=$counter'>$counter</a>";}
}
$paginate.= "...";
$paginate.= "<a href='$targetpage?page=$LastPagem1'>$LastPagem1</a>";
$paginate.= "<a href='$targetpage?page=$lastpage'>$lastpage</a>";
}
// Middle hide some front and some back
elseif($lastpage - ($stages * 2) > $page && $page > ($stages * 2))
{
$paginate.= "<a href='$targetpage?page=1'>1</a>";
$paginate.= "<a href='$targetpage?page=2'>2</a>";
$paginate.= "...";
for ($counter = $page - $stages; $counter <= $page + $stages; $counter++)
{
if ($counter == $page){
$paginate.= "<span class='current'>$counter</span>";
}else{
$paginate.= "<a href='$targetpage?page=$counter'>$counter</a>";}
}
$paginate.= "...";
$paginate.= "<a href='$targetpage?page=$LastPagem1'>$LastPagem1</a>";
$paginate.= "<a href='$targetpage?page=$lastpage'>$lastpage</a>";
}
// End only hide early pages
else
{
$paginate.= "<a href='$targetpage?page=1'>1</a>";
$paginate.= "<a href='$targetpage?page=2'>2</a>";
$paginate.= "...";
for ($counter = $lastpage - (2 + ($stages * 2)); $counter <= $lastpage; $counter++)
{
if ($counter == $page){
$paginate.= "<span class='current'>$counter</span>";
}else{
$paginate.= "<a href='$targetpage?page=$counter'>$counter</a>";}
}
}
}

// Next
if ($page < $counter - 1){
$paginate.= "<a href='$targetpage?page=$next'>next</a>";
}else{
$paginate.= "<span class='disabled'>next</span>";
}

$paginate.= "</div>";

}
echo $total_pages.' Results';
// pagination
echo $paginate;?>
		
	</div>
<!-----------------------colume right side----------------------------------------------------------------->
	
	<div class="relativers">
	<?php include('image/popular.php'); ?>
	
	
		
	</div>
	
	<!----------------------------------------------end right column-------------------------------->
	<div class="footer">
	<?php include('image/footer.php'); ?>
	</div>
<!-- Go to www.addthis.com/dashboard to customize your tools -->
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-575a3cc810553983"></script>

	
</body>
</html>

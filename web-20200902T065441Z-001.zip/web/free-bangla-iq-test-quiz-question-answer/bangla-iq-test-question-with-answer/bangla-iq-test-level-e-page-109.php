<!-------------------------- page-------------------->
<?php
session_start();
if (isset($_POST['i'])) {
$_SESSION['myValue9']=$_POST['i'];
}
else {
  header('Location:index.php');
exit;}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">

<script type="text/javascript">
    // When your page is ready, wire up these events
    $(function () {
        // When your submit button is clicked
        $("form").submit(function (e) {
            // If it is not checked, prevent the default behavior (your submit)
            if (!$('input[name="j"]').is(':checked')) {
                alert("Please ensure an EmbedSize is selected!");
                e.preventDefault();
            }
        });
    });
</script>

<br><p>১০। রফিক সাহেব কিছু খরগোশ নিয়ে বাগানে বেড়াতে গেছেন।
তার এক বন্ধু তখন পাশ দিয়ে যাচ্ছিল, সে জিজ্ঞাসা করল, আপনার কয়টি খরগোশ?
রফিক সাহেব একটি ধাঁধার মাধ্যমে উত্তর দিলেন, তিনি বলেন, “দুইটি খরগোশের ডানে দুটি খরগোশ, দুইটি খরগোশের বামে দুটি খরগোশ, দুইটি খরগোশের সামনে দুটি খরগোশ, 
দুইটি খরগোশের পিছনে দুটি খরগোশ।"
তখন তার বন্ধু সাথে সাথে উত্তরটি সঠিক ভাবে বলে দিলেন।
বলুন তো রফিক সাহেব এর কয়টি খরগোশ?
আর তার বন্ধুই বা এত দ্রুত উত্তর কিভাবে দিলেন? </p>

<form name="frmSubscription" method="post" action="your-score.php" onSubmit="return validate();">
<input type="radio" name="j" value="10" onClick="OptionSelected()" />&nbsp;৪টি 
<br>
<input type="radio" name="j" value="-2.5" onClick="OptionSelected()" /> &nbsp;৮টি
<br>
<input type="radio" name="j" value="-2.5" onClick="OptionSelected()" />&nbsp;১০টি 
<br>
<input type="radio" name="j" value="-2.5" onClick="OptionSelected()" />&nbsp;১২টি
<br>
<input type="submit" name="formSubmit" target="_blank" class="button button1" value="Answer & Total Score"/>
</form>


</div>


<div class="rs">
<?php  include('right-side.php'); ?>
	
</div>

<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>

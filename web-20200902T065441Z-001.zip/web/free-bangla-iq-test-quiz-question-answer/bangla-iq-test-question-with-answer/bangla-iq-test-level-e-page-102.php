<?php
session_start();
if (isset($_POST['b'])) {
$_SESSION['myValue2']=$_POST['b'];
}
else {
  header('Location:index.php');
exit;}
?>


<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">

<script type="text/javascript">
    // When your page is ready, wire up these events
    $(function () {
        // When your submit button is clicked
        $("form").submit(function (e) {
            // If it is not checked, prevent the default behavior (your submit)
            if (!$('input[name="c"]').is(':checked')) {
                alert("Please ensure an EmbedSize is selected!");
                e.preventDefault();
            }
        });
    });
</script>
<br><p> ৩। ৯টি ঘরের ভেতরে ৮টি ঘরে সংখ্যা দেয়া রয়েছে ও ১টি ঘর বাকি রয়েছে। বলতে হবে, প্রশ্নবোধক চিহ্ন দেয়া খালি ঘরটিতে কত বসবে?<br><img src="image/iq3.jpg" alt="bangla iq test question with answer" style="margin-left:100px;"></p>
<form name="frmSubscription" method="post" action="bangla-iq-test-level-e-page-103.php" onSubmit="return validate();">
<input type="radio" name="c" value="-2.5" onClick="OptionSelected()" />&nbsp;	3
<br>
<input type="radio" name="c" value="-2.5" onClick="OptionSelected()" />&nbsp;	6
<br>
<input type="radio" name="c" value="10" onClick="OptionSelected()" />&nbsp;	8
<br>
<input type="radio" name="c" value="-2.5" onClick="OptionSelected()" />&nbsp;	2
<br>
<input type="submit" name="formSubmit" target="_blank" class="button button1" value="Answer & Next Question"/>
</form>


</div>


<div class="rs">
<?php  include('right-side.php'); ?>
	
</div>

<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>

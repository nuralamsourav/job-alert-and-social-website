<!-------------------------- page-------------------->
<?php
session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style2.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">

<br>
<p> ৭। যদি পাঁচের অর্ধেক ৩ হয়, তাহলে ১০ এর এক তৃতীয়াংশ কত?</p>
		

<form>
<input type="radio" name="g" value="-2.5" />&nbsp;২
<br>
<input type="radio" name="g" value="10" checked/>&nbsp;৩
<br>
<input type="radio" name="g" value="-2.5"  />&nbsp;৪
<br>
<input type="radio" name="g" value="-2.5" />&nbsp;৬
<br>
<a href="free-bangla-iq-test-solution-level-e-page-107.php" class="button3 button31">Next Answer</a>
</form>




</div>


<div class="rs">
<?php  include('right-side.php'); ?>
	
</div>

<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>

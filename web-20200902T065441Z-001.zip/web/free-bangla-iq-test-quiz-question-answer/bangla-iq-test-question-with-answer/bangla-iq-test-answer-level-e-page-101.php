<!-------------------------- page-------------------->
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style2.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">


<br>
<p> ২। এখানে কতটি ত্রিভূজ আছে?  <br><img src="image/iq2.jpg" alt="bangla iq test question with ans" style="margin-left:100px;"></p>
<form>
<input type="radio" name="b" value="-2.5" />&nbsp; ৯ টি
<br>
<input type="radio" name="b" value="-2.5"  />&nbsp; ১০ টি
<br>
<input type="radio" name="b" value="-2.5"  />&nbsp; ১৩ টি
<br>
<input type="radio" name="b" value="10"  checked/>&nbsp;  ১৪ টি
<br>
<a href="bangla-iq-test-solve-level-e-page-102.php" class="button3 button31">Next Answer</a>
</form>


 
</div>


<div class="rs">
<?php  include('right-side.php'); ?>
	
</div>

<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>

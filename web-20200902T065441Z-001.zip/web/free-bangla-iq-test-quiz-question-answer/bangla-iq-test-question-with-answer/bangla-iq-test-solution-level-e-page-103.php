
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style2.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">

<br><p>৪। দুইটি চালে এক ঝাক ,এক ঝাক করে কবুতর রয়েছে।প্রথম ঝাক থেকে দিতীয় ঝাকে একটি কবুতর গেলে দুই জায়গার কবুতর সংখা সমান 
হবে।দিতীয় ঝাক থেকে প্রথম ঝাকে একটি কবুতর আসলে প্রথম ঝাকের কবুতর সংখা দিতীয় ঝাকের কবুতর সংখার দুইগুণ হবে।দুই ঝাকের কবুতর সংখা কত কত?</p>
<form>
<input type="radio" name="d" value="-2.5" />&nbsp;	১০ ও ৮
<br>
<input type="radio" name="d" value="-2.5" />&nbsp;	১২ ও ১০
<br>
<input type="radio" name="d" value="10" checked/>&nbsp;	৮ ও ৬
<br>
<input type="radio" name="d" value="-2.5" />&nbsp;	৬ ও ৪
<br>
<a href="bangla-iq-quiz-answer-level-e-page-104.php" class="button3 button31">Next Answer</a>
</form>




 
</div>


<div class="rs">
<?php  include('right-side.php'); ?>
	
</div>

<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>

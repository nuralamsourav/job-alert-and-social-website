<!-------------------------- page-------------------->
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">

<script type="text/javascript" src="script.js"></script>
<br>
<p>১।  আগামী পরশুর পরের দিন যদি রবিবার হয় তবে গতকালের আগের দিন কি বার ছিল ?</p>

<form name="frmSubscription" method="post" action="bangla-iq-test-level-e-page-101.php" onSubmit="return validate();">
<input type="radio" name="a" value="-2.5" onClick="OptionSelected()" />&nbsp;সোমবার
<br>
<input type="radio" name="a" value="10" onClick="OptionSelected()" />&nbsp;মঙ্গলবার
<br>
<input type="radio" name="a" value="-2.5" onClick="OptionSelected()" />&nbsp; বুধবার
<br>
<input type="radio" name="a" value="-2.5" onClick="OptionSelected()" />&nbsp;রবিবার
<br>
<input type="submit" name="formSubmit" target="_blank" class="button button1" value="Answer & Next Question"/>
</form>


</div>


<div class="rs">
<?php  include('right-side.php'); ?>
	
</div>

<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>

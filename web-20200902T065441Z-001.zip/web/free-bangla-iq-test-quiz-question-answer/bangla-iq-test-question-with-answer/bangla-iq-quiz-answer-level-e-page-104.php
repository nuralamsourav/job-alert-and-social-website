<!-------------------------- page-------------------->
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style2.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">

<br><p>৫।  একটি ছেলে খাটে শুয়ে ঘুমাচ্ছে এবং একটি মেয়ে ছেলেটির মাথার কাছে বসে থেকে তার মাথা টিপে দিচ্ছে।
এসময় একজন অতিথি বাসায় এসে তাদেরকে দেখে মেয়েটিকে জিজ্ঞেষ করল যে ছেলেটি তোমার কে হয়?
মেয়েটি উত্তর দিল "তার বাবা যার শশুর, আমার বাবা তার শশুর"।
উত্তর শুনে অতিথি কিছু না বুঝে মাথা চুলকাতে চুলকাতে অন্যঘরে চলে গেল।

<br><br>এখন বলুনতো মেয়েটির সাথে ছেলেটির সম্পর্ক কি ?</p>


<form>
<input type="radio" name="e" value="10"  checked/>&nbsp;	ভাই-বোন
<br>
<input type="radio" name="e" value="-2.5"  />&nbsp;	বাবা-মেয়ে
<br>
<input type="radio" name="e" value="-2.5"  />&nbsp;স্বামী-স্ত্রী
<br>
<input type="radio" name="e" value="-2.5" />&nbsp;কোনটি নয়
<br>
<a href="bangla-iq-quiz-solution-level-e-page-105.php" class="button3 button31"> Next Answer</a>
</form>


</div>


<div class="rs">
<?php  include('right-side.php'); ?>
	
</div>

<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>

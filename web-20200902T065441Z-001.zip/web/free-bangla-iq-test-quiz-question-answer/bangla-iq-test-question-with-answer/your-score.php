<!-------------------------- page-------------------->
<?php
session_start();
if (isset($_POST['j'])) {
$_SESSION['myValue10']=$_POST['j'];
}
else {
  header('Location:index.php');
exit;}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">


<div class="score">

<p>Your Total Score:</p>

<p style="color:blue; font-size:50px;"><?php echo $_SESSION['myValue1']+$_SESSION['myValue2']+$_SESSION['myValue3']+$_SESSION['myValue4']+$_SESSION['myValue5']+$_SESSION['myValue6']+$_SESSION['myValue7']+$_SESSION['myValue8']+$_SESSION['myValue9']+$_SESSION['myValue10']."%";
 ?>
<div class="last"><a href=""><button class="button button2" >IQ Test Home</button></a> <a href="bangla-iq-test-answer-level-e-page-100.php"><button class="button button2" >Answer</button></a></div>

</div>

</div>


<div class="rs">
<?php  include('right-side.php'); ?>
	
</div>

<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>

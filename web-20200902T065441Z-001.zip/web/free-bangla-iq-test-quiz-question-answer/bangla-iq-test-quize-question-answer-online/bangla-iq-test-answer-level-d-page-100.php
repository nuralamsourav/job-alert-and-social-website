<!-------------------------- page-------------------->
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">

<br>
<p>১। রাজার বাড়ীর অভ্যন্তরে একটি লেবু গাছ আছে । একজন সেখান থেকে লেবু আনতে গেলেন । গিয়ে দেখলেন বাড়ীর ভিতরে প্রবেশ করতে হলে তাকে তিনটি গেট পার হতে হবে । আর প্রতিটি 
গেটে রয়েছে একটি করে পাহারাদার । তিনি প্রথম গেটের পাহারেদারের কাছে গেলেন । পাহারাদার তাকে বলল, "আপনাকে ভিতরে ঢুকতে দিব কিন্তু বেরোনোর সময় আপনি যে কয়টি লেবু নিয়ে 
আসবেন তার অর্ধেক এবং আরও একটি লেবু দিতে হবে ।" ২য় এবং ৩য় গেটের পাহারাদার একই কথা বললেন । প্রশ্ন হচ্ছে তিনি কতটি লেবু গাছ থেকে আনলে একটি লেবু হাতে নিয়ে রাজার বাড়ি 
থেকে বের হতে পারবেন ?</p>
<form>
<input type="radio" name="a" value="-2.5"  />&nbsp;১৫ টা
<br>
<input type="radio" name="a" value="-2.5"  />&nbsp;১৯টা
<br>
<input type="radio" name="a" value="10" checked/>&nbsp;২২ টা
<br>
<input type="radio" name="a" value="-2.5"  />&nbsp;৩২টা
<br>
<a href="bangla-iq-test-question-ans-level-d-page-101.php" class="button3 button31">Next Answer</a>
</form>


</div>


<div class="rs">
<?php  include('right-side.php'); ?>
	
</div>

<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>
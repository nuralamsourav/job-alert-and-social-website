<!-------------------------- page-------------------->
<?php
session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">

<br><p>৫। যখন আমার বয়স ২ বছর ছিল তখন আমার ভাইয়ের বয়স আমার অর্ধেক ছিল. এখন আমার বয়স ৭৫ হলে আমার ভাইয়ের বয়স কত হবে??</p>


<form>
<input type="radio" name="e" value="-2.5"  />&nbsp;৩৫ বছর
<br>
<input type="radio" name="e" value="-2.5" />&nbsp;৩৬ বছর
<br>
<input type="radio" name="e" value="-2.5" />&nbsp;৩৭ বছর
<br>
<input type="radio" name="e" value="10" checked/>&nbsp;৭৪ বছর
<br>
<a href="bangla-iq-quiz-answer-level-d-page-105.php" class="button3 button31">Next Answer</a>
</form>


</div>


<div class="rs">
<?php  include('right-side.php'); ?>
	
</div>

<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>
<!-------------------------- page-------------------->
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">

<script type="text/javascript">
    // When your page is ready, wire up these events
    $(function () {
        // When your submit button is clicked
        $("form").submit(function (e) {
            // If it is not checked, prevent the default behavior (your submit)
            if (!$('input[name="a"]').is(':checked')) {
                alert("Please ensure an EmbedSize is selected!");
                e.preventDefault();
            }
        });
    });
</script>
<br>
<p>১। রাজার বাড়ীর অভ্যন্তরে একটি লেবু গাছ আছে । একজন সেখান থেকে লেবু আনতে গেলেন । গিয়ে দেখলেন বাড়ীর ভিতরে প্রবেশ করতে হলে তাকে তিনটি গেট পার হতে হবে । আর প্রতিটি 
গেটে রয়েছে একটি করে পাহারাদার । তিনি প্রথম গেটের পাহারেদারের কাছে গেলেন । পাহারাদার তাকে বলল, "আপনাকে ভিতরে ঢুকতে দিব কিন্তু বেরোনোর সময় আপনি যে কয়টি লেবু নিয়ে 
আসবেন তার অর্ধেক এবং আরও একটি লেবু দিতে হবে ।" ২য় এবং ৩য় গেটের পাহারাদার একই কথা বললেন । প্রশ্ন হচ্ছে তিনি কতটি লেবু গাছ থেকে আনলে একটি লেবু হাতে নিয়ে রাজার বাড়ি 
থেকে বের হতে পারবেন ?</p>

<form name="frmSubscription" method="post" action="bangla-iq-test-level-d-page-101.php" onSubmit="return validate();">
<input type="radio" name="a" value="-2.5" onClick="OptionSelected()" />&nbsp;১৫ টা
<br>
<input type="radio" name="a" value="-2.5" onClick="OptionSelected()" />&nbsp;১৯টা
<br>
<input type="radio" name="a" value="10" onClick="OptionSelected()" />&nbsp;২২ টা
<br>
<input type="radio" name="a" value="-2.5" onClick="OptionSelected()" />&nbsp;৩২টা
<br>
<input type="submit" name="formSubmit" target="_blank" class="button button1" value="Answer & Next Question"/>
</form>


</div>


<div class="rs">
<?php  include('right-side.php'); ?>
	
</div>

<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>
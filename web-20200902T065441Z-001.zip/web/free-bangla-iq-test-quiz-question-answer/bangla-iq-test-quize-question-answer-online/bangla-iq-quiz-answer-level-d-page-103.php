
<?php
session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">

<br><p>৪। এক ব্যাক্তি একটি আনারসের বাগান করার জন্য ১০০টি চাড়া লাগালেন । তার লক্ষ হল ১০০টিই মিষ্টি পাকা আনারস বিক্রি করা । কিন্তু চাড়া লাগানোর দিন থেকে তিনি দেখতে 
পেলেন প্রতিদিন ২টা করে চাড়া নষ্ট হয়ে যাচ্ছে । কোন কিছুতেই এটা ঠেকানো যাচ্ছে না । তবে একটা উপায় আছে । তা হল যদি কোন চাড়াতে সার দেওয়া হয় তবে সেই চাড়া হতে ২টা আনারস 
পাওয়া যাবে আর চাড়াটা নষ্ট হবে না । তবে এতে অতিরিক্ত ১০টাকা চাড়া প্রতি খরচ করতে হবে । এখন চাড়া থেকে আনারস পেতে ২০দিন লাগলে তার লক্ষ পুরণে অতিরিক্ত কত টাকা খরচ করতে হবে ?</p>
<form>
<input type="radio" name="d" value="-2.5" />&nbsp;২০০ টাকা
<br>
<input type="radio" name="d" value="10" checked/>&nbsp;৪০০ টাকা
<br>
<input type="radio" name="d" value="-2.5" />&nbsp;৬০০ টাকা 
<br>
<input type="radio" name="d" value="-2.5"  />&nbsp;৮০০ টাকা 
<br>
<a href="bangla-iq-test-answer-level-d-page-104.php" class="button3 button31">Next Answer</a>
</form>


</div>


<div class="rs">
<?php  include('right-side.php'); ?>
	
</div>

<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>
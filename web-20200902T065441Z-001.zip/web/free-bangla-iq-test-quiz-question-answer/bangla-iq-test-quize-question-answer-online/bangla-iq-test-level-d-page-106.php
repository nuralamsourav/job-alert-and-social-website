<!-------------------------- page-------------------->
<?php
session_start();
if (isset($_POST['f'])) {
$_SESSION['myValue6']=$_POST['f'];
}
else {
  header('Location:index.php');
exit;}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">

<script type="text/javascript">
    // When your page is ready, wire up these events
    $(function () {
        // When your submit button is clicked
        $("form").submit(function (e) {
            // If it is not checked, prevent the default behavior (your submit)
            if (!$('input[name="g"]').is(':checked')) {
                alert("Please ensure an EmbedSize is selected!");
                e.preventDefault();
            }
        });
    });
</script>
<br>
<p>৭। একটা দোকানে ৫ টা খালি কোকের বোতল দিলে একটা ভর্তি কোকের বোতল পাওয়া যায়।যদি একজনের কাছে ৭৭টা খালি বোতল থাকে তবে সে মোট কয় বোতল কোক খাইতে পারব??</p>
<form name="frmSubscription" method="post" action="bangla-iq-test-level-d-page-107.php" onSubmit="return validate();">
<input type="radio" name="g" value="-2.5" onClick="OptionSelected()" />&nbsp;১৫ টা
<br>
<input type="radio" name="g" value="-2.5" onClick="OptionSelected()" />&nbsp;১৮ টা
<br>
<input type="radio" name="g" value="10" onClick="OptionSelected()" />&nbsp;১৯ টা
<br>
<input type="radio" name="g" value="-2.5" onClick="OptionSelected()" />&nbsp;কোনটি নয়
<br>
<input type="submit" name="formSubmit" target="_blank" class="button button1" value="Answer & Next Question"/>
</form>


</div>


<div class="rs">
<?php  include('right-side.php'); ?>
	
</div>

<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>
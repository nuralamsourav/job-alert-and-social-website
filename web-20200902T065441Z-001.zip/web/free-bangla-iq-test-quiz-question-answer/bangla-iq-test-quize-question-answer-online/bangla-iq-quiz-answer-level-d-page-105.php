<!-------------------------- page-------------------->
<?php
session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">

<br><p>৬। মনে মনে ১০০০ সংখ্যাটি ভাবুন এবং এর
সাথে ৪০ যোগ করুন । এখন আরো ১০০০ যোগ করুন ।
এবার
আরো ৩০ যোগ করুন । আবারো ১০০০ যোগ করুন । এর
সাথে আরো ২০ যোগ করুন । শেষবারের মতো ১০০০ যোগ
করুন এবং এর সাথে আরো ১০ যোগ দিন । যোগফল কত
হলো ?</p>
<form>
<input type="radio" name="f" value="-2.5" />&nbsp;৫০০০
<br>
<input type="radio" name="f" value="-2.5" />&nbsp;৪০০০
<br>
<input type="radio" name="f" value="-2.5" />&nbsp;৫১০০
<br>
<input type="radio" name="f" value="10" checked/>&nbsp;৪১০০
<br>
<a href="free-bangla-online-iq-test-answer-level-d-page-106.php" class="button3 button31"> Next Answer</a>
</form>

</div>


<div class="rs">
<?php  include('right-side.php'); ?>
	
</div>

<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>
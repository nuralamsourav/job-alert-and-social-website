<!-------------------------- page-------------------->
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">

<br>
<p style="padding:30px; letter-space:140%;">১। বাংলা বর্ণমালার অক্ষরগুলো একবার ইংরেজী বর্ণমালার অক্ষরগুলোকে পার্টিতে আমন্ত্রণ জানাল। নির্ধারিত সময়ের কিছু আগেই মেহমানরা আসা শুরু করল এবং কিছুক্ষণের মধ্যেই পার্টি বেশ জমে উঠল। তবে কয়েকজন মেহমান সবার শেষে উপস্থিত
হল। কারা(কোন অক্ষরগুলো) শেষে উপস্থিত হয়েছিল?</p>

<form>
<input type="radio" name="a" value="-2.5"  />&nbsp;E N D
<br>
<input type="radio" name="a" value="10"/ checked>&nbsp;L A T E
<br>
<input type="radio" name="a" value="-2.5" />&nbsp;L A S T
<br>
<input type="radio" name="a" value="-2.5" />&nbsp;F I N A L
<br>
<a href="bangla-iq-test-answer-level-a-page-101.php" class="button3 button31" >next Answer</a>
</form>


 
</div>


<div class="rs">
<?php  include('right-side.php'); ?>
	
</div>

<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>

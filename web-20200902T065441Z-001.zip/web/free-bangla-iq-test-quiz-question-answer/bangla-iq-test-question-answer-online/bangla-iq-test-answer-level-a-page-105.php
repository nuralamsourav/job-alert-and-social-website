<!-------------------------- page-------------------->
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">

<br><p>৬। ধরা যাক রাস্তায় বেড়াতে গিয়ে একটি ছেলের সাথে দেখা হলো । তাকে জিজ্ঞেস করে জানা গেলো যে , সে বাবা মায়ের একমাত্র ছেলে । অন্যদিকে জানা গেলো তার বাবা মায়ের দুটি সন্তান । অপর সন্তানের সাথে ছেলেটির কি সম্পর্ক ?</p>
<form>
<input type="radio" name="f" value="10"  checked/>ভাই-বোন
<br>
<input type="radio" name="f" value="-2.5"  />ভাই-ভাই
<br>
<input type="radio" name="f" value="-2.5" />সৎভাই
<br>
<input type="radio" name="f" value="-2.5" />সৎবোন
<br>
<a href="bangla-iq-test-answer-level-a-page-106.php" class="button3 button31"/>Next Answer</a>
</form>




</div>


<div class="rs">
<?php  include('right-side.php'); ?>
	
</div>

<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>

<!-------------------------- page-------------------->
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">

<br>
<p> ২। এক ভদ্রমহিলা একটি বই নিয়ে কাউন্টারের কাছে এসে কাউন্টারের ভদ্রলোককে বইটা দিলেন। ভদ্রলোক বইটা একনজর দেখে নিয়ে বললেন ৮০ টাকা। ভদ্রমহিলা টাকা দিয়ে বইটা না নিয়েই চলে গেলেন। ভদ্রলোক মহিলাকে যেতে দেখেও পিছু ডাকলেন না। কেন?</p>
<form>
<input type="radio" name="b" value="-2.5"  />&nbsp;Hostel Menu Book
<br>
<input type="radio" name="b" value="-2.5"  />&nbsp;Ticket Book
<br>
<input type="radio" name="b" value="10"  checked/>&nbsp;library late fees
<br>
<input type="radio" name="b" value="-2.5" />&nbsp;For parcel Book
<br>
<a href="bangla-iq-test-answer-level-a-page-102.php" class="button3 button31"/>Next Answer</a>
</form>



 
</div>


<div class="rs">
<?php  include('right-side.php'); ?>
	
</div>

<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>

<!-------------------------- page-------------------->
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">



<br><p>১০। আপনি কার মার বাপের ছেলে ?</p>

<form>
<input type="radio" name="j" value="-2.5"  />&nbsp;দাদী
<br>
<input type="radio" name="j" value="10"  checked/> &nbsp;ভাগনা-ভাগনি 
<br>
<input type="radio" name="j" value="-2.5"  />&nbsp;ভাতিজা-ভাতিজী
<br>
<input type="radio" name="j" value="-2.5"  />&nbsp;ফুফু
<br>
<a href="http://bdresulttips.com/Bangla-iq-test-quiz-question-answer/" class="button3 button31"/>IQ Test Home</a>
</form>



</div>


<div class="rs">
<?php  include('right-side.php'); ?>
	
</div>

<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>

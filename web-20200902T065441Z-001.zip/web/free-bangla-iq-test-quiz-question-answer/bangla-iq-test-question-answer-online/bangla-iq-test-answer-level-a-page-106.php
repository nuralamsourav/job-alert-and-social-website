<!-------------------------- page-------------------->
<?php
session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">

<br>
<p>৭। রওশনের বাবা হাফিজ । রওশনের দাদুর মেয়ের ছেলের একজনই মামা আছেন । রওশনের সাথে ঐ মামার সম্পর্ক কি ? স্বামী ।</p>
<form>
<input type="radio" name="g" value="-2.5"  />&nbsp;মামা
<br>
<input type="radio" name="g" value="-2.5"  />&nbsp;ভাই
<br>
<input type="radio" name="g" value="10"  checked/>&nbsp;বাবা
<br>
<input type="radio" name="g" value="-2.5" />&nbsp;কোনটি নয়
<br>
<a href="bangla-iq-test-answer-level-a-page-107.php" class="button3 button31"/>Next Answer</a>
</form>


</div>


<div class="rs">
<?php  include('right-side.php'); ?>
	
</div>

<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>

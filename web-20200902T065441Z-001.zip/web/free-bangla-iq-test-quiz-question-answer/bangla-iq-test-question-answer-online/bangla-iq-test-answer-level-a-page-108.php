<!-------------------------- page-------------------->
<?php
session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">


<br>
<p>
৯। একজন পুরুষকে খোঁচা দিয়ে একজন পুরুষ আরেকজন মহিলাকে বলল, ” তার মা হলো তোমার বাবার একমাত্র কন্যা ।” মহিলার সাথে ঐ পুরুষের সম্পর্ক কি ?</p>
<form>
<input type="radio" name="i" value="-2.5"  />&nbsp;মামা ভাগ্নে
<br>
<input type="radio" name="i" value="-2.5"  />&nbsp;বোনের ছেলে 
<br>
<input type="radio" name="i" value="-2.5"  />&nbsp;মা ছেলে
<br>
<input type="radio" name="i" value="10"  checked/>&nbsp;খালা ভাগ্নে,
<br>
<a href="bangla-iq-test-answer-level-a-page-109.php" class="button3 button31"/>Next Answer</a>
</form>



</div>


<div class="rs">
<?php  include('right-side.php'); ?>
	
</div>

<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>

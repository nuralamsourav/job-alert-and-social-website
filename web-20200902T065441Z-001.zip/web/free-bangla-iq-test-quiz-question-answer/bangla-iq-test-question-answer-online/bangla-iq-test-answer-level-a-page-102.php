<?php
session_start();
?>


<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">

<br><p> ৩। মনির হলো সুমন ও রিঙকির পিতা । সুমন মনিরের ছেলে কিন্তু রিঙকি মনিরের ছেলে নয় । রিঙকি ও মনিরের সম্পর্ক কি ?</p>
<form>
<input type="radio" name="c" value="-2.5"  />&nbsp;সত্‍ বাবা
<br>
<input type="radio" name="c" value="-2.5" />&nbsp;ভাই বোন
<br>
<input type="radio" name="c" value="10" checked/>&nbsp;বাবা মেয়ে
<br>
<input type="radio" name="c" value="-2.5" />&nbsp;চাচা-ভাতিজি
<br>
<a href="bangla-iq-test-answer-level-a-page-103.php" class="button3 button31"/>Next Answer</a>
</form>



 
</div>


<div class="rs">
<?php  include('right-side.php'); ?>
	
</div>

<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>

<?php 
$servername="mysql8.000webhost.com";
$username="a2577131_help";
$password="s41s33c22";
$dbname="a2577131_test";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn)
{
	die("Connection  failed". mysqli_connect_error());
}
else
echo "connection sussecfully"."<br>";
?>
<?php
$name = test_input($_POST["name"]);
if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
  $nameErr = "Only letters and white space allowed"; 
}
$email = test_input($_POST["email"]);
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
  $emailErr = "Invalid email format"; 
}
?>
<?php $nameErr = $emailErr =  "";
$name = $email ="";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["name"])) {
    $nameErr = "Name is required";
  } else {
    $name = test_input($_POST["name"]);
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
      $nameErr = "Only letters and white space allowed"; 
    }
  }

  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = test_input($_POST["email"]);
    // check if e-mail address is well-formed
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Invalid email format"; 
    }
  }
?>


<?php
 $name=$_POST['name'];
 $email=$_POST['email'];
$sql = "INSERT INTO batch14(name,email)
VALUES('$name','$email')
";
if (mysqli_query($conn, $sql)) {
    echo "Database created successfully";
	$last_id=mysqli_insert_id($conn);
	echo "<br>".$last_id;
} else {
    echo "Error creating database: " . mysqli_error($conn);
}
?>
<html>
<head>
<title>Thank You Message</title>
</head>
<body>

<center>Thank YOu</center>
</body>
</html>
<?php 
mysqli_close($conn);
?>

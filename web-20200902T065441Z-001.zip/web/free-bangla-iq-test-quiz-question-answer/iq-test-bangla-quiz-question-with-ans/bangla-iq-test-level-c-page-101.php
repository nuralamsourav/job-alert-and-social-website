<!-------------------------- page-------------------->
<?php
session_start();
if (isset($_POST['a'])) {
$_SESSION['myValue1']=$_POST['a'];
}
else {
  header('Location:index.php');
exit;}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">

<script type="text/javascript">
    // When your page is ready, wire up these events
    $(function () {
        // When your submit button is clicked
        $("form").submit(function (e) {
            // If it is not checked, prevent the default behavior (your submit)
            if (!$('input[name="b"]').is(':checked')) {
                alert("Please ensure an Answer is selected!");
                e.preventDefault();
            }
        });
    });
</script>
<br>
<p>২। তিন টা বন্ধু একটা নদিতে মাছ ধরতে গেছে। তো মাছ তিনজনা একসাথে ধরার পর একটা পাত্রে রাখছে। মাছ ধরা শেষ হলে তারা  ঘুমিয়ে পড়লো। শর্ত হল সবাই মাছ সমান ভাগে ভাগ করবে। 
মনে করুন তাঁরা তিনজন হল বিপ্লব, পলাশ এবং শফিক। সবার আগে সকাল এ ঘুম থেকে উঠলো বিপ্লব । উঠে মাছ গুলো গুনে দেখল এবং তিন ভাগে ভাগ করার সময় একটা মাছ বেশি হওয়ায় সেটা সে নদিতে ফেলে দিলো। এবং নিজের ভাগ নিয়ে চলে গেলো। কিছুক্ষণ পড়ে আবার ঘুম থেকে 
উঠলো শামিম। সেও মাছ গুলো কে গুনে তিনভাগ করার সময় একটা 
মাছ বেশি হওয়ায় সেটা নদিতে ফেলে দিলো এবং নিজের ভাগ নিয়ে চলে গেলো। এবার সবার শেষে ঘুম থেকে উঠলো শফিক ভাবল হয়তো তাঁরা আসে পাশে কোথাও আছে। এই ভেবে সে মাছ গুলোকে আবার
 তিনভাগ করার পর দেখল একটা মাছ বেশি। সে সেটা নদিতে ফেলে দিলো এবং নিজের ভাগ নিয়ে চলে গেলো। 
এখন প্রশ্ন হল তাঁরা তিনজনে মোট কতটা মাছ ধরেরছিল?</p>





<form name="frmSubscription" method="post" action="bangla-iq-test-level-c-page-102.php" onSubmit="return validate();">
<input type="radio" name="b" value="-2.5" onClick="OptionSelected()" />১৩৩
<br>
<input type="radio" name="b" value="-2.5" onClick="OptionSelected()" />১৯৯
<br>
<input type="radio" name="b" value="10" onClick="OptionSelected()" />৬৭
<br>
<input type="radio" name="b" value="-2.5" onClick="OptionSelected()" />১৯
<br>
<input type="submit" name="formSubmit" target="_blank" class="button button1" value="Answer & Next Question"/>
</form>


</div>


<div class="rs">
<?php  include('right-side.php'); ?>
	
</div>

<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>
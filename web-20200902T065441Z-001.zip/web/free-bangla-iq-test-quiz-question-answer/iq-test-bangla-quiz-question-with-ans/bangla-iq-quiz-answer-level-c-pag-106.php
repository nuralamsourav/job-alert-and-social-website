<!-------------------------- page-------------------->
<?php
session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">

<br> <p>7. &nbsp; 3 + 3 x 3 - 3 + 3 =</p>
<form name="frmSubscription" method="post" action="bangla-iq-test-level-c-pag-107.php" onSubmit="return validate();">
<input type="radio" name="g" value="-2.5" />&nbsp;18
<br>
<input type="radio" name="g" value="-2.5" />&nbsp;12
<br>
<input type="radio" name="g" value="-2.5"  />&nbsp;03
<br>
<input type="radio" name="g" value="10" checked/>&nbsp;06
<br>
<a href="bangla-iq-test-answer-level-c-pag-107.php" class="button button1">Next Answer</a>
</form>




</div>


<div class="rs">
<div class="after-box2">
	<p id="h"><b>MOST POPULAR</b></p>
	</div>
	<div class="floating-box2">
	<a target="_blank" href="">
		<div class="img1">
		<img src="image/fbprofile.jpg" alt="dbblf scholarship ssc 2016" >
		</div>
			<div class="desc1">
				</a>
				</div>
	</div>
	
	
	<div class="floating-box2">
	<a target="_blank" href="">
		<div class="img1">
		<img src="image/fbprofile2.jpg" alt="dbblf scholarship ssc 2016">
		</div>
			<div class="desc1">
				</a>
				</div>
	</div>
	<div class="floating-box2">
	<a target="_blank" href="">
		<div class="img1">
		<img src="image/keyboard.jpg" alt="dbblf scholarship ssc 2016" >
		</div>
			<div class="desc1">		</a>
				</div>
	</div>
	
	<div class="floating-box2">
	<a target="_blank" href="">
		<div class="img1">
		<img src="image/apj.jpg" alt="dbblf scholarship ssc 2016">
		</div>
			<div class="desc1">
				</a>
				</div>
	</div>
	
	<div class="floating-box2">
	<a target="_blank" href="">
		<div class="img1">
		<img src="image/fbhack.jpg" alt="dbblf scholarship ssc 2016">
		</div>
			<div class="desc1">
				</a>
				</div>
	</div>
	
	
	<div class="floating-box2">
	<a target="_blank" href="">
		<div class="img1">
		<img src="image/ntrc.jpg" alt="dbblf scholarship ssc 2016" >
		</div>
			<div class="desc1">
				</a>
				</div>
	</div>

	
	
	
</div>

<div class="footer">
Copyright www.examresultbd20.com &copy; All Right Reserved
	</div>	
</body>
</html>

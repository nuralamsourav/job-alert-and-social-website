
<?php
session_start();
if (isset($_POST['c'])) {
$_SESSION['myValue3']=$_POST['c'];
}
else {
  header('Location:index.php');
exit;}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">

<script type="text/javascript">
    // When your page is ready, wire up these events
    $(function () {
        // When your submit button is clicked
        $("form").submit(function (e) {
            // If it is not checked, prevent the default behavior (your submit)
            if (!$('input[name="d"]').is(':checked')) {
                alert("Please ensure an Answer is selected!");
                e.preventDefault();
            }
        });
    });
</script>
<br>
<p>৪। একটা পরিবারে প্রতিটি মেয়ে সদস্যের যতটি ভাই আছে ততটি বোন আছে। কিন্তু ছেলে সদস্যের প্রত্যেকের যতোটি ভাই আছে তার দ্বিগুণ সংখ্যক বোন আছে।
 এখন বলতে হবে অই পরিবারে ছেলে এবং মেয়ের মোট সংখ্যা কত?</p>
<form name="frmSubscription" method="post" action="bangla-iq-test-level-c-page-104.php" onSubmit="return validate();">
<input type="radio" name="d" value="-2.5" onClick="OptionSelected()" />&nbsp;৩ বোন ৪ ভাই
<br>
<input type="radio" name="d" value="10" onClick="OptionSelected()" />&nbsp;৪ বোন ৩ ভাই
<br>
<input type="radio" name="d" value="-2.5" onClick="OptionSelected()" />&nbsp;৩ ভাই ৩ বোন
<br>
<input type="radio" name="d" value="-2.5" onClick="OptionSelected()" />&nbsp;৪ বোন ২ ভাই
<br>
<input type="submit" name="formSubmit" target="_blank" class="button button1" value="Answer & Next Question"/>
</form>


</div>


<div class="rs">
<?php  include('right-side.php'); ?>
	
</div>

<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>
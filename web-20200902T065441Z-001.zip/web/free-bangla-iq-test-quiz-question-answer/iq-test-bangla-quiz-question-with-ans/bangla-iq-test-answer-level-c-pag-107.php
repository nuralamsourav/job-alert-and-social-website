<!-------------------------- page-------------------->
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">

<br><p>8. John is training for a race. He uses this map to find possible routes. The route must start at John's house (home) and end at the park. He wants to run between 4.8 and 5 kilometers.
<br>Select the best route.</p>
<img src="image/iq9.jpg" alt="bangla iq test question with answer" style="margin-left:100px;"> 
<form>
<input type="radio" name="h" value="-2.5" /> &nbsp;Home - Museum - Park 
<br>
<input type="radio" name="h" value="10"  checked/> &nbsp;Home - Club - Bank - Lake - Park
<br>
<input type="radio" name="h" value="-2.5"  />&nbsp;Home - Club - School - Lake - Park
<br>
<input type="radio" name="h" value="-2.5"  />&nbsp;Home - Bank - Museum- Park
<br>
<a href="bangla-free-iq-test-answer-level-c-pag-108.php" class="button3 button31">Next Answer</a>
</form>



</div>


<div class="rs">
<?php  include('right-side.php'); ?>
	
</div>

<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>
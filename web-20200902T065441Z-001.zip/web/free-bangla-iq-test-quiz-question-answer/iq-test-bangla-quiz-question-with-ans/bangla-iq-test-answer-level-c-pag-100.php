<!-------------------------- page-------------------->
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">

<br>
<p>১।  একটা বৃত্তাকার সুইমিং পুলের ঠিক মাঝখান টাই একটা শাপলা ফুল আছে। ওই ফুলটি প্রতিদিন তার নিজের আয়তনের সমান করে বড় হয়। এখন একজন গিয়ে দেখল যে ২০ তম দিনে পুরো সুইমিং পুলে ভরে গেছে শাপলাটাই।  কততম দিনে ফুলটি সুইমিং পুলের অর্ধেক জুরে ছিল?
<form>
<input type="radio" name="a" value="-2.5"  />&nbsp;২
<br>
<input type="radio" name="a" value="-2.5"  />&nbsp;১০
<br>
<input type="radio" name="a" value="-2.5"  />&nbsp;৯
<br>
<input type="radio" name="a" value="10" checked/>&nbsp;১৯
<br>
<a href="iq-test-bangla-answer-level-c-pag-101.php" class="button3 button31"> Next Answer</a>
</form>







</div>


<div class="rs">
<?php  include('right-side.php'); ?>
	
</div>

<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>
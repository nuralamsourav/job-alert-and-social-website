<?php
session_start();

?>


<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">


<br><p>৩। ছয় বছর আগে আলিসার বয়স পাচ বছর কম ছিল মামুনের থেকে। এখন বল তাদের  র্বতমান বয়সের পার্থক্য কত?
<form>
<input type="radio" name="c" value="-2.5"  />&nbsp;১
<br>
<input type="radio" name="c" value="-2.5"  />&nbsp;২
<br>
<input type="radio" name="c" value="-2.5"  />&nbsp;৩
<br>
<input type="radio" name="c" value="10" checked/>&nbsp;৫
<br>
<a href="bangla-iq-test-solution-answer-level-c-pag-103.php" class="button button1"> Next Answer</a>
</form>

 
</div>


<div class="rs">
<div class="after-box2">
	<p id="h"><b>MOST POPULAR</b></p>
	</div>
	<div class="floating-box2">
	<a target="_blank" href="">
		<div class="img1">
		<img src="image/fbprofile.jpg" alt="dbblf scholarship ssc 2016" >
		</div>
			<div class="desc1">কে কে দেখলো আপনার ফেসবুক প্রোফাইল ? জেনে নিন কিভাবে দেখবেন
				</a>
				</div>
	</div>
	
	
	<div class="floating-box2">
	<a target="_blank" href="">
		<div class="img1">
		<img src="image/fbprofile2.jpg" alt="dbblf scholarship ssc 2016">
		</div>
			<div class="desc1">ফেসবুকে অন্যের লুকানো ফ্রেন্ড লিস্ট দেখার কৌশল…
				</a>
				</div>
	</div>
	<div class="floating-box2">
	<a target="_blank" href="">
		<div class="img1">
		<img src="image/keyboard.jpg" alt="dbblf scholarship ssc 2016" >
		</div>
			<div class="desc1">কম্পিউটার এর সকল কীবোর্ড শর্টকাট  মনে রাখার সহজ  পদ্ধতি			</a>
				</div>
	</div>
	
	<div class="floating-box2">
	<a target="_blank" href="">
		<div class="img1">
		<img src="image/apj.jpg" alt="dbblf scholarship ssc 2016">
		</div>
			<div class="desc1">রাষ্ট্রপতি ডঃ এ পি জে আবদুল কালামের ১২ টি উক্তি আপনার ক্যারিয়ার পাল্টে দিতে পারে
				</a>
				</div>
	</div>
	
	<div class="floating-box2">
	<a target="_blank" href="">
		<div class="img1">
		<img src="image/fbhack.jpg" alt="dbblf scholarship ssc 2016">
		</div>
			<div class="desc1">খুব সহজেই যেকোনো ফেসবুক অ্যাকাউন্ট হ্যাক!
				</a>
				</div>
	</div>
	
	
	<div class="floating-box2">
	<a target="_blank" href="">
		<div class="img1">
		<img src="image/ntrc.jpg" alt="dbblf scholarship ssc 2016" >
		</div>
			<div class="desc1">১৩তম শিক্ষক নিবন্ধন পরীক্ষার ফলাফল-২০১৬
				</a>
				</div>
	</div>

	
	
	
</div>

<div class="footer">
Copyright www.examresultbd20.com &copy; All Right Reserved
	</div>	
</body>
</html>

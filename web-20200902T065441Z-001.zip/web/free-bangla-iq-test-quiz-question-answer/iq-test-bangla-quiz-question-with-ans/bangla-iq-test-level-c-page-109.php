<!-------------------------- page-------------------->
<?php
session_start();
if (isset($_POST['i'])) {
$_SESSION['myValue9']=$_POST['i'];
}
else {
  header('Location:index.php');
exit;}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">

<script type="text/javascript">
    // When your page is ready, wire up these events
    $(function () {
        // When your submit button is clicked
        $("form").submit(function (e) {
            // If it is not checked, prevent the default behavior (your submit)
            if (!$('input[name="j"]').is(':checked')) {
                alert("Please ensure an Answer is selected!");
                e.preventDefault();
            }
        });
    });
</script>
<br><p>10. &nbsp;6+3=39 &nbsp;&nbsp;&nbsp;&nbsp;9+4=513&nbsp;&nbsp;&nbsp;&nbsp;18+16=234&nbsp;&nbsp;&nbsp;&nbsp;6+5=????
<form name="frmSubscription" method="post" action="your-score.php" onSubmit="return validate();">
<input type="radio" name="j" value="-2.5" onClick="OptionSelected()" />&nbsp;89
<br>
<input type="radio" name="j" value="-2.5" onClick="OptionSelected()" />&nbsp;59
<br>
<input type="radio" name="j" value="-2.5" onClick="OptionSelected()" />&nbsp;530
<br>
<input type="radio" name="j" value="10" onClick="OptionSelected()" />&nbsp;111
<br>
<input type="submit" name="formSubmit" target="_blank" class="button button1" value="Answer & Total Score"/>
</form>


</div>


<div class="rs">
<?php  include('right-side.php'); ?>
	
</div>

<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>
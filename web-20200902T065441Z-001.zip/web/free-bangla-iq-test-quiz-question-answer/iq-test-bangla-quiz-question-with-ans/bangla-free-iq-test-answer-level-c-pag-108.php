<!-------------------------- page-------------------->
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">

<br> <p>9. 0+50x1-60-60x0+10=???</p>
<form>
<input type="radio" name="i" value="-2.5"  />10
<br>
<input type="radio" name="i" value="-2.5"  />20
<br>
<input type="radio" name="i" value="-2.5"  />60
<br>
<input type="radio" name="i" value="10"  checked/>0
<br>
<a href="free-bangla-iq-quiz-solution-level-c-pag-109.php" class="button button1">Next Answer</a>
</form>



</div>


<div class="rs">
<div class="after-box2">
	<p id="h"><b>MOST POPULAR</b></p>
	</div>
	<div class="floating-box2">
	<a target="_blank" href="">
		<div class="img1">
		<img src="image/fbprofile.jpg" alt="dbblf scholarship ssc 2016" >
		</div>
			<div class="desc1">
				</a>
				</div>
	</div>
	
	
	<div class="floating-box2">
	<a target="_blank" href="">
		<div class="img1">
		<img src="image/fbprofile2.jpg" alt="dbblf scholarship ssc 2016">
		</div>
			<div class="desc1">
				</a>
				</div>
	</div>
	<div class="floating-box2">
	<a target="_blank" href="">
		<div class="img1">
		<img src="image/keyboard.jpg" alt="dbblf scholarship ssc 2016" >
		</div>
			<div class="desc1">		</a>
				</div>
	</div>
	
	<div class="floating-box2">
	<a target="_blank" href="">
		<div class="img1">
		<img src="image/apj.jpg" alt="dbblf scholarship ssc 2016">
		</div>
			<div class="desc1">
				</a>
				</div>
	</div>
	
	<div class="floating-box2">
	<a target="_blank" href="">
		<div class="img1">
		<img src="image/fbhack.jpg" alt="dbblf scholarship ssc 2016">
		</div>
			<div class="desc1">
				</a>
				</div>
	</div>
	
	
	<div class="floating-box2">
	<a target="_blank" href="">
		<div class="img1">
		<img src="image/ntrc.jpg" alt="dbblf scholarship ssc 2016" >
		</div>
			<div class="desc1">
				</a>
				</div>
	</div>

	
	
	
</div>

<div class="footer">
Copyright www.examresultbd20.com &copy; All Right Reserved
	</div>	
</body>
</html>

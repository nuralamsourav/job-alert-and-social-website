<!-------------------------- page-------------------->
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">

<br>
<p> ২।   মিলির সামনে রয়েছে চমৎকার একটি মেয়ের ছবি । মিলি বলছে আমি আমার বাবা মায়ের একমাত্র মেয়ে । আর ছবির মেয়েটির মা আমার বাবার মেয়ে । ঐ ছবিটি কার ?</p>
<form>
<input type="radio" name="b" value="-2.5"  />&nbsp;মিলির মা
<br>
<input type="radio" name="b" value="-2.5"  />&nbsp;মিলির বোনের
<br>
<input type="radio" name="b" value="10" checked/>&nbsp; মিলির মেয়ের
<br>
<input type="radio" name="b" value="-2.5" />&nbsp;কোনটি নয়
<br>
<a href="bangla-iq-test-answer-level-b-page-102.php" class="button3 button31"/>Next Answer</a>
</form>



</div>


<div class="rs">
<?php  include('right-side.php'); ?>
	
</div>

<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>

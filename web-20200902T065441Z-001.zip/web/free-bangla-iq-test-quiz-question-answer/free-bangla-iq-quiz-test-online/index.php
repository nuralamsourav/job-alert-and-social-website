<!-------------------------- page-------------------->
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">

<script type="text/javascript">
    // When your page is ready, wire up these events
    $(function () {
        // When your submit button is clicked
        $("form").submit(function (e) {
            // If it is not checked, prevent the default behavior (your submit)
            if (!$('input[name="a"]').is(':checked')) {
                alert("Please ensure an EmbedSize is selected!");
                e.preventDefault();
            }
        });
    });
</script>
<br>
<p style="padding:30px; letter-space:140%;">১।  তোমার মা আমার মায়ের ভাইয়ের নানী । তোমার সাথে আমার সম্পর্ক কি ? তুমি আমার কে ?</p>

<form name="frmSubscription" method="post" action="bangla-iq-test-level-b-page-101.php" onSubmit="return validate();">
<input type="radio" name="a" value="-2.5" onClick="OptionSelected()" />&nbsp;নাতনি
<br>
<input type="radio" name="a" value="-2.5" onClick="OptionSelected()" />&nbsp;নানী
<br>
<input type="radio" name="a" value="-2.5" onClick="OptionSelected()" />&nbsp; আমার দাদা
<br>
<input type="radio" name="a" value="10" onClick="OptionSelected()" />&nbsp;মামা-ভাগিনা
<br>
<input type="submit" name="formSubmit" target="_blank" class="button button1" value="Answer & Next Question"/>
</form>


</div>


<div class="rs">
<?php  include('right-side.php'); ?>
	
</div>

<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>

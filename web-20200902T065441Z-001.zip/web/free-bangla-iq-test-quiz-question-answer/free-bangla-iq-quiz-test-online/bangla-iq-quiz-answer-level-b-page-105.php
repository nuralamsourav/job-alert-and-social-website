<!-------------------------- page-------------------->
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">

<br><p>৬। একটি গাছের দুইটি ডালে দুইঝাক চড়ুই পাখি বসে আছে । একটি ছোট ঝাক ও অন্যটি বড় ঝাক । ঝাক দুইটিতে চড়ুইএর সংখ্যা এমন যে, বড় ঝাক থেকে ২টা ছোট ঝাকে এলে ঝাক দুইটিতে সমান সমান চড়ুই থাকে । আবার ছোট ঝাক থেকে ২টা বড় ঝাকে গেলে বড় ঝাকের চড়ুইএর সংখ্যা ছোটটার ৩গুন হয় ।
তাহলে গাছটিতে মোট কয়টি চড়ুই পাখি আছে ?</p>
<form>
<input type="radio" name="f" value="-2.5" />৬ ও ৮
<br>
<input type="radio" name="f" value="-2.5" />৪ ও ১০
<br>
<input type="radio" name="f" value="10" checked/>৬ ও ১০
<br>
<input type="radio" name="f" value="-2.5" />১০ ও ১৪
<br>
<a href="bangla-iq-test-answer-level-b-page-106.php" class="button3 button31"/>Next Answer</a>
</form>




</div>


<div class="rs">
<?php  include('right-side.php'); ?>
	
</div>

<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>

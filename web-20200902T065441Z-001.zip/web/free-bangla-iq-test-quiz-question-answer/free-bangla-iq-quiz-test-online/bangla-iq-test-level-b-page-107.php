<!-------------------------- page-------------------->
<?php
session_start();
if (isset($_POST['g'])) {
$_SESSION['myValue7']=$_POST['g'];
}
else {
  header('Location:index.php');
exit;}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">

<script type="text/javascript">
    // When your page is ready, wire up these events
    $(function () {
        // When your submit button is clicked
        $("form").submit(function (e) {
            // If it is not checked, prevent the default behavior (your submit)
            if (!$('input[name="h"]').is(':checked')) {
                alert("Please ensure an EmbedSize is selected!");
                e.preventDefault();
            }
        });
    });
</script>

<br>
<p>৮। নিচের প্যাটার্নগুলো খেয়াল করুন এবং (?) চিহ্নিত স্থানে সঠিক সংখ্যাটি  কত? &nbsp;&nbsp; ১ - ১ - ২ - ৩ - ৫ - ৮ - ১৩ </p>

<form name="frmSubscription" method="post" action="bangla-iq-test-level-b-page-108.php" onSubmit="return validate();">
<input type="radio" name="h" value="-2.5" onClick="OptionSelected()" />&nbsp;৮
<br>
<input type="radio" name="h" value="-2.5" onClick="OptionSelected()" />&nbsp;১৩
<br>
<input type="radio" name="h" value="10" onClick="OptionSelected()" />&nbsp;২১
<br>
<input type="radio" name="h" value="-2.5" onClick="OptionSelected()" />&nbsp;২৬
<br>
<input type="submit" name="formSubmit" target="_blank" class="button button1" value="Answer & Next Question"/>
</form>


</div>


<div class="rs">
<?php  include('right-side.php'); ?>
	
</div>

<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>

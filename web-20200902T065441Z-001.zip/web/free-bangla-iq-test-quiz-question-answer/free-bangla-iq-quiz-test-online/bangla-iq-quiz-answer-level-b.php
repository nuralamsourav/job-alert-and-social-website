<!-------------------------- page-------------------->
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">


<br>
<p style="padding:30px; letter-space:140%;">১।  তোমার মা আমার মায়ের ভাইয়ের নানী । তোমার সাথে আমার সম্পর্ক কি ? তুমি আমার কে ?</p>

<form>
<input type="radio" name="a" value="-2.5"  />&nbsp;নাতনি
<br>
<input type="radio" name="a" value="-2.5"  />&nbsp;নানী
<br>
<input type="radio" name="a" value="-2.5"  />&nbsp; আমার দাদা
<br>
<input type="radio" name="a" value="10" checked/>&nbsp;মামা-ভাগিনা
<br>
<a href="bangla-iq-test-answer-level-b-page-101.php" class="button3 button31"/>Next Answer</a>
</form>


 
</div>


<div class="rs">
<?php  include('right-side.php'); ?>
	
</div>

<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>

<!-------------------------- page-------------------->
<?php
session_start();
if (isset($_POST['a'])) {
$_SESSION['myValue1']=$_POST['a'];
}
else {
  header('Location:index.php');
exit;}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">

<script type="text/javascript">
    // When your page is ready, wire up these events
    $(function () {
        // When your submit button is clicked
        $("form").submit(function (e) {
            // If it is not checked, prevent the default behavior (your submit)
            if (!$('input[name="b"]').is(':checked')) {
                alert("Please ensure an EmbedSize is selected!");
                e.preventDefault();
            }
        });
    });
</script>
<br>
<p> ২।   মিলির সামনে রয়েছে চমৎকার একটি মেয়ের ছবি । মিলি বলছে আমি আমার বাবা মায়ের একমাত্র মেয়ে । আর ছবির মেয়েটির মা আমার বাবার মেয়ে । ঐ ছবিটি কার ?</p>
<form name="frmSubscription" method="post" action="bangla-iq-test-level-b-page-102.php" onSubmit="return validate();">
<input type="radio" name="b" value="-2.5" onClick="OptionSelected()" />&nbsp;মিলির মা
<br>
<input type="radio" name="b" value="-2.5" onClick="OptionSelected()" />&nbsp;মিলির বোনের
<br>
<input type="radio" name="b" value="10" onClick="OptionSelected()" />&nbsp; মিলির মেয়ের
<br>
<input type="radio" name="b" value="-2.5" onClick="OptionSelected()" />&nbsp;কোনটি নয়
<br>
<input type="submit" name="formSubmit" target="_blank" class="button button1" value="Answer & Next Question"/>
</form>


</div>


<div class="rs">
<?php  include('right-side.php'); ?>
	
</div>

<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>

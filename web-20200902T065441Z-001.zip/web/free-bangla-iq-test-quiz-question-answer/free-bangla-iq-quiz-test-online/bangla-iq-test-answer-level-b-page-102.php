<?php
session_start();

?>


<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">

<br><p> ৩।  মহিম মহিমাকে নির্দেশ করে রাজিয়াকে বলল যে, ‘ তার মা হলো তোমার বাবার একমাত্র কন্যা । ” মহিমার সাথে মহিমের সম্পর্ক কি ?</p>
<form>
<input type="radio" name="c" value="-2.5" />&nbsp;ভাইবোন
<br>
<input type="radio" name="c" value="-2.5" />&nbsp;বোন
<br>
<input type="radio" name="c" value="-2.5" />&nbsp; সৎমেয়ে
<br>
<input type="radio" name="c" value="10" checked/>&nbsp;তাদের উভয়ের মাঝে কোন সম্পর্ক নেই
<br>
<a href="bangla-iq-test-answer-level-b-page-103.php" class="button3 button31"/>Next Answer</a>
</form>







 
</div>


<div class="rs">
<?php  include('right-side.php'); ?>
	
</div>

<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>

<!-------------------------- page-------------------->
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include 'nave.php';?>


<div class="form">

<br><p>৫।  রাস্তায় একটি ছেলে দুর্ঘটনায় আহত হলে ছেলেটির পিতা ছেলেকে নিয়ে ডাক্তারের কাছে গেলেন । ডাক্তার বললেন , ” আমি আমার ছেলেকে অপারেশন করতে পারবো না । ” ডাক্তার ছেলেটির কে ?</p>


<form>
<input type="radio" name="e" value="-2.5"  />&nbsp;নাতিন 
<br>
<input type="radio" name="e" value="-2.5"  />&nbsp;বাবা
<br>
<input type="radio" name="e" value="10" checked/>&nbsp;মা
<br>
<input type="radio" name="e" value="-2.5" />&nbsp;কোনটি নয়
<br>
<a href="bangla-iq-quiz-answer-level-b-page-105.php" class="button3 button31"/>Next Answer</a>
</form>


</script>


</div>


<div class="rs">
<?php  include('right-side.php'); ?>
	
</div>

<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>

<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>government job bangladesh</title>

<meta charset="utf-8">
<META NAME="author" CONTENT="Nur Alam Sourav">
<META NAME="Description" CONTENT="Bangladesh government Jobs in bd find here and all govt jobs in bangladesh publish here then result of all bd jobs. all latest govt job update daily so find your choice job that update today. find only for goverment job.">
<META NAME="Keywords" 	CONTENT="www.bpsc.gov.bd,government job in bangladesh,job circular,bangladesh bank job circular,www.bpsc.com,jobs bd,bd govt job,all newspaper jobs,govt job circular,govt job bd,www.bangladeshpost.gov.bd,government jobs bd,bd govt jobs,job bd.com,jobs in bd,govt jobs bd,www.bd jobs today.com,bd jobs bangla,jobs circular,bpsc.com,bangladesh job news,government job circular,alljobsbd,government job bangladesh,bd jobs news,latest job circular,bd jobs circular,bd jobes,job circular in bangladesh,government job bd,new job circular,wwwbdjobs,govt jobs circular in bangladesh,bd govt job circular,recent job circular,bd jobs government,all govt jobs bd,govt job in bangladesh,bangladeshi job site,circular bd,bangladeshi job,gov jobs bd,govt jobs circular,bangla job news,bangladesh job circular,bangladesh govt job circular,job circuler,public service commission bangladesh,goverment jobs,jobcircular,bangladesh govt jobs,bd government job circular,online job bd,govt job circular bd,all job bd,government jobs in bd,job circular in bd,www.bd govt jobs.com,bangladesh govt job,bangladeshi jobs,bd government jobs,">
<META NAME="Language" CONTENT="English">
<META HTTP-EQUIV="CACHE-CONTROL" CONTENT="PUBLIC">
<META NAME="Designer" CONTENT="Nur Alam">
<META NAME="distribution" CONTENT="Global">
<META NAME="city" CONTENT="Dhaka">
<META NAME="country" CONTENT="Bangladesh">
<meta name="google-site-verification" content="" />

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="../include/home-post/image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="../include/home-post/style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
<script language="javascript">
  document.onmousedown = disableclick;
  status = "Right Click Disabled";
  Function disableclick(e)
  {
    if(event.button == 2)
    {
      alert(status);
      return false; 
    }
  }
</script> 
</head>
<body oncontextmenu="return false">



<!-- menu Bar option---------------------------------------------->
<?php include('../include/home-post/nave.php'); ?>

  
	
  <div class="relativels">
	<?php include('../include/home-post/latest.php'); ?>
	</div>
  
  
  </div>
<!-------------------------------------posting part---------------------------->
 <div class="relativem">
  	
	<div class="relative2">
		No Result Found at this Time. Please find Your Result after few Moment
		</div>
	
		
	</div>
	
<!------------------------------------------------------------------------------->
	<div class="relativers">
	<?php include('../include/home-post/popular.php'); ?>
	
	
		
	</div>
	
	<!----------------------------------------------end right column-------------------------------->
	<div class="footer">
	<?php include('../include/home-post/footer.php'); ?>
	</div>
<!-- Go to www.addthis.com/dashboard to customize your tools -->
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-575a3cc810553983"></script>

	
</body>
</html>

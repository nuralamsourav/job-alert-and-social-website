<!--------------------------home page-------------------->
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>



<!-- menu Bar option---------------------------------------------->
<?php include('nave.php'); ?>
 <div class="relativels">
  <!-----------------------------------------------post part-------------------------------------------->
  <div class="relative2">
  <h1 id="h">Dutch Bangla Bank Ltd. Foundation ( DBBLF ) Scholarship SSC Level 2016</h1><br>
 <img src="image/dbblf.jpg" alt="bangladesh army soldier soinik post job circular-2106" width="900px" height="500px" border="1">
 <br><br> <h2 id="m">Dutch Bangla Bank Ltd. Scholarship SSC Level 2016 Notice, Application and Result 2016</h2>
 <p>Dutch Bangla Bank Ltd. Foundation Scholarship 2016 publish for only SSC level student who passed SSC 2016 with good Result.
 The Notice of DBBLF Scholarship is available below and How to applying online internet process is Explain given below. and we are help to find your Dutch Bangla Bank Ltd. Foundation  Scholarship Result when publish result. you will be find your result in this page.
Now show past result of Dutch Bangla Bank Ltd. Foundation . You will find your result after publish SSC Level 2016 Result. 
 </p>
 <h3 id="h">DBBLF Scholarship Notice Application and Result SSC Level 2016</h3>
 <p>Dutch Bangla Bank has been awarding scholarship to Meritorious student in need of  financial aid
 styding at Higher Secondary, at Graduation and post Graduation level. In Continuation of this program Application are invited 
DBBL Scholarship for from meritorious Students in need to financial aid Who passed SSC or Equivalent Examination in 2016.
</p>
<br>  
 <p id="m">Requirement for HSC Scholarship (SSC passed Student)</p>
<p>EligibilityApplicants must be passed SSC or Equivalent exam in 2013.Applicants must have GPA 5.00 for under city corporation area School/Institute, GPA 4.70 for under district area School/Institute and GPA 4.50 for others remote area students (without 4th subjects) out of GPA5.00 scale for all groups.</p> 
 <br>
 <p id="m">Amount and Duration of Scholarship</p>
 <p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Scholarship Duration: 2 years (Renewable).<br>
 &nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Monthly Scholarship: Tk. 2000/-.<br>
 &nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Annul grant for reading materials: Tk. 2500/-.<br>
 &nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Annual grant for clothing: Tk. 1000/-.</p>
 <br><p id="m">Important Information of Scholarship for:HSC Level</p>
 <p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Application opening :&nbsp;&nbsp;<b style="color:blue">May 15, 2016</b><br>
 &nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Application closing :&nbsp;&nbsp;<b style="color:red">July 31, 2016</b><br>
 &nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Eligible List Publish:&nbsp;&nbsp;10 August, 2016.<br>
 &nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Original Paper Submission:&nbsp;&nbsp;11-31 August, 2016.<br>
 &nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;More Info:&nbsp;&nbsp;Apply Procedure Application form will be available in all the branches of Dutch-Bangla Bank Limited, where there is no branch of Dutch-Bangla Bank Limited; the applicants may apply in plain paper giving personal, academic and contact details (mentioning post code).</p>
<a href="#" target="_blank" class="button button1">DBBLF Scholarship Notice SSC 2016</a></p> 
 <h4 id="m">How to Apply Dutch Bangla Bank Ltd. Foundation Scholarship SSC Level for HSC Students</h4>
 <p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Scanned Passport size Color photo of applicant<br>
	&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Scanned Passport Size color Photo of Parents<br>
	&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Scanned Testimonial and Marksheet of SSC Examination</p> 
 <a href="http://www.dutchbanglabank.com/DBBLScholarship/vwparamSscScholarshipApplicationAction.action?batch_id=SSC-2016" target="_blank" class="button button1">DBBLF Scholarship apply Online</a></p> 
 <p id="m">Other criteria of the Scholarship:</p>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Students availing scholarship from other sources (except Government scholarship) will not qualify for Dutch-Bangla Bank's scholarship.</p> 
 <p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;90% of total scholarships will be earmarked for students who passed S.S.C./equivalent examinations from the institutions in rural areas and 50% of total scholarships will be earmarked for female students.</p>
 <p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Eligible and interested students who passed S.S.C./equivalent examinations in 2016, are requested to apply through online at: www.dutchbanglabank.com/DBBLScholarship along with the following:
 <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#8727;&nbsp;&nbsp;&nbsp;Scanned color photograph of student (image Dimension- width:500px to 600px, Height:700px to 800px and Image Size Max-150kb)<br>
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#8727;&nbsp;&nbsp;&nbsp;Scanned color photographs of student's father and mother (image Dimension- width:500px to 600px, Height:700px to 800px and Image Size Max-150kb)
 <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#8727;&nbsp;&nbsp;&nbsp;Scanned marksheet and testimonial of S.S.C./equivalent examinations (image Dimension- width:500px to 600px, Height:700px to 800px and Image Size Max-150kb)
 </p>
 <a href="http://www.dutchbanglabank.com/scholarship/application_form/DBBF_Scholarship_Application_Form.pdf" target="_blank" class="button button1">DBBLF Scholarship Application Form</a></p> 
<p id="m"> Dutch Bangla Bank Scholarship Notice</p>
 <br><img src="image/dbblf2.jpg" height="1100" width="900" border="1">
 <br><br><h5 id="m">Dutch Bangla Bank Scholarship Result SSC Level 2016 for HSC Student</h5>
 <p>Dutch Bangla Bank Foundation Scholarship SSC Level 2016 for HSC Students Result will be publish After Original paper Submission
 . First DBBLF Publish primary result and view Original Paper then publish Final Result of selected Students.
 </p>
  <a href="http://www.dutchbanglabank.com/DBBLScholarship/primarySelectedBatchGlobalParemetersAction.action" target="_blank" class="button button1">DBBLF Scholarship Result SSC-2016</a></p> 

 </div>
  <!-----------------------------------------------end post part-------------------------------------------->
 
 <div class="relative21">
		
  
	
  
  </div>
  </div>
  
<!---------------------------------------------most popular------------------------------->
  <div class="relativers">
	<?php include('popular.php'); ?>
	</div>
	<div class="footer">
	<?php include('footer.php'); ?>
	</div>
	
	
</body>
</html>

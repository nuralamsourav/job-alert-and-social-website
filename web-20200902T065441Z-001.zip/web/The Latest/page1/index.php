<!--------------------------home page-------------------->
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>

<?php include('nave.php'); ?>
  
 <div class="relativels">
  <!-----------------------------------------------post part-------------------------------------------->
  <div class="relative2">
  <h1 id="h">HSC College Admission Circular online Application 2016 Result</h1><br>
 <img src="image/addhsc.jpg" alt="bangladesh army soldier soinik post job circular-2106" width="900px" height="500px" border="1">
 <br><br> <h2 id="m">HSC College Admission 2016</h2>
 <p><strong>HSC (College) Admission Circular Result 2016: </strong>Higher Secondary Certificate (College) admission Start after publish SSC Result 2016.
 Now All Student of Bangladesh are Waiting for Admission to College in Session 2016-2017.
 This Admission Process will be complete by through SMS via Mobile phone and next Apply online to successfully finish HSC college Admission 2016 Application.<br> 
  Many Student don't Know how to successfully Application procedure by SMS process and online Application process.HSC Admission circular for All College in Bangladesh,
  How to application HSC College Admission 2016 and how to sent SMS to application HSC College Admission, of all other full information of HSC College Admission is Explain for successfully Admission process of HSC College Admission 2016.</p>
  <br>
  <h3 id="m">HSC Admission 2016 Details Information</h3>
 <p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;HSC Admission Online Application Start:&nbsp;<b style="color:magenta">26 May 2016.</b><br>
	&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;HSC Admission Online Application End:&nbsp; <b style="color:red">9 June 2016.</b><br>
	&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;1st Merit List Publish:&nbsp;16 June, 2016.<br>
 &nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;1st Merit List Admission Start:&nbsp;18 June, 2016<br>
 &nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;1st Merit List Admission End: &nbsp;30 June,2016.<br>
 &nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Class Start: &nbsp;10 July, 2016.<br>
 &nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Admission with Fine:&nbsp;10 July to 20 July.</p>
 <br><p id="m">Candidate Eligibility for Apply HSC College Admission</p>
 <p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Student who Passed SSC Exam from Any Education Board of the Passing 2014, 2015, 2016<br>
	&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Student Who passed SSC Exam from Bangladesh Open University of the Passing year 2013, 2014, 2015 and 2016<br>
	&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Student can Apply Science or Humanities or Commerce who passed SSC from Science Group <br>
 &nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Student can Apply Humanities or Commerce who passed SSC from Commerce Group <br>
 &nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Student can Apply Only Humanities who passed SSC from Humanities Group<br>
 <br>
 <h4 id="h">HSC College Admission 2016 Online & SMS Application Process</h4> 
 <p>Student Have to Option for Applying HSC College Admission 2016.one is Online Applying Process another is SMS Applying Process.
 Candidate Have to Apply online through at http://www.xiclassadmission.gov.bd/ official Website.Student Can choice Maximum 10 College for HSC Admission.<br>
 Sometime HSC Admission official Website is Busy and not respond so The Best way to application for HSC College Admission is SMS method.
 Carefully College choice before application. You select for Admission to College your SSC Result so Choice High or medium rate college.
 HSC College Admission 2016 application SMS Method is given Below:
 </p>
 <br>
 <h5 id="m">HSC College Admission 2016 Applying SMS Method</h5>
<p>A student can Apply HSC College Admission 2016 by SMS Process is only through SMS by Teletalk prepaid Mobile. Now Student can Apply online and SMS by Teletalk both Way Online Application fee is 150 TK for 5 College and 120 TK for single college.Apply SMS method:</p>
 <p style="color:magenta;font-size:20px;text-decoration:underline;">STEP ONE:</p>
 <p style="text-align:center"><b style="color:red">CAD</b>&nbsp;&#60;space&#62;&nbsp;<b style="color:red">College EIIN Number</b>&nbsp;&#60;space&#62;&nbsp;
 <b style="color:red">First 2 Letter of Desired Group</b>&nbsp;&#60;space&#62;&nbsp;<b style="color:red">First 3 Letter of Your SSC Board</b>&nbsp;&#60;space&#62;&nbsp;
 <b style="color:red">SSC Roll</b>&nbsp;&#60;space&#62;&nbsp;<b style="color:red">Passing Year</b>&nbsp;&#60;space&#62;&nbsp;<b style="color:red">Registration Number</b>&nbsp;&#60;space&#62;&nbsp;<b style="color:red">Name of Shift</b>&nbsp;&#60;space&#62;&nbsp;<b style="color:red">version</b> send to 16222</p>
 <p id="m">For Quota:</p>
  <p style="text-align:center"><b style="color:blue">CAD</b>&nbsp;&#60;space&#62;&nbsp;<b style="color:blue">College EIIN Number</b>&nbsp;&#60;space&#62;&nbsp;
 <b style="color:blue">First 2 Letter of Desired Group</b>&nbsp;&#60;space&#62;&nbsp;<b style="color:blue">First 3 Letter of Your SSC Board</b>&nbsp;&#60;space&#62;&nbsp;
 <b style="color:blue">SSC Roll</b>&nbsp;&#60;space&#62;&nbsp;<b style="color:blue">Passing Year</b>&nbsp;&#60;space&#62;&nbsp;<b style="color:blue">Registration Number</b>&nbsp;&#60;space&#62;&nbsp;
 <b style="color:blue">Name of Shift</b>&nbsp;&#60;space&#62;&nbsp;<b style="color:blue">version</b>&nbsp;&#60;space&#62;&nbsp;<b style="color:blue">Quota</b> send to 16222</p>
<br><p id="m"> First 3 Letter of Board:</p>
 <br>
 <table style="width:100%">
  <tr>
    <th>Full Board name</th>
    <th>Short 3 Letter</th>
  </tr>
  <tr>
    <td>Dhaka Board</td>		
	<td>DHA</td>
  </tr>
  <tr>
    <td>Rajshahi Board</td>
	<td>Raj</td>
  </tr>
  <tr>
    <td>Chittagong Board</td>
	<td>CHI</td>
  </tr>
  
  <tr>
    <td>Comilla Board</td>
	<td>COM</td>
  </tr>
 <tr>
    <td>Jessore</td>
	<td>JES</td>
  </tr>
 <tr>
    <td>Barishal Board</td>
	<td>BAR</td>
  </tr>
 <tr>
    <td>Sylhet Board</td>
	<td>SYL</td>
  </tr>

 <tr>
    <td>Dinajpur Board</td>
	<td>DIN</td>
  </tr>
  <tr>
    <td>Madrasha Board</td>
	<td>MAD</td>
  </tr>
 <td>Technical Board</td>
	<td>TEC</td>
  </tr>
 
</table>
<br>


<p id="m">group Keyword:</p>
<br>
<table style="width:100%">
 <tr>
    <th>Group Name</th>
    <th>Short 2 Letter</th>
  </tr>
<tr>
    <td>Science</td>
	<td>SC</td>
  </tr>

 <tr>
    <td>Business Studies</td>
	<td>BS</td>
  </tr>
  <tr>
    <td>Humanities</td>
	<td>HU</td>
  </tr>
 <td>Home Economics</td>
	<td>HE</td>
  </tr>
 
</table>
 <br>
 <p id="m">Shift Keyword:</p>
 <p>Morning-M, Day-D, Evening-E, No shift-N.</p>
 <br>
 <p id="m">Version KeyWord:</p>
 <p>Bangla-B, English-E</p>
 <br>
 <p id="m">Quota KeyWord:</p>
 <p>Freedom Fighter Quota-FQ, Employ Child of Desired College or Education Ministry-EQ, Special Quota-SQ</p>
 <br>
 <p style="color:magenta;font-size:20px;text-decoration:underline;">STEP TWO:</p>
 <p style="text-align:center"><b style="color:red">CAD</b>&nbsp;&#60;space&#62;&nbsp;<b style="color:red">YES</b>&nbsp;&#60;space&#62;&nbsp;
 <b style="color:red">PIN Number</b>&nbsp;&#60;space&#62;&nbsp;<b style="color:red">Contact Number</b>&nbsp;&#60;space&#62;&nbsp;and send to 16222.</p>
 <br><img src="image/collegeadd.jpg" height="600" width="900" border="1">
 <br><br>
 <h6 id="h">HSC College Admission 2016 Online Process</h6>
 <p> HSC college Admission 2016 Online process is given Below. first you sent your money by Teletalk prepaid SIM Mobile then Apply Online</p>
 <br>
 <iframe src="http://www.xiclassadmission.gov.bd/" height="600" width="900">
 <p>server is busy now. Reload Page every few second later</p>
 </iframe>
 </div>

 
 
 <div class="relative21">
		
  
	
  
  </div>
  </div>
  
<!---------------------------------------------most popular------------------------------->
  <div class="relativers">
	<?php include('popular.php'); ?>
	</div>
	<div class="footer">
	<?php include('footer.php'); ?>
	</div>
	
	
</body>
</html>

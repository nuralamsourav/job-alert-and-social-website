<!--------------------------home page-------------------->
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>



<!-- menu Bar option---------------------------------------------->
<?php include('nave.php'); ?>
 <div class="relativels">
  <!-----------------------------------------------post part-------------------------------------------->
  <div class="relative2">
  <h1 id="h">Bangladesh National Insurance Company Limited IPO Lottery Result</h1><br>
 <img src="image/ipo1.jpg" alt="bangladesh army soldier soinik post job circular-2106" width="900px" height="500px" border="1">
 <br><br> <h2 id="m">Download Bangladesh National Insurance Company Ltd. IPO Result</h2>
 <p><strong>Bangladesh National Insurance Company Limited:</strong>Bangladesh National Insurance Company Limited (BNICL) was incorporated in Bangladesh as a public limited company on 21 May 1996 under the Companies Act,
 1994 and licensed under the Insurance Act,1938 in order to run all types of general insurance business other than life insurance business. 
 It obtained certificate of commencement of business on 1 June 1996. It got registration from controller of Insurance on 18 June 1996. Presently the Company has been operating its business through 26 branches along with one local office.
 The branches are located different strategically important areas of the country.</p> 
 <br><a href="http://www.bniclimited.com/index.php?option=com_content&view=article&id=66&Itemid=56" target="_blank" class="button button1">Download Bangladesh National Insurance Company Limited IPO Prospectus</a></p> 
 <br>
 <p id="m">Download Bangladesh National Insurance Company Limited IPO Result 2016</p>
 <p>Bangladesh National Insurance Company Ltd IPO Lottery Result has been published. Download Bangladesh National Insurance Company Ltd IPO Lottery Result here. After ending of application of Initial Public Offer (IPO) from 17 February 2016 to 25 February 2016 or Lottery draw will be held on today, 20 March Sunday 2016. Bangladesh National Insurance Company Ltd IPO Lottery Draw Complete and Result found here. Result or Lottery draw has been published on 20 March 2016. Place: IEB Milanayton, Ramna  Dhaka. Time: 03:00 P.M.
<br>
Bangladesh National Insurance Company Ltd IPO Lottery Result found here. Bangladesh National Insurance Company Ltd IPO Lottery Draw Complete and Result found here. Result or Lottery draw has been published on 20 March 2016. Place: IEB Milanayton, Ramna  Dhaka. Time: 03:00 P.M. 
Public offer for application of Bangladesh National Insurance Company Ltd starting from 17 February 2016 and end on 25 February 2016.
 IPO or an Initial Public Offer (IPO) is the first sale of a stock by a private company to the public company. In this way a company can increase money by issuing either debt or equity. IPO or Share market launch is a type of public offer in which shares of a company generally are sold to the recognized investors that in turn, 
 sell to the general public by a securities exchange for the first time. 
 In this way, a private company transforms into a public limited company. IPOs are often issued by smaller 
 or newer companies seeking the capital to expand, but can also be done by large privately-owned companies looking to become publicly traded.
</p>
 <br><h3 id="h">Download Bangladesh National Insurance Ltd. IPO Lottery Result</h3>
<br>
<table style="width:100%">
  <tr>
    <th>Title</th>
    <th>Download</th>
  </tr>
  <tr>
    <td>Stock Exchange TREC No. / M.Bank SL No.</td>		
    <td><a href="http://www.bniclimited.com/images/pdf/DSE_CSE_MB_Code.pdf" target="_blank" color="green"><u>Download</u></a></td>
  </tr>
  <tr>
    <td>Residents Bangladeshi</td>
    <td><a href="http://www.bniclimited.com/images/pdf/rb_final_allocation.pdf" target="_blank" color="green"><u>Download</u></a></td>
  </tr>
  <tr>
    <td>Residents Bangladeshi affected small investors</td>
    <td><a href="http://www.bniclimited.com/images/pdf/asi_final_allocation.pdf" target="_blank" color="green"><u>Download</u></a></td>
  </tr>
  <tr>
    <td>Non-Residents Bangladeshi</td>
    <td><a href="http://www.bniclimited.com/images/pdf/nrb_final_allocation.pdf" target="_blank" color="green"><u>Download</u></a></td>
  </tr>
  <tr>
    <td>Mutual Fund</td>
    <td><a href="http://www.bniclimited.com/images/pdf/fund_final_allocation.pdf" target="_blank" color="green"><u>Download</u></a></td>
  </tr>
</table>

 
 </div>
  <!-----------------------------------------------end post part-------------------------------------------->
<div class="relative21">
		
  
	
  
  </div>
  </div>
  
<!---------------------------------------------most popular------------------------------->
  <div class="relativers">
	<?php include('popular.php'); ?>
	</div>
	<div class="footer">
	<?php include('footer.php'); ?>
	</div>
	
	
</body>
</html>

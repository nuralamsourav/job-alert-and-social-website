<!--------------------------home page-------------------->
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>



<!-- menu Bar option---------------------------------------------->
<?php include('nave.php')?>
 
 <div class="relativels">
  <!-----------------------------------------------post part-------------------------------------------->
  <div class="relative2">
  <h1 id="h">ব্র্যাক মেধাবিকাশ উদ্যোগ এইচএসসি স্তরের শিক্ষার্থীদের জন্য  বৃত্তি ২০১৬</h1><br>
 <img src="image/brac.jpg" alt="brac Bank Scholarship HSC level 2015" width="900px" height="500px" border="1">
 <br> <h2 id="h">BRAC Medhabikash udyog Scholarship 2015 for HSC Level Students</h2>
 <br>
  <p>Medhabikash udyog, an initiative that means ‘promoting talent’, was started in 2005. It is an innovative intervention where meritorious students from disadvantaged background receive financial support to cover college or university tuition fee at home or abroad. In addition, they receive support in English and computer literacy.
</p>
<br>
<p id="m">Recipients of the award </p>
<p>This scholarship is awarded to high achieving students who score at least 80 per cent in the secondary school certificate (SSC) or higher secondary school certificate (HSC) examinations, which is equivalent to grade point average (GPA) 5 or A . However, often due to financial constraints many of them cannot pursue higher education. If some do enrol themselves in institutions of higher education, limited financial ability hinders their academic performance.
 Therefore, through medhabikash udyog BRAC provides financial support to such students. This monthly monetary support covers admission fees, books and other educational and daily expenses. In addition, girls receive a stipend for transportation and incidental expenses. As of June 2015, a total of 3,542 students received medhabikash scholarships at higher secondary level (classes 11-12) and undergraduate levels of which 45 per cent of the recipients were girls.</p>
 <br><p id="m">Support provided </p>
 <p>The medhabikash programme is not just limited to financial support. The programme consists of specially designed training modules to develop students’ competency in English and computing. </p>
	<p>The English language course has been designed to help students gain more advanced knowledge of the language, which is often not covered in the traditional curriculum. As the general standard of English language teaching is rather poor in most secondary schools, our English courses are fundamental in helping students raise their language proficiencies.</p>
	<p>The course on information technology covers elementary skills that are essential to carry out common office tasks, including basic competency in software such as Microsoft Word and Excel.</p>
 <br><p id="m">Eligibility for the medhabikash</p>
 
<p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Students with GPA 5 in SSC and HSC whose parents have had little to no education</p>
 <p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Students with parents who earn their living through manual work (ie, day labourer, rickshaw puller, domestic help&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; unskilled/skilled labour, ultra poor, orphan, poorly paid jobs such as cook, guard, garments worker,  poor farmer etc)</p>
 <p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Students from single-parent household or with family members who are physically challenged, whose income is typically low or unstable</p>
 <p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Students who are girls (to promote girls’ access to post-secondary education), BRAC school graduates (both girls and boys), indigenous people, or people with disabilities</p>
 <p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Students who have been awarded with the medhabikash scholarship at HSC level need to score at least GPA 4.5 (without additional subject) to continue with this scholarship during their honors level</p>
 <p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Students with a family income not exceeding BDT 8,000 per month</p>
 <p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Students with family ownership of land not exceeding 50 decimals</p>
 <br>
 <p style="font-size:10px;"> source:www.brac.net</p>
 <img src="image/brac2.png" alt="brac medhabikash udyog Scholarship Hsc Level" width="900px" height="800px" border="1">
 <p id="m">Contact to Medhabikash</p>
 <p>BRAC Education Programme
	<br>BRAC Centre (10th floor),
	<br>75 Mohakhali, Dhaka 1212, Bangladesh
	<br>email: medhabikash@brac.net 
	<br>Tel: 88 02 9881265 Ext 3430/3433</p>
  </div>
  <!-----------------------------------------------end post part-------------------------------------------->
 
<div class="relative21">
		
  
	
  
  </div>
  </div>
  
<!---------------------------------------------most popular------------------------------->
  <div class="relativers">
	<?php include('popular.php'); ?>
	</div>
	<div class="footer">
	<?php include('footer.php'); ?>
	</div>
	
	
</body>
</html>

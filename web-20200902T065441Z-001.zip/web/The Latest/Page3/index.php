<!--------------------------home page-------------------->
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>



<!-- menu Bar option---------------------------------------------->
<?php include('nave.php'); ?>
 <div class="relativels">
  <!-----------------------------------------------post part-------------------------------------------->
  <div class="relative2">
  <h1 id="h">National University NU B.ED Exam Result 2015</h1><br>
 <img src="image/nu.jpg" alt="National University NU B.ED Exam Result 2015" width="900px" height="500px" border="1">
 <br><br> <h2 id="h"><strong>National University B.ED Exam Routine 2015</strong></h2>
 <p><strong>National University B.ED Exam Routine 2015 Download</strong> in this Website. National University B.ED Exam Routine 2015 publish on National University Website <a href="http://www.nu.edu.bd/" target="_blank">http://www.nu.edu.bd/</a>.
 National University has declared B.ED exam Result-2015 for part-1, part-2 and part-3 on National University Website.<br>
National University B.ED exam routine on Available on national university website. we also publish National University BED Exam Routine.you can download National University B.ED Exam Routine 2015 from this website that is given below. You Also collect your Admit card from your college and you can download your admit card from  national University website.  </p> 
 <br> 
 <h3 id="h"><a href="http://www.nu.edu.bd/home/all_notice_download_content/Examination/December_2015/notice_3387_pub_date_01.12.2015.pdf" target="_blank">Download National University B.ED Change Exam Routine 2015</a></h2>
 <br>
 <img src="image/nu2.jpg" alt="NU B.ED exam routine 2015" height="1200" width="900" border="1">
 <br>
 <h4 id="h"> National University B.ED exam Result 2015</h4>
 <p> After complete National University B.ED exam 2015, The Authority of National University is Publish National University B.ED Exam Result 2015. After 2 month finish NU B.ED exam 2015 
the result of National University bed exam Result is available below as well as National university official website.<br>
We Publish National university NU honours 1st year, 2nd year, 3rd year and 4th year B.ED exam Result 2015.</p> 
 <h5 id="h"><a href="http://www.nu.edu.bd/home/Professional%20Results/B.Ed.%20%28Hon%29%20Result/bed_2nd_sem_2015_res_prn_pub_date_22032016.txt" target="_blank">View National University B.ED Exam Result-2015</a></h5>
 <br>
 <p>Download National University B.ED exam Result 2015</p> 
 <a href="" class="button button1">Download</a>
 </div>
  <!-----------------------------------------------end post part-------------------------------------------->
 
 <div class="relative21">

		
		
		
		</div>
  
	<div class="relative21">
	
		
		
	</div>
  
  </div>
<!---------------------------------------------most popular------------------------------->
  <div class="relativers">
	
	<?php include('popular.php'); ?>
	</div>
	<!----------------------------------------------end right column-------------------------------->
	<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>

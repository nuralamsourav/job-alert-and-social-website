<!--------------------------home page-------------------->
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>



<!-- menu Bar option---------------------------------------------->
<?php include('nave.php'); ?>
 <div class="relativels">
  <!-----------------------------------------------post part-------------------------------------------->
  <div class="relative2">
  <h1 id="h">Bangladesh Army soldier (soinik) job circular-2016 for male and female</h1><br>
 <img src="image/army.jpg" alt="bangladesh army soldier soinik post job circular-2106" width="900px" height="500px" border="1">
 <br><br> <h2 id="m">Bangaldesh Army soinik post Job Circular-2016</h2>
  <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bangladesh army soinik post job circular-2016 is Published in 2016 for Male and Female soinik (soldier) post.
  The Details information of this job such as Educational Requirement, Age, Nationality, Applying process of this JOb
  and SMS procedure is Explain in below.<br> First you pay fee by SMS method and collect your User ID & Password then submit your application in the website http://sainik.teletalk.com.bd/. IF you want to successfully applying and Know details information of Bangladesh army soinik post job-2016 follow all article of this page.</p>
 <br><p id="h">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Eligibility for Application</p>
	<p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Application date start: 17th January 2016.<br>

	&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Application date ended: 30th June 2016.<br>

	&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Admit process date start: 17th January 2016.<br>

	&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Admit process date ended: 30th June 2016.<br>

	&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Application charge: BDT. 150/-</p>
	<br><p id="m"><u>For General Post:</u></p>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Age as on 15th November 2016:&nbsp;17 to 20 Years Old affidavit is not accept.</p> 
<p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Educational Requirement:&nbsp; Concerned applicants have to complete SSC or equivalent exam with minimum CGPA 3.50. &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Only science group’s students will apply in female post.</p>
<br><p id="m"><u>For Vocational Post</u></p>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;&nbsp;Age as on 15th November 2016:&nbsp;17 to 21 Years Old affidavit is not accept.Only for Driver trade age will be 17-22 years &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;old(affidavit is not received)</p> 
<p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;&nbsp;Educational Requirement (without driver): &nbsp;Concerned applicants have to complete SSC or equivalent exam with &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;minimum CGPA 3.50 in Vocational group from a standard board or institute. Only science group’s students will apply in &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;solder post.</p>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;&nbsp;Educational Requirement (driver): &nbsp;Concerned applicants have to complete SSC or equivalent exam with minimum &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;CGPA 3.50. Concerned applicants have to skill driving & legal documents. But from TTTI certificate will be acceptable.</p>
 <br><p id="m"><u>Physical Standard for Male</u></p>
 <p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;&nbsp;Height: &nbsp;1.68 meter (5’-6”)
 <p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;&nbsp;Weight: &nbsp;49.90 KG(110 pound)
 <p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;&nbsp;Chest: &nbsp;0.76 meter(30 inch)to 0.81 meter(32 inch)
 <p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;&nbsp;Swimming: &nbsp;Must No.
 <p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;&nbsp;Martial Status: &nbsp;Unmarried
 
 <br><p id="m"><u>Physical Standard for Female</u></p>
 <p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;&nbsp;Height: &nbsp;1.58 meter(5’-2”)
 <p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;&nbsp;Weight: &nbsp;47 KG(104 pound)
 <p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;&nbsp;Chest: &nbsp;0.71 meter(28 inch) to 0.76 meter(30 inch)
 <p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;&nbsp;Swimming: &nbsp;Must No.
 <p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;&nbsp;Martial Status: &nbsp;Unmarried
 <br><p id="m"><u>Selection process:</u></p> <p>Concerned applicants selected by attend written test (Bangla, English, Math, General Knowledge & intelligence), medical test & viva.</p>
 <br><p id="m"><u>For getting Admission candidates have to bring following Certificate/ Photo:</u></p>
 <p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;&nbsp;Education qualification main certificate/ Academic transcript (Marksheet)</p>
 <p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;&nbsp;Academic Testimonial including permanent address & date of birth by attached organization head.</p>
 <p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;&nbsp;Birth Certificate & character Certificate’s main copy.</p>
 <p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;&nbsp;Swimming dress</p>
 <p>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;&nbsp;Pen, Scale, Pencil and Clipboard for written test.</p>
<br><p id="m"><u>How to Apply Bangladesh Army soinik post Job SMS and Online</u></p>
 <p>Interested and Eligible Candidate Apply to Bangladesh Army soinik Post job first SMS process. When You finish SMS process then you get User ID and Password 
 to use next step online application. So save this user ID and Password.
 </p>
 <p>SMS Process: SAINIK &nbsp;&#60;space&#62;&nbsp;first three letters of SSC Board &nbsp;&#60;space&#62;&nbsp;Roll &nbsp;&#60;space&#62;&nbsp;Passing Year &nbsp;&#60;space&#62;&nbsp;District Code and send to 16222.</p>
 <p id="m"><b>Exp:</b>SAINIK&nbsp;RAJ&nbsp;12345&nbsp;2014&nbsp;52 and send to 16222.</p>
 <p>After Send SMS you will get a PIN no. and that informed that you will be charged BDT. 150 for Application</p>
 <p id="m"><u> then again send a SMS</u></p>
 <p>SMS Process: SAINIK&nbsp;&#60;space&#62;&nbsp;YES&nbsp;&#60;space&#62;&nbsp;PIN&nbsp;&#60;space&#62;&nbsp;your Mobile Number for contact message and send to 16222.</p>
  <p id="m"><b>Exp:</b>SAINIK&nbsp;YES&nbsp;889389&nbsp;01700000000 and send to 16222.</p>
<br>
<h3 id="h">&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;&nbsp;Apply Bangaldesh Army sainik post online</p>
 <br><iframe src="http://sainik.teletalk.com.bd/" height="500" width="900" border="1">
 <p> Server not found, Please try http://sainik.teletalk.com.bd/</p>
 </iframe>
 <br><h4 id="h"><a href="" target="_blank">Download Bangladesh Army Soldier (sainik) Job circular 2016</a></h4>
 <br>
 <img src="image/army_circular.jpg" width="900" height="auto" border="1">
 
 
 
 </div>
  <!-----------------------------------------------end post part-------------------------------------------->
 
<div class="relative21">
		
  
	
  
  </div>
  </div>
  
<!---------------------------------------------most popular------------------------------->
  <div class="relativers">
	<?php include('popular.php'); ?>
	</div>
	<div class="footer">
	<?php include('footer.php'); ?>
	</div>
	
	
</body>
</html>

<!--------------------------home page-------------------->
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>



<!-- menu Bar option---------------------------------------------->
<?php include('nave.php'); ?>
 <div class="relativels">
  <!-----------------------------------------------post part-------------------------------------------->
  <div class="relative2">
  <h1 id="h">Bangladesh Krishi Bank Job Circular Officer post-2016</h1><br>
 <img src="image/krishi.jpg" alt="brac Bank Scholarship HSC level 2015" width="900px" height="500px" border="1">
 <br> <h2 id="h">Bangladesh Krishi Bank  officer post Job Circular-2016</h2>
 <br>
  <p><strong>&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Bangladesh Krishi bank job circular for officer post-2016.</strong> krishi bank job exam 2016 applying different category of officer post, download your
  Admit card for Bangladesh Krishi Bank Job Exam 2016. and finally find your result after publish Bangladesh krishi Bank Job result 2016 in this website. So applying Bangladesh Krishi bank job before Deadline <b>7th June 2016.</b></p>
 <br><p><u id="m">&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Number of total post:</u>&nbsp;&nbsp;704.</p>
 <p><u id="m">&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Position:</u>&nbsp;&nbsp;Officer of Bangladesh Krishi Bank</p>
 <p><u id="m">&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Online application date start:</u>&nbsp;&nbsp;15th May 2016 at 10:00 am</p>
 <p><u id="m">&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Online application date end:</u> &nbsp;&nbsp;7th June 2016</p>
 <br>
 <p id="m">&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Education Requirement: </p>
 <p>Bachelor's degree from any Govt. approved university. approved university with at-least one first division/class. Third division/class in any examination is not allowed.</p>
 <br>
 <p><u id="m">&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Age as on 01/03/2016:</u>&nbsp;&nbsp;a. 30 years maximum</p>
 <p><u id="m">&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp; Salary scale:</u>&nbsp;&nbsp;Under National Pay Scale 2015, BDT 16000-16800-17640-18530-19460-20440-21470-22550-23680-24870-26120-27430-28810-30260-31780-33370-35040-36800-38640</p>
  <br><p><u id="m">&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Pre-requisite:</u>&nbsp;&nbsp;Scanned or Digital print of your passport size photograph & signature. 
   A 300×300 Pixel Color  photo that capture recently and 300×80 Pixel Candidates Signature After Completing the Application Form Fill-Up Candidates/Applicants will get A “User ID and they have to Pay Application Fee by Using Teletalk Mobile.</p>
 <p><u id="m">&nbsp;&nbsp;&nbsp;&nbsp;&sext;&nbsp;&nbsp;Last date of application:</u>&nbsp;&nbsp;07/06/2016</p>
 <br><h3 id="m">How to Applying Bangladesh Krishi Bank job 2016:</h3>
 <p> who are interested and Eligible  to applying Bangladesh Krishi bank officer Post 2016 the methos of applying system
 is available in Bangladesh bank website at https://www.bb.org.bd/. No accept on other process such as hand right post etc.</p>
 <p style="color:#FF0066;"> if you want to apply Bangladesh krishi bank job officer post-2016<a href="#" target="_blank" class="button button1">Apply Online </a></p> 
	<br><p id="m"> View Bangaldesh Krishi Bank Job circular Officer post-2016</p>
	<br><img src="image/krishi1.jpg" alt="bangladesh krishi bank job circular officer post 2016" width="910" height="auto" border="1">
 </div>
  <!-----------------------------------------------end post part-------------------------------------------->
 
 <div class="relative21">
		
  
	
  
  </div>
  </div>
  
<!---------------------------------------------most popular------------------------------->
  <div class="relativers">
	<?php include('popular.php'); ?>
	</div>
	<div class="footer">
	<?php include('footer.php'); ?>
	</div>
	
	
</body>
</html>

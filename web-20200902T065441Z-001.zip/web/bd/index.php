<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
</head>
<body>
<!---------------------social page plugin------------------------>



<!-------------------------End Social Plugin tage------------------------------->

<div class="header">
<div class="logo">
<img src="image/logo.jpg" alt="bdresult20.com" style="width:60px; height: 50px; "></div>
<div class="title"><p>exam<b id="m">R</b>esultbd<b id="m">2</b>0.com<p></div>
</div>

<!-- menu Bar option---------------------------------------------->
<div class="navebar">
<ul id="drop-nav">
  <li><a href="#">Home</a></li>
 
 <li><a href="#">All Result &#x21E9;</a>
    <ul>
      <li><a href="#">IPO Result</a></li>
      <li><a href="#">DPE Result</a></li>
	  <li><a href="#">BPSC Result</a></li>
	  <li><a href="#">PRIZE Bond Result</a></li>
	  <li><a href="#">NTRC Result</a></li>
	</ul>
  </li>
 
 
  <li><a href="#">Admission circular &#x21E9;</a>
    <ul>
       <li><a href="#">School Admission</a></li>
      <li><a href="#">College/HSC Admission</a></li>
      <li><a href="#">National University</a></li>
		<li><a href="#">Public University</a></li>
      <li><a href="#">medical College MBBS</a></li>
    </ul>
  </li>
  
  <li><a href="#">Routine &#x21E9;</a>
    <ul>
      <li><a href="#">PSC/Ebtedayi Routine</a></li>
      <li><a href="#">JSC/JDC Routine</a></li>
      <li><a href="#">SSC/Dakhil Routine</a></li>
		<li><a href="#">HSC/Alim Routine</a></li>
      <li><a href="#">NU Routine</a></li>
	</ul>
  </li>
  
  <li><a href="#">Education Result &#x21E9;</a>
    <ul>
       <li><a href="#">PSC/Ebtedayi Result</a></li>
      <li><a href="#">JSC/JDC Result</a></li>
      <li><a href="#">SSC/Dakhil Result</a></li>
		<li><a href="#">HSC/Alim Result</a></li>
      <li><a href="#">Vocational Result</a></li>
    </ul>
  </li>
  
  
  <li><a href="#">NU Result &#x21E9;</a>
    <ul>
      <li><a href="#">Degree Result</a></li>
      <li><a href="#">Honours Result</a></li>
	  <li><a href="#">Masters Result</a></li>
    </ul>
  </li>
  
  
  <li><a href="#">Admission Result &#x21E9;</a>
    <ul>
      <li><a href="#">School Admission</a></li>
      <li><a href="#">College/HSC Admission</a></li>
	  <li><a href="#">NU Admission</a></li>
	  <li><a href="#">University Admission</a></li>
	  <li><a href="#">Medical Admission</a></li>
	  </ul>
  </li>
  
  
  <li><a href="#">Scholarship &#x21E9;</a>
    <ul>
      <li><a href="#">PSC/Ebtedayi Scholarship</a></li>
      <li><a href="#">JSC/JDC Scholarship</a></li>
	  <li><a href="#">SSC/Dakhil Scholarship</a></li>
	  <li><a href="#">HSC/Alim Scholarship</a></li>
	  <li><a href="#">DBBLF Scholarship</a></li>
	  </ul>
  </li>
  
   <li><a href="#">Job Result &#x21E9;</a>
    <ul>
      <li><a href="#">Govt. Job</a></li>
      <li><a href="#">Bank Job</a></li>
	  <li><a href="#">BCS</a></li>
	  </ul>
  </li>
  
   <li><a href="#">Notice</a>
  </div>
 
	<!--------------------menu bar setting------------------>
	

	
	
	
	
	<!---------------End left column---------------------->
	
	<!--column middle, post------------------------------------->
  
   <div class="relativem">
					<div class="relative2">
					<h1 id="h"><a href="">SSC Exam Result 2016 All Education Board in Bangladesh</a></h1>
					<img src="image/man.jpg" alt="connect"><a href="" target="_blank" >Examresultbd20</a>   <img src="image/date.png" alt="date"><a href="">10 May 2016</a>    <img src="image/comment.jpg" alt="comment on facebook"><a href="" target="_blank">Comment</a>	
					<p >Secondary School certificate SSC Result 2016 in Bangladesh is the greatest publish Exam Result. SSC Exam Result 2016 will be publish By Ministary of education. All Education Board  publish Result will be same time.   </p>
					<p>The Education of Secondary School Certificate SSC are Three Group: Science, Humanities, And Commerce.Bangladesh Madrasha Education Board is the other Largest Board that SSC equivalent and Said it to be Dakhil.SSC/Dakhil/Vocational Result 2016 in Bangladesh Will be Publish on 1st or 2nd week of Month May ...... </p>
					<a href="#" class="button button1">Read more..</a>
					</div>
	
	
					<div class="relative2">
					<h2 id="h"><a href="">Bangldesh Madrasah Education Board Dakhil Result 2016</a></h2>
					<img src="image/man.jpg" alt="connect"><a href="" target="_blank" >Examresultbd20</a>    <img src="image/date.png" alt="date"><a href="">10 May 2016</a>       <img src="image/comment.jpg" alt="comment on facebook"><a href="" target="_blank">Comment</a>
					<p> Bangladesh Madrasha Education Board Dakhil Result 2016 is The result of Madrasah Board Dakhil Result. Dakhil is equivalent of Secondary school certificate SSC </p>
					<p>Every Year Number of student attend to SSC Equivalent Dakhil Exam Under Bangladesh Madrasah Education Board. Dakhil Exam Resul 2016 Will be Publish Soon with SSC or Vocational Exam Result 2016. Result Publish on.......
					</br></br></br><a href="#" class="button button1">Read more..</a>
					</div>
	
					<div class="relative2">
					<h3 id="h"><a href="">National University(NU) Honours second (2nd) Year Result 2016</a></h3>
					<img src="image/man.jpg" alt="connect"><a href="" target="_blank" >Examresultbd20</a>    <img src="image/date.png" alt="date"><a href="">10 May 2016</a>    <img src="image/comment.jpg" alt="comment on facebook"><a href="" target="_blank">Comment</a>
					<p>National University Honours 1st Year Result 2015 | www.nu.edu.bd. Honours 1st year examination 2015 under National University was started on last week of September 2015 and completed on November 2015. NU Honours First Year Result 2015 is on processing. National University Honours 1st Year Result 2015 will be found here when it is published by nu.edu.bd. Check Honours 2nd....</p>
					</br></br><a href="#" class="button button1">Read more..</a>
					</div>
	
					<div class="relative2">
					<h4 id="h"><a href="">polytechnic Institute Admission test circular, Exam Date and  Result 2016-2017</a></h4>
					<img src="image/man.jpg" alt="connect"><a href="" target="_blank" >Examresultbd20</a>    <img src="image/date.png" alt="date"><a href="">10 May 2016</a>    <img src="image/comment.jpg" alt="comment on facebook"><a href="" target="_blank">Comment</a>
					<p>Every Year Bangladesh Polytechnic Institute release Admission Circular for 4 year Diploma Engineering Course.Polytechnic Diploma Engineering Admission 2016-17 | www.techedu.gov.bd. Polytechnic Diploma Engineering Admission Circular 2016-17 session will be published soon. The candidates will have to to apply for Polytechnic Admission 2016-17. Polytechnic Diploma Engineering Admission 2016-17 Notice and Polytechnic Admission Result 2016-17 will be found here....</p> 
					</br><a href="#" class="button button1">Read more..</a>
					</div>
	
					<div class="relative2">
					<h5 id="h"><a href="">HSC-College Admission circular Notice Result 2016</a></h5>
					<img src="image/man.jpg" alt="connect"><a href="" target="_blank" >Examresultbd20</a>     <img src="image/date.png" alt="date"><a href="">10 May 2016</a>   <img src="image/comment.jpg" alt="comment on facebook"><a href="" target="_blank">Comment</a>
					<p> HSC-College Admission will be statrted after publish SSC/Dakhil Result 2016. SSC Result 2016 will be publish 10th may after 2.00 PM in bd. </p>
					<p>HSC College Admission Applying Candidate by two process Online applying or using  SMS  Method. The process of Applying College Admission are.....</p> 
					</br></br><a href="#" class="button button1">Read more..</a>
					</div>
					
					
					<div class="relative2">
					<h6 id="h"><a href="">83rd Prize Bond Draw Result 2016 of 100 TK-www.bb.org.bd</a></h6>
					<img src="image/man.jpg" alt="connect"><a href="" target="_blank" >Examresultbd20</a>    <img src="image/date.png" alt="date"><a href="">10 May 2016</a>    <img src="image/comment.jpg" alt="comment on facebook"><a href="" target="_blank">Comment</a>
					<p> 83rd Prize Bond Draw Result 2016 of 100 TK-www.bb.org.bd . Download Bangladesh Bank 83rd Prize bond Draw Result 2016 from Bangladesh Bank Website. 83rd Prize Bond Money Draw Result 2016 of TK 100 has been published
							on 02 May 2016. Bangladesh Bank Publsh this Result. 83rd Prize Bond Result of 100 TK also See on Website of Bangladesh Bank.</p>
					</br></br><a href="#" class="button button1">Read more..</a>
					</div>
					
					 <div class="footer">
					 
					<p>Copyright www.examresultbd20.com &copy; All Right Reserved</p> 
					</div>
	
					
					
					
	
	
	
	</div>
	<!----------------colume right side------------------------------->
	

  
	<div class="relativers">
	<div class="search">
								<td align="center">
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Search in this side
								</td>
								<td valign="middle" align="right"><br>
								<form action="http://www.google.com/cse" id="cse-search-box" target="_blank">
  <div>
    <input type="hidden" name="cx" value="partner-pub-7076007165145310:7627252844" />
    <input type="hidden" name="ie" value="UTF-8" />
    <input type="text" name="q" size="20" />
    <input type="submit" name="sa"  value="Search" />
  </div>
</form>

<script type="text/javascript" src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en"></script>

								</td>
</tr>
</div>


	<div class="add"><p style="background-color:	#4682B4; color:white;font-size:20px;">Advertising<p>
	</div>
	<div class="email">
	<p style="background-color:#4682B4;color:white;font-size:20px;">Get Update Via E-mail</p></br>
	<form name="fmce" method="post" action="index2.php">
	<font size="4"><b>Name: </b></font><input type="text" name="name"  maxlength="50" /></br></br>
	<font size="4"><b>Email: </b></font><input type="text" name="email" maxlength="150" /></br></br>
	<center><input type="submit" value="submit" style="width:100px; height: 40px;"/></center>
	</form>
	</div>
	 <div class="job">
	<p style="font-size:20px;color:white;background-color:green;text-align:center;">Govt. Job Circular</p>	
  <p id="p"><a href="">বাংলাদেশ সেনাবাহিনী ( সৈনিক  ) </a></p>
  <p id="p"><a href="">কর কমিশনারের কার্যালয়, কুমিল্লা  ( উচ্চমান সহকারী )</a></p>
  <p id="p"><a href=""> বাংলাদেশ টেলিকমিউনিকেশন্স কোম্পানী লিমিটেড (বিটিসিএল)  ( একাউন্ট্যান্ট )</a></p>
  <p id="p"><a href="">বস্ত্র ও পাট মন্ত্রণালয়  ( হিসাব রক্ষক  )</a></p>
	<p id="p"><a href="">ভূমি মন্ত্রণালয় ( সহকারী সিস্টেম এনালিস্ট  ) </a></p>
  <p id="p"><a href=""> ইসলামিক ফাউন্ডেশন  ( সেকশন অফিসার )</a></p>
  <p id="p"><a href="">পানি সম্পদ পরিকল্পনা সংস্থা  ( উর্ধ্বতন বৈজ্ঞানিক কর্মকর্তা (অর্থনীতিবিদ) )</a></p>
	<p style="font-size:18px; background-color: white;">	<a href="">	See More >></a></p>	
	</div>

	<div class="bank">
		<p style="font-size:20px;color:white;background-color:green;text-align:center;">All Bank Job Circular</p>
		<p id="p"><a href="">BRAC Bank Limited </a></p>
  <p id="p"><a href="">Eastern Bank Limited</a></p>
  <p id="p"><a href=""> IFIC Bank Limited</a></p>
  <p id="p"><a href="">Sonali Bank</a></p>
	<p id="p"><a href="">Janata Bank </a></p>
  <p id="p"><a href=""> Dutch-Bangla Bank Ltd. </a></p>
  <p id="p"><a href="">Al-Arafah Islami Bank Limited</a></p>
  <p id="p"><a href="">Dhaka Bank Limited</a></p>
	<p id="p"><a href="">ICB Bank Limited</a></p>
	<p style="font-size:18px; background-color: white;">	<a href="">	See More >></a></p>	
	</div>

	</div>
 <!------------------footer------------------------>
	<!-- Go to www.addthis.com/dashboard to customize your tools -->
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-57262ee04d2a6bd0"></script>

</body>
</html>

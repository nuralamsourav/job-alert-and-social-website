<?php 
$servername="mysql8.000webhost.com";
$username="a2577131_help";
$password="s41s33c22";
$dbname="a2577131_test";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn)
{
	die("Connection  failed". mysqli_connect_error());
}
else
echo "connection sussecfully"."<br>";
?>

<html>
<head>
<title>simple php programm</title>
</head>
<body>
<?php 
$query="SELECT * FROM batch14";
$result=mysqli_query($conn,$query);
if(!$result){die("database query failed.");}
?>
<?php 
while($row=mysqli_fetch_assoc($result))
{
	echo $row["id"];
	echo $row["name"];
	echo $row["address"];
	echo $row["email"];
	echo $row["number"];
	echo "<br>";
}
?>




</body>

</html>





<?php 
mysqli_close($conn);
?>
<?php 
$servername="mysql8.000webhost.com";
$username="a2577131_help";
$password="s41s33c22";
$dbname="a2577131_test";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn)
{
	die("Connection  failed". mysqli_connect_error());
}
else
echo ""."<br>";
?>

<?php
 $id=$_POST['id'];
 $name=$_POST['name'];
 $address=$_POST['address'];
 $email=$_POST['email'];
 $number=$_POST['number'];
$sql = "INSERT INTO batch14(id,name,address,email,number)
VALUES('$id','$name','$address','$email','$number')";
if (mysqli_query($conn, $sql)) {
    echo "Your Data succesfully submitted";
	$last_id=mysqli_insert_id($conn);
	echo "<br>".$last_id;
} else {
    echo  "You already submitted your information";
}


?>
<html>
<head>
<title>simple php programm</title>
</head>
<body>


</body>
</html>
<?php 
mysqli_close($conn);
?>
<html>
<head>
<title>simple php programm</title>
</head>
<body>






</body>

</html>

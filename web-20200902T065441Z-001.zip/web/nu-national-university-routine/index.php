<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>

<meta charset="utf-8">
<META NAME="author" CONTENT="Nur Alam Sourav">
<META NAME="Description" CONTENT="">
<META NAME="Keywords" 	CONTENT="">
<META NAME="Language" CONTENT="English">
<META HTTP-EQUIV="CACHE-CONTROL" CONTENT="PUBLIC">
<META NAME="Designer" CONTENT="Nur Alam">
<META NAME="distribution" CONTENT="Global">
<META NAME="city" CONTENT="Dhaka">
<META NAME="country" CONTENT="Bangladesh">
<meta name="google-site-verification" content="" />

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="../include/home-post/image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="../include/home-post/style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
<script language="javascript">
  document.onmousedown = disableclick;
  status = "Right Click Disabled";
  Function disableclick(e)
  {
    if(event.button == 2)
    {
      alert(status);
      return false; 
    }
  }
</script> 
</head>
<body oncontextmenu="return false">



<!-- menu Bar option---------------------------------------------->
<?php include('../include/home-post/nave.php'); ?>

  
	
  <div class="relativels">
	<?php include('../include/home-post/latest.php'); ?>
	</div>
  
  
  </div>
<!-------------------------------------posting part---------------------------->
 <div class="relativem">
  	
	<div class="relative2">
		No Result Found at this Time. Please find Your Result after few Moment
		</div>
	
		
	</div>
	
<!------------------------------------------------------------------------------->
	<div class="relativers">
	<?php include('../include/home-post/popular.php'); ?>
	
	
		
	</div>
	
	<!----------------------------------------------end right column-------------------------------->
	<div class="footer">
	<?php include('../include/home-post/footer.php'); ?>
	</div>
<!-- Go to www.addthis.com/dashboard to customize your tools -->
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-575a3cc810553983"></script>

	
</body>
</html>

<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>scholarships in bangladesh</title>

<meta charset="utf-8">
<META NAME="author" CONTENT="Nur Alam Sourav">
<META NAME="Description" CONTENT="International scholarship for bangladeshi students is provide many organization or country. the news of international scholarship to  foreign country for bangladeshi students is available here.">
<META NAME="Keywords" 	CONTENT="nst fellowship,scholarship for bangladeshi students,scholarships in bangladesh,full free scholarship for bangladeshi students,scholarship for bangladeshi student,scholarship result,scholarships for bangladeshi students,scholarship in usa,scholarship in bangladesh,scholarship for bangladeshi,study in usa from bangladesh,study in australia from bangladesh,scholarship in canada for bangladeshi students,british council in bangladesh,scholarship in germany for bangladeshi students,international scholarship for bangladeshi students,scholarship bd,iccr scholarship for bangladeshi students,undergraduate scholarship for bangladeshi students,study in newzealand for bangladeshi students,indian scholarship for bangladeshi students,bd scholarship,moedu.gov.bd scholarship,bangladesh scholarship,scholarship for bangladeshi students in europe,nst scholarship,study in canada for bangladeshi students,study in norway for bangladeshi students,world university bangladesh tuition fees,ministry of education bangladesh scholarship,japan scholarship for bangladeshi student,fulbright scholarship bangladesh,bangladeshi scholarship,foreign scholarship for bangladeshi students,study in malaysia for bangladeshi students,talentpool scholarship,study in singapore for bangladeshi student,scholarship in bd,study in denmark for bangladeshi student,daad scholarship for bangladeshi student,scholarships in usa,foreign scholarship information for bangladeshi students,scholarship for bd student,scholarship for bd students,masters scholarship for bangladeshi students,korean scholarship for bangladeshi students,study in uk from bangladesh,scholarship in malaysia for bangladeshi student,scholarship in usa for bangladeshi student,study in australia for bangladeshi student,scholarship in uk for bangladeshi students,study in usa for bangladeshi students,scholarship in usa for bangladeshi students,scholarship in china for bangladeshi students,bangladeshi students in usa,china scholarship for bangladeshi students,bangladesh universities,scholarship in australia for bangladeshi student,world university of bangladesh tuition fees,scholarship in russia for bangladeshi students,commonwealth scholarship bangladesh,scholarships for international students in usa,international scholarships for bangladeshi students,phd scholarship for bangladeshi students,scholarship in abroad for bangladeshi students">
<META NAME="Language" CONTENT="English">
<META HTTP-EQUIV="CACHE-CONTROL" CONTENT="PUBLIC">
<META NAME="Designer" CONTENT="Nur Alam">
<META NAME="distribution" CONTENT="Global">
<META NAME="city" CONTENT="Dhaka">
<META NAME="country" CONTENT="Bangladesh">
<meta name="google-site-verification" content="" />

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="../include/home-post/image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="../include/home-post/style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
<script language="javascript">
  document.onmousedown = disableclick;
  status = "Right Click Disabled";
  Function disableclick(e)
  {
    if(event.button == 2)
    {
      alert(status);
      return false; 
    }
  }
</script> 
</head>
<body oncontextmenu="return false">



<!-- menu Bar option---------------------------------------------->
<?php include('../include/home-post/nave.php'); ?>

  
	
  <div class="relativels">
	<?php include('../include/home-post/latest.php'); ?>
	</div>
  
  
  </div>
<!-------------------------------------posting part---------------------------->
 <div class="relativem">
  	
	<div class="relative2">
		No Result Found at this Time. Please find Your Result after few Moment
		</div>
	
		
	</div>
	
<!------------------------------------------------------------------------------->
	<div class="relativers">
	<?php include('../include/home-post/popular.php'); ?>
	
	
		
	</div>
	
	<!----------------------------------------------end right column-------------------------------->
	<div class="footer">
	<?php include('../include/home-post/footer.php'); ?>
	</div>
<!-- Go to www.addthis.com/dashboard to customize your tools -->
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-575a3cc810553983"></script>

	
</body>
</html>

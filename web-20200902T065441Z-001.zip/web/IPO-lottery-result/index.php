<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>ipo result dse bd-dsebd.org</title>

<meta charset="utf-8">
<META NAME="author" CONTENT="Nur Alam Sourav">
<META NAME="Description" CONTENT="Bangladesh IPO lottery result is related to the dse share market. it is also popular lottery for a bangladeshi share market holder. the result is available here to find your result all companies and all year give this now.">
<META NAME="Keywords" 	CONTENT="www.dsebd.org, dsebd.org,dsebd.org latest share price, dsebd.org market price,www.dsebd.org latest share price,  www.dsebd,dsc bd,result bd, dsebdorg,ipo result, dse ipo,ipo information, www dse com bd latest price,ipobd,dse ipo result, result bd.com,ipo lottery result,bd dse,upcoming ipo,wwwdsebd,bd ipo,dsebd ipo, dhaka stock exchange ipo result,dsebd.org ipo result,dseorgbd,ipo bd,wwwdsebdorg,dhaka stock exchange ipo,www.dsebd.org ipo result,ipo news bd,upcoming ipo bd,bdipo news,ipo bangladesh,www.dhaka stock exchang.com,ipo result bd,bd ipo news,dsc dhaka,dhaka stock exchance,dse ipo news,bd ipo lottery result,bd lottery,dse in bd,bangladesh ipo news,www.dhaka stock exchange ipo,dsebdcom,new ipo bd,ipo lottery,ipo form,ipo application form,bangladeshi ipo news,ipo result bangladesh,ipo results,www.dsebd.org ipo,bd ipo result,recent ipo bd,ipo information bd,upcoming ipo in dse,dse of bd,www dse org bd co,lottery bangladesh,lottery in bangladesh,dsebd.org ipo,ipo bd.com,bangladesh building system,dsebd.org org,iporesult,wwwdseorg,dsebd ipo result,upcoming ipo in bangladesh,ipo apply,dse results,dhakastockexchang,ipo bd news,dse ipo lottery result,ipo dse,bdipo result,latest ipo news,latest ipo news in bangladesh,ipo in bangladesh,dhaka stock exchange new ipo,www.dhaka stock exchange ipo result,ipobd news,www.ipo news bd.com,dseipo,upcoming ipo in bd,dse ipo lottery">
<META NAME="Language" CONTENT="English">
<META HTTP-EQUIV="CACHE-CONTROL" CONTENT="PUBLIC">
<META NAME="Designer" CONTENT="Nur Alam">
<META NAME="distribution" CONTENT="Global">
<META NAME="city" CONTENT="Dhaka">
<META NAME="country" CONTENT="Bangladesh">
<meta name="google-site-verification" content="" />

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="../include/home-post/image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="../include/home-post/style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
<script language="javascript">
  document.onmousedown = disableclick;
  status = "Right Click Disabled";
  Function disableclick(e)
  {
    if(event.button == 2)
    {
      alert(status);
      return false; 
    }
  }
</script> 
</head>
<body oncontextmenu="return false">



<!-- menu Bar option---------------------------------------------->
<?php include('../include/home-post/nave.php'); ?>

  
	
  <div class="relativels">
	<?php include('../include/home-post/latest.php'); ?>
	</div>
  
  
  </div>
<!-------------------------------------posting part---------------------------->
 <div class="relativem">
  	
	<div class="relative2">
		No Result Found at this Time. Please find Your Result after few Moment
		</div>
	
		
	</div>
	
<!------------------------------------------------------------------------------->
	<div class="relativers">
	<?php include('../include/home-post/popular.php'); ?>
	
	
		
	</div>
	
	<!----------------------------------------------end right column-------------------------------->
	<div class="footer">
	<?php include('../include/home-post/footer.php'); ?>
	</div>
<!-- Go to www.addthis.com/dashboard to customize your tools -->
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-575a3cc810553983"></script>

	
</body>
</html>

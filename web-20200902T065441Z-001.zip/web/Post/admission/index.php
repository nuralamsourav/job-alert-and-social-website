<!-------------------------- page-------------------->
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Bd result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>



<?php include('nave.php'); ?>
	
	
	<div class="relativels">
  <!-----------------------------------------------post part-------------------------------------------->
  <div class="relative2">
  
  
  
  </div>
  <!-----------------------------------------------end post part-------------------------------------------->
 
 <div class="relative21">
		<?php include('ground1.php'); ?>
		
		</div>
  
	<div class="relative21">
	<?php include('ground2.php'); ?>
		
	</div>
  
  </div>
<!---------------------------------------------right column------------------------------->
  <div class="relativers">
	<?php include('right-side.php'); ?>

	</div>
	<!----------------------------------------------end right column-------------------------------->
	<div class="footer">
<?php include('footer.php'); ?>
	</div>	
</body>
</html>

<?php 
$servername="localhost";
$username="root";
$password="";
$dbname="nur";
$conn=mysqli_connect($servername,$username,$password,$dbname);
?>

<?php

 $name=$_POST['name'];
 $email=$_POST['email'];
$sql = "INSERT INTO sourav(name,email)
VALUES('$name','$email')
";
?>
<html>
<head>
<title>Thank You Message</title>
</head>
<body>

<center>Thank YOu</center>
</body>
</html>
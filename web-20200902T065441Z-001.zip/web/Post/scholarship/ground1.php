<div class="after-box1"><p id="h">RECOMMENDED FOR YOU</p></div>
		<div class="img">
		<a target="_blank" href="">
		<img src="image/girl.jpg" alt="Trolltunga Norway" >
			<div class="desc">Tamil and Pakistani Hot and Cute Girls Photos and Wallpaper</div>
				</a>
		</div>
		
		<div class="img">
		<a target="_blank" href="">
		<img src="image/model.jpg" alt="Trolltunga Norway">
			<div class="desc">Tamil Actress Model Hot picture and Wallpaper</div>
				</a>
		</div>
		
		<div class="img">
		<a target="_blank" href="">
		<img src="image/saree.jpg" alt="Trolltunga Norway" >
			<div class="desc">Tamil actress hot photo with saree</div>
				</a>
		</div>
		
		<div class="img">
		<a target="_blank" href="">
		<img src="image/hsc.png" alt="HSC Result Education board result 2016" width="32%" height="178">
			<div class="desc">cute actress model with saree</div>
				</a>
		</div>
		
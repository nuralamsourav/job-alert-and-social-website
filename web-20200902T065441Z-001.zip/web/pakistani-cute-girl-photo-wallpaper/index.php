<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>pakistani girl</title>

<meta charset="utf-8">
<META NAME="author" CONTENT="Nur Alam Sourav">
<META NAME="Description" CONTENT="Pakistani hot and cute girl photo, image, picture and HD wallpaper is available is now. to visit you will be find top most popular pakistani cute and hot girls photo. ">
<META NAME="Keywords" 	CONTENT="pakistani mujra,pakistani girl,pakistani girls,pakistani hot girl,pakistani beautiful girl,Pakistani hot photo,pakistani girl photo,hot pakistani girls,pakistani beautiful girls,pakistani girl pic,beautiful pakistani girl,hot pakistani girl,pakistani cute girl,pakistan hot photos,pakistani hot pic,pakistani girls photo,beautiful pakistani girls,pakistani girls pic,pakistani hot picture,pakistan hot photo,pakistani hot photos,pakistani girls photos,pakistani girls picture,pakistani girl picture,pakistani cute girls,pakistani photo,pakistani hot pictures,pakistani nice girl,pakistani hot girl pic,pakistani hot girl photo,pakistani girl photos,pakistani girl image,pak girl,beautiful girl in pakistan,beautiful girl of pakistan,pakistani girls wallpapers,pak girls,pakistani girls pics,pak girl photo,pakistani girls images,pakistani girls pictures,pak girls photos,pakistani photos,pakistani images,pakistani girls mobile number,pak girls photo,pakistani girls image,pakistani girls wallpaper,pakistani girl images,pakistani girl mobile number,pak girls images,pakistani girls number,pak girls pic,pakistani girl pictures,pak girl image,pakistani grils,pakistani garls,pakistani women photos,pakistani beautiful girls photos,pakistani girl pics,pretty pakistani girls,pak girls image">
<META NAME="Language" CONTENT="English">
<META HTTP-EQUIV="CACHE-CONTROL" CONTENT="PUBLIC">
<META NAME="Designer" CONTENT="Nur Alam">
<META NAME="distribution" CONTENT="Global">
<META NAME="city" CONTENT="Dhaka">
<META NAME="country" CONTENT="Bangladesh">
<meta name="google-site-verification" content="" />

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="../include/home-post/image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="../include/home-post/style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
<script language="javascript">
  document.onmousedown = disableclick;
  status = "Right Click Disabled";
  Function disableclick(e)
  {
    if(event.button == 2)
    {
      alert(status);
      return false; 
    }
  }
</script> 
</head>
<body oncontextmenu="return false">



<!-- menu Bar option---------------------------------------------->
<?php include('../include/home-post/nave.php'); ?>

  
	
  <div class="relativels">
	<?php include('../include/home-post/latest.php'); ?>
	</div>
  
  
  </div>
<!-------------------------------------posting part---------------------------->
 <div class="relativem">
  	
	<div class="relative2">
		No Result Found at this Time. Please find Your Result after few Moment
		</div>
	
		
	</div>
	
<!------------------------------------------------------------------------------->
	<div class="relativers">
	<?php include('../include/home-post/popular.php'); ?>
	
	
		
	</div>
	
	<!----------------------------------------------end right column-------------------------------->
	<div class="footer">
	<?php include('../include/home-post/footer.php'); ?>
	</div>
<!-- Go to www.addthis.com/dashboard to customize your tools -->
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-575a3cc810553983"></script>

	
</body>
</html>

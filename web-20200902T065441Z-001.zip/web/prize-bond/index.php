<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>prize bond draw result</title>

<meta charset="utf-8">
<META NAME="author" CONTENT="Nur Alam Sourav">
<META NAME="Description" CONTENT="">
<META NAME="Keywords" 	CONTENT="prize bond,prize bond draw result,prize bond draw,prize bond result,prize bond draw results,prize bond results,prise bond,price bond,prize bond draw schedule,prise bond draw,prize bond draw result 100,prize bond draw list,prizebond result,prise bond result,price bond draw,prize bond list,national prize bond,prize bonds results,prize bond result 100,prize bond draw 100,price bond result,prise bond results,draw of prize bond 100,last prize bond draw,prize bond list 200,prize bond schedule,prize bond 200,prize bond 750,prize bond net,kalpoint prize bond,kalpoint,prize bond list 750,200 prize bond list,the prize bond,prize bond list 1500,prize bond check,prize bond result 750,200 prize bond,prize bond result 200,all prize bond,pakistani prize bond,prize bond 1500,prize bond draw 750,prize bond draw 200,prize bond list rs 200,list of prize bond">
<META NAME="Language" CONTENT="English">
<META HTTP-EQUIV="CACHE-CONTROL" CONTENT="PUBLIC">
<META NAME="Designer" CONTENT="Nur Alam">
<META NAME="distribution" CONTENT="Global">
<META NAME="city" CONTENT="Dhaka">
<META NAME="country" CONTENT="Bangladesh">
<meta name="google-site-verification" content="" />

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="../include/home-post/image/logo.jpg" type="image/x-icon">
<link rel="stylesheet" href="../include/home-post/style.css">
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
<script language="javascript">
  document.onmousedown = disableclick;
  status = "Right Click Disabled";
  Function disableclick(e)
  {
    if(event.button == 2)
    {
      alert(status);
      return false; 
    }
  }
</script> 
</head>
<body oncontextmenu="return false">



<!-- menu Bar option---------------------------------------------->
<?php include('../include/home-post/nave.php'); ?>

  
	
  <div class="relativels">
	<?php include('../include/home-post/latest.php'); ?>
	</div>
  
  
  </div>
<!-------------------------------------posting part---------------------------->
 <div class="relativem">
  	
	<div class="relative2">
		No Result Found at this Time. Please find Your Result after few Moment
		</div>
	
		
	</div>
	
<!------------------------------------------------------------------------------->
	<div class="relativers">
	<?php include('../include/home-post/popular.php'); ?>
	
	
		
	</div>
	
	<!----------------------------------------------end right column-------------------------------->
	<div class="footer">
	<?php include('../include/home-post/footer.php'); ?>
	</div>
<!-- Go to www.addthis.com/dashboard to customize your tools -->
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-575a3cc810553983"></script>

	
</body>
</html>

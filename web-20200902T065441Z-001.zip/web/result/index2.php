<?php 
$servername="mysql8.000webhost.com";
$username="a2577131_help";
$password="s41s33c22";
$dbname="a2577131_test";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn)
{
	die("Connection  failed". mysqli_connect_error());
}
else
echo "connection sussecfully"."<br>";
?>

<?php
 $name=$_POST['name'];
 $email=$_POST['email'];
$sql = "INSERT INTO batch14(id,name,address,email,number)
VALUES('$name','$email')
";
if (mysqli_query($conn, $sql)) {
    echo "Database created successfully";
	$last_id=mysqli_insert_id($conn);
	echo "<br>".$last_id;
} else {
    echo "Error creating database: " . mysqli_error($conn);
}
?>
<html>
<head>
<title>Thank You Message</title>
</head>
<body>

<center>Thank YOu</center>
</body>
</html>
<?php 
mysqli_close($conn);
?>
